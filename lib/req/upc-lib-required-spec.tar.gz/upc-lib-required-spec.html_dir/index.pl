# LaTeX2HTML 2008 (1.71)
# Associate index original text with physical files.


$key = q/upc_all_gather###1643/;
$index{$key} .= q|<A NAME="tex2html8" HREF="|."$dir".q|upc-lib-required-spec.html#136">|; 
$noresave{$key} = "$nosave";

$key = q/upc_all_permute###1667/;
$index{$key} .= q|<A NAME="tex2html14" HREF="|."$dir".q|upc-lib-required-spec.html#237">|; 
$noresave{$key} = "$nosave";

$key = q/upc_all_reduce_prefix###1736/;
$index{$key} .= q|<A NAME="tex2html32" HREF="|."$dir".q|upc-lib-required-spec.html#321">|; 
$noresave{$key} = "$nosave";

$key = q/upc_all_exchange###1653/;
$index{$key} .= q|<A NAME="tex2html12" HREF="|."$dir".q|upc-lib-required-spec.html#203">|; 
$noresave{$key} = "$nosave";

$key = q/UPC_FUNC###1682/;
$index{$key} .= q|<A NAME="tex2html26" HREF="|."$dir".q|upc-lib-required-spec.html#283">|; 
$noresave{$key} = "$nosave";

$key = q/UPC_OR###1676/;
$index{$key} .= q|<A NAME="tex2html20" HREF="|."$dir".q|upc-lib-required-spec.html#277">|; 
$noresave{$key} = "$nosave";

$key = q/upc_all_scatter###1635/;
$index{$key} .= q|<A NAME="tex2html6" HREF="|."$dir".q|upc-lib-required-spec.html#104">|; 
$noresave{$key} = "$nosave";

$key = q/broadcast###1628/;
$index{$key} .= q|<A NAME="tex2html5" HREF="|."$dir".q|upc-lib-required-spec.html#70">|; 
$noresave{$key} = "$nosave";

$key = q/upc_all_gather_all###1650/;
$index{$key} .= q|<A NAME="tex2html10" HREF="|."$dir".q|upc-lib-required-spec.html#169">|; 
$noresave{$key} = "$nosave";

$key = q/UPC_AND###1675/;
$index{$key} .= q|<A NAME="tex2html19" HREF="|."$dir".q|upc-lib-required-spec.html#276">|; 
$noresave{$key} = "$nosave";

$key = q/UPC_LOGAND###1678/;
$index{$key} .= q|<A NAME="tex2html22" HREF="|."$dir".q|upc-lib-required-spec.html#279">|; 
$noresave{$key} = "$nosave";

$key = q/permute###1668/;
$index{$key} .= q|<A NAME="tex2html15" HREF="|."$dir".q|upc-lib-required-spec.html#238">|; 
$noresave{$key} = "$nosave";

$key = q/gather###1644/;
$index{$key} .= q|<A NAME="tex2html9" HREF="|."$dir".q|upc-lib-required-spec.html#137">|; 
$noresave{$key} = "$nosave";

$key = q/UPC_ADD###1673/;
$index{$key} .= q|<A NAME="tex2html17" HREF="|."$dir".q|upc-lib-required-spec.html#274">|; 
$noresave{$key} = "$nosave";

$key = q/UPC_MULT###1674/;
$index{$key} .= q|<A NAME="tex2html18" HREF="|."$dir".q|upc-lib-required-spec.html#275">|; 
$noresave{$key} = "$nosave";

$key = q/reduction###1737/;
$index{$key} .= q|<A NAME="tex2html33" HREF="|."$dir".q|upc-lib-required-spec.html#322">|; 
$noresave{$key} = "$nosave";

$key = q/__UPC_COLLECTIVE__###1622/;
$index{$key} .= q|<A NAME="tex2html2" HREF="|."$dir".q|upc-lib-required-spec.html#60">|; 
$noresave{$key} = "$nosave";

$key = q/upc_op_t###1672/;
$index{$key} .= q|<A NAME="tex2html16" HREF="|."$dir".q|upc-lib-required-spec.html#273">|; 
$noresave{$key} = "$nosave";

$key = q/UPC_NONCOMM_FUNC###1683/;
$index{$key} .= q|<A NAME="tex2html27" HREF="|."$dir".q|upc-lib-required-spec.html#284">|; 
$noresave{$key} = "$nosave";

$key = q/prefix reduction###1738/;
$index{$key} .= q|<A NAME="tex2html34" HREF="|."$dir".q|upc-lib-required-spec.html#323">|; 
$noresave{$key} = "$nosave";

$key = q/UPC_LOGOR###1679/;
$index{$key} .= q|<A NAME="tex2html23" HREF="|."$dir".q|upc-lib-required-spec.html#280">|; 
$noresave{$key} = "$nosave";

$key = q/scatter###1636/;
$index{$key} .= q|<A NAME="tex2html7" HREF="|."$dir".q|upc-lib-required-spec.html#105">|; 
$noresave{$key} = "$nosave";

$key = q/collective libarary###1621/;
$index{$key} .= q|<A NAME="tex2html1" HREF="|."$dir".q|upc-lib-required-spec.html#59">|; 
$noresave{$key} = "$nosave";

$key = q/exchange###1654/;
$index{$key} .= q|<A NAME="tex2html13" HREF="|."$dir".q|upc-lib-required-spec.html#204">|; 
$noresave{$key} = "$nosave";

$key = q/UPC_XOR###1677/;
$index{$key} .= q|<A NAME="tex2html21" HREF="|."$dir".q|upc-lib-required-spec.html#278">|; 
$noresave{$key} = "$nosave";

$key = q/UPC_MIN###1680/;
$index{$key} .= q|<A NAME="tex2html24" HREF="|."$dir".q|upc-lib-required-spec.html#281">|; 
$noresave{$key} = "$nosave";

$key = q/gather, to all###1651/;
$index{$key} .= q|<A NAME="tex2html11" HREF="|."$dir".q|upc-lib-required-spec.html#170">|; 
$noresave{$key} = "$nosave";

$key = q/upc_collective.h###1623/;
$index{$key} .= q|<A NAME="tex2html3" HREF="|."$dir".q|upc-lib-required-spec.html#61">|; 
$noresave{$key} = "$nosave";

$key = q/upc_all_broadcast###1627/;
$index{$key} .= q|<A NAME="tex2html4" HREF="|."$dir".q|upc-lib-required-spec.html#69">|; 
$noresave{$key} = "$nosave";

$key = q/UPC_MAX###1681/;
$index{$key} .= q|<A NAME="tex2html25" HREF="|."$dir".q|upc-lib-required-spec.html#282">|; 
$noresave{$key} = "$nosave";

$key = q/upc_all_reduce###1735/;
$index{$key} .= q|<A NAME="tex2html31" HREF="|."$dir".q|upc-lib-required-spec.html#320">|; 
$noresave{$key} = "$nosave";
