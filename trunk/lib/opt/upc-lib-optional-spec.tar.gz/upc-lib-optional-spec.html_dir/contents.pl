# LaTeX2HTML 2008 (1.71)
# Associate contents original text with physical files.


$key = q/0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '0%:%'."$dir".q|upc-lib-optional-spec.html%:%UPC Language Required Library Specifications
V1.3 | unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 0 9 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '3%:%'."$dir".q|upc-lib-optional-spec.html%:%About this document ...%:%<tex2html_star_mark>| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 0 7 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '3%:%'."$dir".q|upc-lib-optional-spec.html%:%7 Library| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 0 6 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '3%:%'."$dir".q|upc-lib-optional-spec.html%:%Contents| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 0 7 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '4%:%'."$dir".q|upc-lib-optional-spec.html%:%4 UPC Parallel I/O ;SPMlt;upc_io.h;SPMgt;| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 0 8 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '3%:%'."$dir".q|upc-lib-optional-spec.html%:%Index| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

1;

