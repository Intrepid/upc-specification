# LaTeX2HTML 2008 (1.71)
# Associate internals original text with physical files.


$key = q/upc-io-common/;
$ref_files{$key} = "$dir".q|upc-lib-optional-spec.html|; 
$noresave{$key} = "$nosave";

$key = q/io-func-read/;
$ref_files{$key} = "$dir".q|upc-lib-optional-spec.html|; 
$noresave{$key} = "$nosave";

$key = q/io-func-write/;
$ref_files{$key} = "$dir".q|upc-lib-optional-spec.html|; 
$noresave{$key} = "$nosave";

$key = q/io-func-open/;
$ref_files{$key} = "$dir".q|upc-lib-optional-spec.html|; 
$noresave{$key} = "$nosave";

$key = q/io-func-list/;
$ref_files{$key} = "$dir".q|upc-lib-optional-spec.html|; 
$noresave{$key} = "$nosave";

1;

