# LaTeX2HTML 2008 (1.71)
# Associate index original text with physical files.


$key = q/upc_all_fwait_async###3637/;
$index{$key} .= q|<A NAME="tex2html99" HREF="|."$dir".q|upc-lib-optional-spec.html#705">|; 
$noresave{$key} = "$nosave";

$key = q/upc_all_fread_list_local###3623/;
$index{$key} .= q|<A NAME="tex2html89" HREF="|."$dir".q|upc-lib-optional-spec.html#617">|; 
$noresave{$key} = "$nosave";

$key = q/UPC_RDONLY###3548/;
$index{$key} .= q|<A NAME="tex2html29" HREF="|."$dir".q|upc-lib-optional-spec.html#170">|; 
$noresave{$key} = "$nosave";

$key = q/file seek###3569/;
$index{$key} .= q|<A NAME="tex2html47" HREF="|."$dir".q|upc-lib-optional-spec.html#295">|; 
$noresave{$key} = "$nosave";

$key = q/UPC_GET_HINTS###3598/;
$index{$key} .= q|<A NAME="tex2html72" HREF="|."$dir".q|upc-lib-optional-spec.html#434">|; 
$noresave{$key} = "$nosave";

$key = q/common file pointer###3589/;
$index{$key} .= q|<A NAME="tex2html63" HREF="|."$dir".q|upc-lib-optional-spec.html#392">|; 
$noresave{$key} = "$nosave";

$key = q/upc_all_fwait_async###3656/;
$index{$key} .= q|<A NAME="tex2html109" HREF="|."$dir".q|upc-lib-optional-spec.html#806">|; 
$noresave{$key} = "$nosave";

$key = q/asynchronous I\/O###3522/;
$index{$key} .= q|<A NAME="tex2html11" HREF="|."$dir".q|upc-lib-optional-spec.html#97">|; 
$noresave{$key} = "$nosave";

$key = q/UPC_GET_FL###3594/;
$index{$key} .= q|<A NAME="tex2html68" HREF="|."$dir".q|upc-lib-optional-spec.html#414">|; 
$noresave{$key} = "$nosave";

$key = q/file interoperability###3532/;
$index{$key} .= q|<A NAME="tex2html19" HREF="|."$dir".q|upc-lib-optional-spec.html#139">|; 
$noresave{$key} = "$nosave";

$key = q/UPC_EXCL###3555/;
$index{$key} .= q|<A NAME="tex2html36" HREF="|."$dir".q|upc-lib-optional-spec.html#177">|; 
$noresave{$key} = "$nosave";

$key = q/upc_all_fwrite_local###3613/;
$index{$key} .= q|<A NAME="tex2html82" HREF="|."$dir".q|upc-lib-optional-spec.html#528">|; 
$noresave{$key} = "$nosave";

$key = q/file atomicity###3527/;
$index{$key} .= q|<A NAME="tex2html15" HREF="|."$dir".q|upc-lib-optional-spec.html#105">|; 
$noresave{$key} = "$nosave";

$key = q/upc_all_fseek###3568/;
$index{$key} .= q|<A NAME="tex2html46" HREF="|."$dir".q|upc-lib-optional-spec.html#294">|; 
$noresave{$key} = "$nosave";

$key = q/individual file pointer###3539/;
$index{$key} .= q|<A NAME="tex2html24" HREF="|."$dir".q|upc-lib-optional-spec.html#164">|; 
$noresave{$key} = "$nosave";

$key = q/upc_all_fsync###3528/;
$index{$key} .= q|<A NAME="tex2html16" HREF="|."$dir".q|upc-lib-optional-spec.html#109">|; 
$noresave{$key} = "$nosave";

$key = q/file atomicity###3515/;
$index{$key} .= q|<A NAME="tex2html7" HREF="|."$dir".q|upc-lib-optional-spec.html#72">|; 
$noresave{$key} = "$nosave";

$key = q/file writing###3628/;
$index{$key} .= q|<A NAME="tex2html92" HREF="|."$dir".q|upc-lib-optional-spec.html#658">|; 
$noresave{$key} = "$nosave";

$key = q/asynchronous I\/O###3634/;
$index{$key} .= q|<A NAME="tex2html96" HREF="|."$dir".q|upc-lib-optional-spec.html#701">|; 
$noresave{$key} = "$nosave";

$key = q/upc_all_ftest_async###3523/;
$index{$key} .= q|<A NAME="tex2html12" HREF="|."$dir".q|upc-lib-optional-spec.html#98">|; 
$noresave{$key} = "$nosave";

$key = q/file open###3546/;
$index{$key} .= q|<A NAME="tex2html27" HREF="|."$dir".q|upc-lib-optional-spec.html#168">|; 
$noresave{$key} = "$nosave";

$key = q/UPC_STRONG_CA###3556/;
$index{$key} .= q|<A NAME="tex2html37" HREF="|."$dir".q|upc-lib-optional-spec.html#178">|; 
$noresave{$key} = "$nosave";

$key = q/file writing###3611/;
$index{$key} .= q|<A NAME="tex2html81" HREF="|."$dir".q|upc-lib-optional-spec.html#523">|; 
$noresave{$key} = "$nosave";

$key = q/file writing###3631/;
$index{$key} .= q|<A NAME="tex2html94" HREF="|."$dir".q|upc-lib-optional-spec.html#680">|; 
$noresave{$key} = "$nosave";

$key = q/file reading###3622/;
$index{$key} .= q|<A NAME="tex2html88" HREF="|."$dir".q|upc-lib-optional-spec.html#616">|; 
$noresave{$key} = "$nosave";

$key = q/file consistency###3602/;
$index{$key} .= q|<A NAME="tex2html76" HREF="|."$dir".q|upc-lib-optional-spec.html#458">|; 
$noresave{$key} = "$nosave";

$key = q/file pointer###3537/;
$index{$key} .= q|<A NAME="tex2html22" HREF="|."$dir".q|upc-lib-optional-spec.html#162">|; 
$noresave{$key} = "$nosave";

$key = q/UPC_APPEND###3553/;
$index{$key} .= q|<A NAME="tex2html34" HREF="|."$dir".q|upc-lib-optional-spec.html#175">|; 
$noresave{$key} = "$nosave";

$key = q/upc_all_fset_size###3574/;
$index{$key} .= q|<A NAME="tex2html51" HREF="|."$dir".q|upc-lib-optional-spec.html#313">|; 
$noresave{$key} = "$nosave";

$key = q/file pointer###3588/;
$index{$key} .= q|<A NAME="tex2html62" HREF="|."$dir".q|upc-lib-optional-spec.html#391">|; 
$noresave{$key} = "$nosave";

$key = q/upc_local_memvec###3618/;
$index{$key} .= q|<A NAME="tex2html85" HREF="|."$dir".q|upc-lib-optional-spec.html#581">|; 
$noresave{$key} = "$nosave";

$key = q/upc_all_fread_local_async###3640/;
$index{$key} .= q|<A NAME="tex2html101" HREF="|."$dir".q|upc-lib-optional-spec.html#718">|; 
$noresave{$key} = "$nosave";

$key = q/file hints###3560/;
$index{$key} .= q|<A NAME="tex2html41" HREF="|."$dir".q|upc-lib-optional-spec.html#226">|; 
$noresave{$key} = "$nosave";

$key = q/upc_all_fwrite_shared_async###3646/;
$index{$key} .= q|<A NAME="tex2html104" HREF="|."$dir".q|upc-lib-optional-spec.html#751">|; 
$noresave{$key} = "$nosave";

$key = q/UPC_SET_WEAK_CA_SEMANTICS###3586/;
$index{$key} .= q|<A NAME="tex2html60" HREF="|."$dir".q|upc-lib-optional-spec.html#377">|; 
$noresave{$key} = "$nosave";

$key = q/file hints###3597/;
$index{$key} .= q|<A NAME="tex2html71" HREF="|."$dir".q|upc-lib-optional-spec.html#433">|; 
$noresave{$key} = "$nosave";

$key = q/common file pointer###3519/;
$index{$key} .= q|<A NAME="tex2html9" HREF="|."$dir".q|upc-lib-optional-spec.html#84">|; 
$noresave{$key} = "$nosave";

$key = q/upc_off_t###3534/;
$index{$key} .= q|<A NAME="tex2html20" HREF="|."$dir".q|upc-lib-optional-spec.html#145">|; 
$noresave{$key} = "$nosave";

$key = q/file close###3563/;
$index{$key} .= q|<A NAME="tex2html43" HREF="|."$dir".q|upc-lib-optional-spec.html#266">|; 
$noresave{$key} = "$nosave";

$key = q/file writing###3636/;
$index{$key} .= q|<A NAME="tex2html98" HREF="|."$dir".q|upc-lib-optional-spec.html#703">|; 
$noresave{$key} = "$nosave";

$key = q/UPC_SET_HINT###3599/;
$index{$key} .= q|<A NAME="tex2html73" HREF="|."$dir".q|upc-lib-optional-spec.html#444">|; 
$noresave{$key} = "$nosave";

$key = q/end of file###3513/;
$index{$key} .= q|<A NAME="tex2html5" HREF="|."$dir".q|upc-lib-optional-spec.html#64">|; 
$noresave{$key} = "$nosave";

$key = q/UPC_SET_STRONG_CA_SEMANTICS###3587/;
$index{$key} .= q|<A NAME="tex2html61" HREF="|."$dir".q|upc-lib-optional-spec.html#384">|; 
$noresave{$key} = "$nosave";

$key = q/upc_all_fread_list_shared###3626/;
$index{$key} .= q|<A NAME="tex2html91" HREF="|."$dir".q|upc-lib-optional-spec.html#637">|; 
$noresave{$key} = "$nosave";

$key = q/UPC_WRONLY###3549/;
$index{$key} .= q|<A NAME="tex2html30" HREF="|."$dir".q|upc-lib-optional-spec.html#171">|; 
$noresave{$key} = "$nosave";

$key = q/upc_all_fwrite_list_local###3629/;
$index{$key} .= q|<A NAME="tex2html93" HREF="|."$dir".q|upc-lib-optional-spec.html#659">|; 
$noresave{$key} = "$nosave";

$key = q/common file pointer###3538/;
$index{$key} .= q|<A NAME="tex2html23" HREF="|."$dir".q|upc-lib-optional-spec.html#163">|; 
$noresave{$key} = "$nosave";

$key = q/individual file pointer###3520/;
$index{$key} .= q|<A NAME="tex2html10" HREF="|."$dir".q|upc-lib-optional-spec.html#85">|; 
$noresave{$key} = "$nosave";

$key = q/upc_all_fwait_async###3524/;
$index{$key} .= q|<A NAME="tex2html13" HREF="|."$dir".q|upc-lib-optional-spec.html#99">|; 
$noresave{$key} = "$nosave";

$key = q/UPC_TRUNC###3557/;
$index{$key} .= q|<A NAME="tex2html38" HREF="|."$dir".q|upc-lib-optional-spec.html#179">|; 
$noresave{$key} = "$nosave";

$key = q/UPC_GET_FN###3595/;
$index{$key} .= q|<A NAME="tex2html69" HREF="|."$dir".q|upc-lib-optional-spec.html#422">|; 
$noresave{$key} = "$nosave";

$key = q/upc_all_fwrite_list_shared###3632/;
$index{$key} .= q|<A NAME="tex2html95" HREF="|."$dir".q|upc-lib-optional-spec.html#681">|; 
$noresave{$key} = "$nosave";

$key = q/file flush###3566/;
$index{$key} .= q|<A NAME="tex2html45" HREF="|."$dir".q|upc-lib-optional-spec.html#283">|; 
$noresave{$key} = "$nosave";

$key = q/UPC_COMMON_FP###3551/;
$index{$key} .= q|<A NAME="tex2html32" HREF="|."$dir".q|upc-lib-optional-spec.html#173">|; 
$noresave{$key} = "$nosave";

$key = q/end of file###3576/;
$index{$key} .= q|<A NAME="tex2html53" HREF="|."$dir".q|upc-lib-optional-spec.html#315">|; 
$noresave{$key} = "$nosave";

$key = q/upc_hint###3596/;
$index{$key} .= q|<A NAME="tex2html70" HREF="|."$dir".q|upc-lib-optional-spec.html#432">|; 
$noresave{$key} = "$nosave";

$key = q/file reading###3605/;
$index{$key} .= q|<A NAME="tex2html78" HREF="|."$dir".q|upc-lib-optional-spec.html#468">|; 
$noresave{$key} = "$nosave";

$key = q/file reading###3625/;
$index{$key} .= q|<A NAME="tex2html90" HREF="|."$dir".q|upc-lib-optional-spec.html#636">|; 
$noresave{$key} = "$nosave";

$key = q/UPC_GET_CA_SEMANTICS###3585/;
$index{$key} .= q|<A NAME="tex2html59" HREF="|."$dir".q|upc-lib-optional-spec.html#371">|; 
$noresave{$key} = "$nosave";

$key = q/upc_file_t###3535/;
$index{$key} .= q|<A NAME="tex2html21" HREF="|."$dir".q|upc-lib-optional-spec.html#148">|; 
$noresave{$key} = "$nosave";

$key = q/UPC_SEEK_END###3572/;
$index{$key} .= q|<A NAME="tex2html50" HREF="|."$dir".q|upc-lib-optional-spec.html#304">|; 
$noresave{$key} = "$nosave";

$key = q/file size###3575/;
$index{$key} .= q|<A NAME="tex2html52" HREF="|."$dir".q|upc-lib-optional-spec.html#314">|; 
$noresave{$key} = "$nosave";

$key = q/upc_all_fwrite_shared###3615/;
$index{$key} .= q|<A NAME="tex2html83" HREF="|."$dir".q|upc-lib-optional-spec.html#548">|; 
$noresave{$key} = "$nosave";

$key = q/UPC_CREATE###3554/;
$index{$key} .= q|<A NAME="tex2html35" HREF="|."$dir".q|upc-lib-optional-spec.html#176">|; 
$noresave{$key} = "$nosave";

$key = q/upc_all_fclose###3562/;
$index{$key} .= q|<A NAME="tex2html42" HREF="|."$dir".q|upc-lib-optional-spec.html#265">|; 
$noresave{$key} = "$nosave";

$key = q/upc_all_ftest_async###3659/;
$index{$key} .= q|<A NAME="tex2html111" HREF="|."$dir".q|upc-lib-optional-spec.html#817">|; 
$noresave{$key} = "$nosave";

$key = q/upc_all_fcntl###3584/;
$index{$key} .= q|<A NAME="tex2html58" HREF="|."$dir".q|upc-lib-optional-spec.html#361">|; 
$noresave{$key} = "$nosave";

$key = q/upc_all_fsync###3565/;
$index{$key} .= q|<A NAME="tex2html44" HREF="|."$dir".q|upc-lib-optional-spec.html#282">|; 
$noresave{$key} = "$nosave";

$key = q/list I\/O###3617/;
$index{$key} .= q|<A NAME="tex2html84" HREF="|."$dir".q|upc-lib-optional-spec.html#579">|; 
$noresave{$key} = "$nosave";

$key = q/UPC_SEEK_CUR###3571/;
$index{$key} .= q|<A NAME="tex2html49" HREF="|."$dir".q|upc-lib-optional-spec.html#303">|; 
$noresave{$key} = "$nosave";

$key = q/file pointer###3518/;
$index{$key} .= q|<A NAME="tex2html8" HREF="|."$dir".q|upc-lib-optional-spec.html#83">|; 
$noresave{$key} = "$nosave";

$key = q/UPC_STRONG_CA###3529/;
$index{$key} .= q|<A NAME="tex2html17" HREF="|."$dir".q|upc-lib-optional-spec.html#121">|; 
$noresave{$key} = "$nosave";

$key = q/upc_all_fread_list_shared_async###3650/;
$index{$key} .= q|<A NAME="tex2html106" HREF="|."$dir".q|upc-lib-optional-spec.html#773">|; 
$noresave{$key} = "$nosave";

$key = q/upc_all_fpreallocate###3581/;
$index{$key} .= q|<A NAME="tex2html56" HREF="|."$dir".q|upc-lib-optional-spec.html#345">|; 
$noresave{$key} = "$nosave";

$key = q/file atomicity###3603/;
$index{$key} .= q|<A NAME="tex2html77" HREF="|."$dir".q|upc-lib-optional-spec.html#459">|; 
$noresave{$key} = "$nosave";

$key = q/__UPC_IO__###3509/;
$index{$key} .= q|<A NAME="tex2html1" HREF="|."$dir".q|upc-lib-optional-spec.html#53">|; 
$noresave{$key} = "$nosave";

$key = q/file size###3579/;
$index{$key} .= q|<A NAME="tex2html55" HREF="|."$dir".q|upc-lib-optional-spec.html#335">|; 
$noresave{$key} = "$nosave";

$key = q/upc_hint###3559/;
$index{$key} .= q|<A NAME="tex2html40" HREF="|."$dir".q|upc-lib-optional-spec.html#225">|; 
$noresave{$key} = "$nosave";

$key = q/upc_shared_memvec###3619/;
$index{$key} .= q|<A NAME="tex2html86" HREF="|."$dir".q|upc-lib-optional-spec.html#582">|; 
$noresave{$key} = "$nosave";

$key = q/upc_all_fread_shared###3609/;
$index{$key} .= q|<A NAME="tex2html80" HREF="|."$dir".q|upc-lib-optional-spec.html#491">|; 
$noresave{$key} = "$nosave";

$key = q/UPC_INDIVIDUAL_FP###3552/;
$index{$key} .= q|<A NAME="tex2html33" HREF="|."$dir".q|upc-lib-optional-spec.html#174">|; 
$noresave{$key} = "$nosave";

$key = q/UPC_SET_COMMON_FP###3592/;
$index{$key} .= q|<A NAME="tex2html66" HREF="|."$dir".q|upc-lib-optional-spec.html#400">|; 
$noresave{$key} = "$nosave";

$key = q/upc_all_fread_local###3607/;
$index{$key} .= q|<A NAME="tex2html79" HREF="|."$dir".q|upc-lib-optional-spec.html#473">|; 
$noresave{$key} = "$nosave";

$key = q/UPC_SEEK_SET###3570/;
$index{$key} .= q|<A NAME="tex2html48" HREF="|."$dir".q|upc-lib-optional-spec.html#302">|; 
$noresave{$key} = "$nosave";

$key = q/upc_all_fopen###3547/;
$index{$key} .= q|<A NAME="tex2html28" HREF="|."$dir".q|upc-lib-optional-spec.html#169">|; 
$noresave{$key} = "$nosave";

$key = q/upc_all_fread_list_local_async###3648/;
$index{$key} .= q|<A NAME="tex2html105" HREF="|."$dir".q|upc-lib-optional-spec.html#762">|; 
$noresave{$key} = "$nosave";

$key = q/upc_all_fget_size###3578/;
$index{$key} .= q|<A NAME="tex2html54" HREF="|."$dir".q|upc-lib-optional-spec.html#334">|; 
$noresave{$key} = "$nosave";

$key = q/upc_all_fread_shared_async###3642/;
$index{$key} .= q|<A NAME="tex2html102" HREF="|."$dir".q|upc-lib-optional-spec.html#729">|; 
$noresave{$key} = "$nosave";

$key = q/UPC_SET_INDIVIDUAL_FP###3593/;
$index{$key} .= q|<A NAME="tex2html67" HREF="|."$dir".q|upc-lib-optional-spec.html#407">|; 
$noresave{$key} = "$nosave";

$key = q/individual file pointer###3590/;
$index{$key} .= q|<A NAME="tex2html64" HREF="|."$dir".q|upc-lib-optional-spec.html#393">|; 
$noresave{$key} = "$nosave";

$key = q/UPC_RDWR###3550/;
$index{$key} .= q|<A NAME="tex2html31" HREF="|."$dir".q|upc-lib-optional-spec.html#172">|; 
$noresave{$key} = "$nosave";

$key = q/upc_all_fwrite_list_local_async###3652/;
$index{$key} .= q|<A NAME="tex2html107" HREF="|."$dir".q|upc-lib-optional-spec.html#784">|; 
$noresave{$key} = "$nosave";

$key = q/file reading###3635/;
$index{$key} .= q|<A NAME="tex2html97" HREF="|."$dir".q|upc-lib-optional-spec.html#702">|; 
$noresave{$key} = "$nosave";

$key = q/upc_all_ftest_async###3638/;
$index{$key} .= q|<A NAME="tex2html100" HREF="|."$dir".q|upc-lib-optional-spec.html#706">|; 
$noresave{$key} = "$nosave";

$key = q/file consistency###3526/;
$index{$key} .= q|<A NAME="tex2html14" HREF="|."$dir".q|upc-lib-optional-spec.html#104">|; 
$noresave{$key} = "$nosave";

$key = q/upc_io.h###3510/;
$index{$key} .= q|<A NAME="tex2html2" HREF="|."$dir".q|upc-lib-optional-spec.html#54">|; 
$noresave{$key} = "$nosave";

$key = q/UPC_SET_STRONG_CA_SEMANTICS###3530/;
$index{$key} .= q|<A NAME="tex2html18" HREF="|."$dir".q|upc-lib-optional-spec.html#122">|; 
$noresave{$key} = "$nosave";

$key = q/asynchronous I\/O###3600/;
$index{$key} .= q|<A NAME="tex2html74" HREF="|."$dir".q|upc-lib-optional-spec.html#453">|; 
$noresave{$key} = "$nosave";

$key = q/upc_all_fwrite_local_async###3644/;
$index{$key} .= q|<A NAME="tex2html103" HREF="|."$dir".q|upc-lib-optional-spec.html#740">|; 
$noresave{$key} = "$nosave";

$key = q/UPC_DELETE_ON_CLOSE###3558/;
$index{$key} .= q|<A NAME="tex2html39" HREF="|."$dir".q|upc-lib-optional-spec.html#180">|; 
$noresave{$key} = "$nosave";

$key = q/UPC_GET_FP###3591/;
$index{$key} .= q|<A NAME="tex2html65" HREF="|."$dir".q|upc-lib-optional-spec.html#394">|; 
$noresave{$key} = "$nosave";

$key = q/file size###3582/;
$index{$key} .= q|<A NAME="tex2html57" HREF="|."$dir".q|upc-lib-optional-spec.html#346">|; 
$noresave{$key} = "$nosave";

$key = q/upc_flag_t###3512/;
$index{$key} .= q|<A NAME="tex2html4" HREF="|."$dir".q|upc-lib-optional-spec.html#57">|; 
$noresave{$key} = "$nosave";

$key = q/UPC_ASYNC_OUTSTANDING###3601/;
$index{$key} .= q|<A NAME="tex2html75" HREF="|."$dir".q|upc-lib-optional-spec.html#454">|; 
$noresave{$key} = "$nosave";

$key = q/file consistency###3514/;
$index{$key} .= q|<A NAME="tex2html6" HREF="|."$dir".q|upc-lib-optional-spec.html#71">|; 
$noresave{$key} = "$nosave";

$key = q/upc_all_fwrite_list_shared_async###3654/;
$index{$key} .= q|<A NAME="tex2html108" HREF="|."$dir".q|upc-lib-optional-spec.html#795">|; 
$noresave{$key} = "$nosave";

$key = q/upc_filevec###3620/;
$index{$key} .= q|<A NAME="tex2html87" HREF="|."$dir".q|upc-lib-optional-spec.html#583">|; 
$noresave{$key} = "$nosave";
