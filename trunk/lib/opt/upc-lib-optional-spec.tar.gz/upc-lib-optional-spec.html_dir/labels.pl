# LaTeX2HTML 2008 (1.71)
# Associate labels original text with physical files.


$key = q/upc-io-common/;
$external_labels{$key} = "$URL/" . q|upc-lib-optional-spec.html|; 
$noresave{$key} = "$nosave";

$key = q/io-func-read/;
$external_labels{$key} = "$URL/" . q|upc-lib-optional-spec.html|; 
$noresave{$key} = "$nosave";

$key = q/io-func-write/;
$external_labels{$key} = "$URL/" . q|upc-lib-optional-spec.html|; 
$noresave{$key} = "$nosave";

$key = q/io-func-open/;
$external_labels{$key} = "$URL/" . q|upc-lib-optional-spec.html|; 
$noresave{$key} = "$nosave";

$key = q/io-func-list/;
$external_labels{$key} = "$URL/" . q|upc-lib-optional-spec.html|; 
$noresave{$key} = "$nosave";

1;


# LaTeX2HTML 2008 (1.71)
# labels from external_latex_labels array.


$key = q/upc-io-common/;
$external_latex_labels{$key} = q|7.4.3|; 
$noresave{$key} = "$nosave";

$key = q/io-func-read/;
$external_latex_labels{$key} = q|7.4.4|; 
$noresave{$key} = "$nosave";

$key = q/io-func-write/;
$external_latex_labels{$key} = q|7.4.5|; 
$noresave{$key} = "$nosave";

$key = q/io-func-open/;
$external_latex_labels{$key} = q|7.4.3.1|; 
$noresave{$key} = "$nosave";

$key = q/io-func-list/;
$external_latex_labels{$key} = q|7.4.6|; 
$noresave{$key} = "$nosave";

1;

