# LaTeX2HTML 2008 (1.71)
# Associate contents original text with physical files.


$key = q/0 0 0 12 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '4%:%'."$dir".q|upc-lang-spec.html%:%B..3 Consistency Semantics of Standard Libraries and Language Operations| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '3%:%'."$dir".q|upc-lang-spec.html%:%Acknowledgments%:%<tex2html_star_mark>| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 0 6 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '4%:%'."$dir".q|upc-lang-spec.html%:%3.2 object| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 0 15 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '3%:%'."$dir".q|upc-lang-spec.html%:%Index| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 0 10 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '4%:%'."$dir".q|upc-lang-spec.html%:%7.3 UPC Collective Utilities ;SPMlt;upc_collective.h;SPMgt;| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 0 12 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '4%:%'."$dir".q|upc-lang-spec.html%:%B..4 Properties Implied by the Specification| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 0 6 8 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '4%:%'."$dir".q|upc-lang-spec.html%:%3.8 single-valued| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 0 6 5 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '4%:%'."$dir".q|upc-lang-spec.html%:%3.5 pointer-to-local| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 0 14 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '3%:%'."$dir".q|upc-lang-spec.html%:%References%:%<tex2html_star_mark>| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 0 9 7 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '4%:%'."$dir".q|upc-lang-spec.html%:%6.7 Preprocessing directives| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 0 12 6 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '4%:%'."$dir".q|upc-lang-spec.html%:%B..6 Formal Definition of Precedes| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 0 10 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '4%:%'."$dir".q|upc-lang-spec.html%:%7.1 Standard headers| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 0 10 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '4%:%'."$dir".q|upc-lang-spec.html%:%7.2 UPC utilities ;SPMlt;upc.h;SPMgt;| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 0 6 6 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '4%:%'."$dir".q|upc-lang-spec.html%:%3.6 access| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 0 7 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '3%:%'."$dir".q|upc-lang-spec.html%:%4 Conformance| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 0 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '3%:%'."$dir".q|upc-lang-spec.html%:%1 Scope| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 0 12 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '3%:%'."$dir".q|upc-lang-spec.html%:%B. Formal UPC Memory Consistency Semantics| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 0 9 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '4%:%'."$dir".q|upc-lang-spec.html%:%6.3 Predefined identifiers| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 0 16 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '3%:%'."$dir".q|upc-lang-spec.html%:%About this document ...%:%<tex2html_star_mark>| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 0 9 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '4%:%'."$dir".q|upc-lang-spec.html%:%6.1 Notations| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 0 6 7 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '4%:%'."$dir".q|upc-lang-spec.html%:%3.7 collective| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 0 6 9 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '4%:%'."$dir".q|upc-lang-spec.html%:%3.9 phase| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 0 12 5 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '4%:%'."$dir".q|upc-lang-spec.html%:%B..5 Examples| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 0 9 5 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '4%:%'."$dir".q|upc-lang-spec.html%:%6.5 Declarations| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 0 9 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '3%:%'."$dir".q|upc-lang-spec.html%:%6 Language| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 0 9 6 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '4%:%'."$dir".q|upc-lang-spec.html%:%6.6 Statements and blocks| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 0 11 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '3%:%'."$dir".q|upc-lang-spec.html%:%A. Proposed Additions and Extensions| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 0 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '3%:%'."$dir".q|upc-lang-spec.html%:%Introduction%:%<tex2html_star_mark>| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 0 13 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '3%:%'."$dir".q|upc-lang-spec.html%:%C. UPC versus C Standard Section Numbering| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 0 6 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '3%:%'."$dir".q|upc-lang-spec.html%:%3 Terms, definitions and symbols| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 0 11 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '4%:%'."$dir".q|upc-lang-spec.html%:%A..1 UPC Parallel I/O ;SPMlt;upc_io.h;SPMgt;| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 0 8 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '4%:%'."$dir".q|upc-lang-spec.html%:%5.1 Conceptual models| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 0 12 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '4%:%'."$dir".q|upc-lang-spec.html%:%B..2 Memory Access Model| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '0%:%'."$dir".q|upc-lang-spec.html%:%UPC Language Specifications
V1.2 | unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 0 9 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '4%:%'."$dir".q|upc-lang-spec.html%:%6.2 Keywords| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 0 12 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '4%:%'."$dir".q|upc-lang-spec.html%:%B..1 Definitions| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 0 10 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '3%:%'."$dir".q|upc-lang-spec.html%:%7 Library| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 0 9 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '4%:%'."$dir".q|upc-lang-spec.html%:%6.4 Expressions| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 0 8 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '3%:%'."$dir".q|upc-lang-spec.html%:%5 Environment| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 0 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '3%:%'."$dir".q|upc-lang-spec.html%:%Contents| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 0 5 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '3%:%'."$dir".q|upc-lang-spec.html%:%2 Normative references| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 0 6 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '4%:%'."$dir".q|upc-lang-spec.html%:%3.1 thread| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 0 6 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '4%:%'."$dir".q|upc-lang-spec.html%:%3.3 affinity| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 0 6 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '4%:%'."$dir".q|upc-lang-spec.html%:%3.4 pointer-to-shared| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

1;

