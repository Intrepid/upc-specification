# LaTeX2HTML 2008 (1.71)
# Associate index original text with physical files.


$key = q/individual file pointer/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1565">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#1644">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">3</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#1873">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">8</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_global_alloc/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#809"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_all_fwait_async/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1579">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#2185">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">7</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#2286">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">9</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/shared layout qualifier/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#374"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">5</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_all_fread_list_shared/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#2117">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/shared object, clearing/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1093"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">5</SPAN>.<SPAN CLASS="arabic">4</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/keywords/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#167"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/dependsonthreads/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#2357">B..<SPAN CLASS="arabic">2</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_logor/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1382"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/shared access/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#3196"><SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#133"><SPAN CLASS="arabic">5</SPAN>.<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">3</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#743"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#2319">B..<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_all_fpreallocate/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1825">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">7</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_max_block_size/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#174"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#205"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">3</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#763"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_all_scatter/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1206"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_rdonly/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1650">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_all_fread_local/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1953">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">4</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_all_fset_size/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1793">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">5</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_all_fget_size/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1814">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">6</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/shared object, allocation/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#805"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/relaxed/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#172"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#341"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">5</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#373"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">5</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#742"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_global_exit/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#123"><SPAN CLASS="arabic">5</SPAN>.<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#798"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_local_alloc/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#851"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">4</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/reduction/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1424"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_all_fsync/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1589">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">3</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#1762">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">3</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_local_memvec/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#2061">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">6</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_collective.h/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1164"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">3</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/synchronization/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#92"><SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#573"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#954"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">4</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_individual_fp/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1654">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_append/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1655">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_filevec/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#2063">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">6</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_off_t/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1625">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_memcpy/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1043"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">5</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_seek_set/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1782">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">4</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/relaxed shared write/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#3240"><SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">4</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#137"><SPAN CLASS="arabic">5</SPAN>.<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">3</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#747"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#2323">B..<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/memory consistency, collective library/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#2416">B..<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_unlock/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1030"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">4</SPAN>.<SPAN CLASS="arabic">7</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/memory consistency, barriers/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#2389">B..<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_all_lock_alloc/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#980"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">4</SPAN>.<SPAN CLASS="arabic">3</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_all_fread_list_local/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#2097">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_all_fread_shared/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1971">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">4</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_get_fl/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1894">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">8</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/phase/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#3284"><SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#289"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">4</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#897"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#908"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">3</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_notify/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#177"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#576"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_set_hint/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1924">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">8</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_wronly/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1651">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/gather, to all/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1272"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">4</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/access/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#3185"><SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">6</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_func/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1385"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_seek_end/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1784">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">4</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_localsizeof/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#171"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#248"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">4</SPAN>.<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#927"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">5</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/sequential consistency/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#138"><SPAN CLASS="arabic">5</SPAN>.<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">3</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#2435">B..<SPAN CLASS="arabic">4</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/__upc_static_threads__/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#772"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_set_individual_fp/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1887">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">8</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_all_alloc/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#822"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/exchange/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1306"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">5</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_all_fwrite_local/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#2008">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">5</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_seek_cur/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1783">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">4</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_all_fwrite_shared/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#2028">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">5</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/file atomicity/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1552">A..<SPAN CLASS="arabic">1</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#1585">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">3</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#1939">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">8</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/shared object/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#3107"><SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/mythread/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#169"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#199"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#777"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_addrfield/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#285"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">4</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#917"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">4</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/collective/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#3262"><SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">7</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#580"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#791"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/exit/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#124"><SPAN CLASS="arabic">5</SPAN>.<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/pointer-to-shared/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#3163"><SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">4</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#280"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">4</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/pointer-to-local/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#3174"><SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">5</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#281"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">4</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_memput/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1076"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">5</SPAN>.<SPAN CLASS="arabic">3</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/file interoperability/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1619">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">4</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/shared/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#175"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/shared object, copying/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1039"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">5</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/strict shared write/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#3218"><SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#135"><SPAN CLASS="arabic">5</SPAN>.<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">3</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#745"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#2321">B..<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/struct field, address-of/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#333"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">4</SPAN>.<SPAN CLASS="arabic">4</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/indefinite block size/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#418"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">5</SPAN>.<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/pragmas/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#740"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/memory allocation/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#806"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_get_fn/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1902">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">8</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_add/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1376"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/pointer-to-shared, null/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#318"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">4</SPAN>.<SPAN CLASS="arabic">3</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/file flush/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1763">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">3</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_all_fwrite_shared_async/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#2231">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">4</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/dynamic threads environment/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#104"><SPAN CLASS="arabic">5</SPAN>.<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#500"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">5</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#769"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_free/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#865"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">5</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_min/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1383"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_all_reduce_prefix/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1423"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/global address space/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#62"><SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_op_t/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1375"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/block size/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#206"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">3</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#342"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">5</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/thread/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#3085"><SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_in_allsync/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1114"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">6</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_or/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1379"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_forall/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#182"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#679"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_mult/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1377"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/__upc_dynamic_threads__/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#768"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/pointer addition/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#282"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">4</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_out_nosync/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1113"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">6</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/file hints/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1706">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#1913">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">8</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/allstrict/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#2346">B..<SPAN CLASS="arabic">2</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#61"><SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/object/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#3096"><SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_lock_t/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#957"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">4</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/parallel loop/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#682"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_shared_memvec/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#2062">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">6</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/prefix reduction/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1425"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/feature macros/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1528">A.</A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/asynchronous i\/o/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1577">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#1933">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">8</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#2181">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">7</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/pointer-to-shared, generic/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#319"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">4</SPAN>.<SPAN CLASS="arabic">3</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/pointer-to-shared, conversion/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#317"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">4</SPAN>.<SPAN CLASS="arabic">3</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/blocking factor/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#420"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">5</SPAN>.<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_all_fwrite_list_local_async/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#2264">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">7</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_memset/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1092"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">5</SPAN>.<SPAN CLASS="arabic">4</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/__upc__/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#759"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_file_t/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1628">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_memget/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1059"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">5</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_all_fopen/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1649">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/file seek/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1775">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">4</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/shared declarations, examples/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#432"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">5</SPAN>.<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#511"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">5</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_resetphase/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#907"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">3</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/file open/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1648">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/file pointer/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1563">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#1642">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">3</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#1871">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">8</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/file reading/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1948">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">4</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#2096">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#2116">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#2182">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">7</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_lock_attempt/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1020"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">4</SPAN>.<SPAN CLASS="arabic">6</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_xor/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1380"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/shared array/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#3141"><SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">3</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/tokens/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#168"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_get_fp/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1874">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">8</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/end of file/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1544">A..<SPAN CLASS="arabic">1</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#1795">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">5</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/memory consistency, non-collective library/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#2406">B..<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_create/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1656">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_delete_on_close/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1660">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/null strict access/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#602"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/permute/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1340"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">6</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_strong_ca/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1601">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">3</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#1658">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_all_exchange/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1305"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">5</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/file close/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1746">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/memory consistency, examples/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#2454">B..<SPAN CLASS="arabic">5</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/list i\/o/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#2059">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">6</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_all_fread_list_local_async/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#2242">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">5</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_all_permute/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1339"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">6</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/local access/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#3251"><SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/work sharing/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#681"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_get_ca_semantics/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1851">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">8</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/synchronization phase/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#578"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/proposed extensions/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1522">A.</A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_all_reduce/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1422"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_all_fcntl/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1841">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">8</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/mutual exclusion/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#955"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">4</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/program startup/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#116"><SPAN CLASS="arabic">5</SPAN>.<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_all_gather/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1238"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">3</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_affinitysize/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#926"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">5</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/barriers/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#574"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_global_lock_alloc/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#970"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">4</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_all_broadcast/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1171"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/file consistency/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1551">A..<SPAN CLASS="arabic">1</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#1584">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">3</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#1938">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">8</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/strict/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#178"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#340"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">5</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#372"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">5</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#741"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_all_fclose/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1745">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_lock/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1008"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">4</SPAN>.<SPAN CLASS="arabic">5</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/block size, default/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#416"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">5</SPAN>.<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/strictonthreads/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#2345">B..<SPAN CLASS="arabic">2</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_in_mysync/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1115"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">6</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/shared declarations, scalar/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#496"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">5</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/strict shared read/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#3207"><SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#134"><SPAN CLASS="arabic">5</SPAN>.<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">3</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#744"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#2320">B..<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_and/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1378"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/pointer-to-shared, casts/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#316"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">4</SPAN>.<SPAN CLASS="arabic">3</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_blocksizeof/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#173"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#257"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">4</SPAN>.<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">3</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_hint/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1705">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#1912">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">8</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_threadof/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#284"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">4</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#883"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#896"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/program order/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#139"><SPAN CLASS="arabic">5</SPAN>.<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">3</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#2677">B..<SPAN CLASS="arabic">6</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_max/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1384"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/block size, conversion/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#320"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">4</SPAN>.<SPAN CLASS="arabic">3</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_all_ftest_async/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1578">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#2186">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">7</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#2297">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">10</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_all_fwrite_list_shared/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#2161">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">4</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/__upc_version__/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#761"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_lock_free/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#990"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">4</SPAN>.<SPAN CLASS="arabic">4</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/precedes/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#2676">B..<SPAN CLASS="arabic">6</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_get_hints/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1914">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">8</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/__upc_io__/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1533">A..<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_rdwr/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1652">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_all_fread_local_async/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#2198">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_in_nosync/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1116"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">6</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/memory consistency/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#132"><SPAN CLASS="arabic">5</SPAN>.<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">3</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#579"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#1110"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">6</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#2315">B.</A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/common file pointer/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1564">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#1643">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">3</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#1872">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">8</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_io.h/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1534">A..<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_relaxed.h/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#788"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_excl/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1657">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_all_fwrite_list_local/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#2139">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">3</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_all_fwrite_local_async/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#2220">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">3</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_trunc/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1659">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_set_weak_ca_semantics/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1857">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">8</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_barrier/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#170"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#575"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_async_outstanding/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1934">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">8</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/file writing/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#2003">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">5</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#2138">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">3</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#2160">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">4</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#2183">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">7</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/locks/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#953"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">4</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/definite block size/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#419"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">5</SPAN>.<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#425"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">5</SPAN>.<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_logand/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1381"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_all_fwrite_list_shared_async/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#2275">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">8</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/predefined macros/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#755"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/sizeof/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#243"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">4</SPAN>.<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/broadcast/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1172"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/shared declarations, array/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#499"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">5</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/block size, definite/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#415"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">5</SPAN>.<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/__upc_collective__/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1163"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">3</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_all_gather_all/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1271"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">4</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_set_common_fp/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1880">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">8</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/implicit barriers/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#109"><SPAN CLASS="arabic">5</SPAN>.<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#581"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_out_mysync/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1112"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">6</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_elemsizeof/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#176"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#270"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">4</SPAN>.<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">4</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_phaseof/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#283"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">4</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#508"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">5</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/file size/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1794">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">5</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#1815">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">6</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#1826">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">7</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/memory copy/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1040"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">5</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/block size, automatically-computed/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#417"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">5</SPAN>.<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/main/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#117"><SPAN CLASS="arabic">5</SPAN>.<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_out_allsync/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1111"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">6</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_common_fp/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1653">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/program termination/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#122"><SPAN CLASS="arabic">5</SPAN>.<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/private object/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#3124"><SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_strict.h/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#785"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/continue/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#680"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_all_fread_list_shared_async/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#2253">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">6</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/shared declarations, restrictions/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#491"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">5</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_noncomm_func/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1386"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/block size, indefinite/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#414"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">5</SPAN>.<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/pointer equality/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#286"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">4</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/pointer-to-shared, type compatibility/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#426"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">5</SPAN>.<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/affinity/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#3152"><SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">3</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#288"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">4</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#884"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_all_fread_shared_async/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#2209">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/strictpairs/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#2344">B..<SPAN CLASS="arabic">2</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/potentialraces/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#2441">B..<SPAN CLASS="arabic">4</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/indefinite/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#423"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">5</SPAN>.<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/memory consistency, fence/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#2390">B..<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_wait/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#180"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#577"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/collective libarary/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1162"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">3</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/static threads environment/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#103"><SPAN CLASS="arabic">5</SPAN>.<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#501"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">5</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#773"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/data races/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#140"><SPAN CLASS="arabic">5</SPAN>.<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">3</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_all_fseek/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1774">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">4</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_flag_t/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1117"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">6</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#1537">A..<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_alloc/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#838"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">3</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_fence/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#179"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#597"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/thread creation/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#108"><SPAN CLASS="arabic">5</SPAN>.<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/memory consistency, locks/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#2388">B..<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/scatter/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1207"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_set_strong_ca_semantics/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1602">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">3</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#1864">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">8</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/threads/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#181"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#194"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#776"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/iso c/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#60"><SPAN CLASS="arabic">1</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#64"><SPAN CLASS="arabic">2</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/gather/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1239"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">3</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/relaxed shared read/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#3229"><SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">3</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#136"><SPAN CLASS="arabic">5</SPAN>.<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">3</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#746"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#2322">B..<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/block size, declaration/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#445"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">5</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/conflicting/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#2356">B..<SPAN CLASS="arabic">2</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/pointer subtraction/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#287"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">4</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/single-valued/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#3273"><SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

# LaTeX2HTML 2008 (1.71)
# Printable index-keys from printable_key array.


$key = q/individual file pointer/;
$printable_key{$key} = q|individual file pointer| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_global_alloc/;
$printable_key{$key} = q|upc_global_alloc| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_all_fwait_async/;
$printable_key{$key} = q|upc_all_fwait_async| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/shared layout qualifier/;
$printable_key{$key} = q|shared layout qualifier| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_all_fread_list_shared/;
$printable_key{$key} = q|upc_all_fread_list_shared| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/shared object, clearing/;
$printable_key{$key} = q|shared object, clearing| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/keywords/;
$printable_key{$key} = q|keywords| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/dependsonthreads/;
$printable_key{$key} = q|DependsOnThreads| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_logor/;
$printable_key{$key} = q|UPC_LOGOR| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/shared access/;
$printable_key{$key} = q|shared access| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_all_fpreallocate/;
$printable_key{$key} = q|upc_all_fpreallocate| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_max_block_size/;
$printable_key{$key} = q|UPC_MAX_BLOCK_SIZE| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_all_scatter/;
$printable_key{$key} = q|upc_all_scatter| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_rdonly/;
$printable_key{$key} = q|UPC_RDONLY| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_all_fread_local/;
$printable_key{$key} = q|upc_all_fread_local| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_all_fset_size/;
$printable_key{$key} = q|upc_all_fset_size| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_all_fget_size/;
$printable_key{$key} = q|upc_all_fget_size| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/shared object, allocation/;
$printable_key{$key} = q|shared object, allocation| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/relaxed/;
$printable_key{$key} = q|relaxed| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_global_exit/;
$printable_key{$key} = q|upc_global_exit| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_local_alloc/;
$printable_key{$key} = q|upc_local_alloc| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/reduction/;
$printable_key{$key} = q|reduction| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_all_fsync/;
$printable_key{$key} = q|upc_all_fsync| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_local_memvec/;
$printable_key{$key} = q|upc_local_memvec| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_collective.h/;
$printable_key{$key} = q|upc_collective.h| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/synchronization/;
$printable_key{$key} = q|synchronization| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_individual_fp/;
$printable_key{$key} = q|UPC_INDIVIDUAL_FP| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_append/;
$printable_key{$key} = q|UPC_APPEND| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_filevec/;
$printable_key{$key} = q|upc_filevec| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_off_t/;
$printable_key{$key} = q|upc_off_t| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_memcpy/;
$printable_key{$key} = q|upc_memcpy| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_seek_set/;
$printable_key{$key} = q|UPC_SEEK_SET| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/relaxed shared write/;
$printable_key{$key} = q|relaxed shared write| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/memory consistency, collective library/;
$printable_key{$key} = q|memory consistency, collective library| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_unlock/;
$printable_key{$key} = q|upc_unlock| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/memory consistency, barriers/;
$printable_key{$key} = q|memory consistency, barriers| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_all_lock_alloc/;
$printable_key{$key} = q|upc_all_lock_alloc| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_all_fread_list_local/;
$printable_key{$key} = q|upc_all_fread_list_local| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_all_fread_shared/;
$printable_key{$key} = q|upc_all_fread_shared| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_get_fl/;
$printable_key{$key} = q|UPC_GET_FL| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/phase/;
$printable_key{$key} = q|phase| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_notify/;
$printable_key{$key} = q|upc_notify| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_set_hint/;
$printable_key{$key} = q|UPC_SET_HINT| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_wronly/;
$printable_key{$key} = q|UPC_WRONLY| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/gather, to all/;
$printable_key{$key} = q|gather, to all| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/access/;
$printable_key{$key} = q|access| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_func/;
$printable_key{$key} = q|UPC_FUNC| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_seek_end/;
$printable_key{$key} = q|UPC_SEEK_END| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_localsizeof/;
$printable_key{$key} = q|upc_localsizeof| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/sequential consistency/;
$printable_key{$key} = q|sequential consistency| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/__upc_static_threads__/;
$printable_key{$key} = q|__UPC_STATIC_THREADS__| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_set_individual_fp/;
$printable_key{$key} = q|UPC_SET_INDIVIDUAL_FP| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_all_alloc/;
$printable_key{$key} = q|upc_all_alloc| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/exchange/;
$printable_key{$key} = q|exchange| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_all_fwrite_local/;
$printable_key{$key} = q|upc_all_fwrite_local| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_seek_cur/;
$printable_key{$key} = q|UPC_SEEK_CUR| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_all_fwrite_shared/;
$printable_key{$key} = q|upc_all_fwrite_shared| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/file atomicity/;
$printable_key{$key} = q|file atomicity| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/shared object/;
$printable_key{$key} = q|shared object| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/mythread/;
$printable_key{$key} = q|MYTHREAD| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_addrfield/;
$printable_key{$key} = q|upc_addrfield| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/collective/;
$printable_key{$key} = q|collective| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/exit/;
$printable_key{$key} = q|exit| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/pointer-to-shared/;
$printable_key{$key} = q|pointer-to-shared| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/pointer-to-local/;
$printable_key{$key} = q|pointer-to-local| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_memput/;
$printable_key{$key} = q|upc_memput| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/file interoperability/;
$printable_key{$key} = q|file interoperability| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/shared/;
$printable_key{$key} = q|shared| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/shared object, copying/;
$printable_key{$key} = q|shared object, copying| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/strict shared write/;
$printable_key{$key} = q|strict shared write| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/struct field, address-of/;
$printable_key{$key} = q|struct field, address-of| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/indefinite block size/;
$printable_key{$key} = q|indefinite block size| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/pragmas/;
$printable_key{$key} = q|pragmas| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/memory allocation/;
$printable_key{$key} = q|memory allocation| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_get_fn/;
$printable_key{$key} = q|UPC_GET_FN| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_add/;
$printable_key{$key} = q|UPC_ADD| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/pointer-to-shared, null/;
$printable_key{$key} = q|pointer-to-shared, null| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/file flush/;
$printable_key{$key} = q|file flush| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_all_fwrite_shared_async/;
$printable_key{$key} = q|upc_all_fwrite_shared_async| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/dynamic threads environment/;
$printable_key{$key} = q|dynamic THREADS environment| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_free/;
$printable_key{$key} = q|upc_free| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_min/;
$printable_key{$key} = q|UPC_MIN| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_all_reduce_prefix/;
$printable_key{$key} = q|upc_all_reduce_prefix| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/global address space/;
$printable_key{$key} = q|global address space| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_op_t/;
$printable_key{$key} = q|upc_op_t| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/block size/;
$printable_key{$key} = q|block size| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/thread/;
$printable_key{$key} = q|thread| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_in_allsync/;
$printable_key{$key} = q|UPC_IN_ALLSYNC| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_or/;
$printable_key{$key} = q|UPC_OR| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_forall/;
$printable_key{$key} = q|upc_forall| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_mult/;
$printable_key{$key} = q|UPC_MULT| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/__upc_dynamic_threads__/;
$printable_key{$key} = q|__UPC_DYNAMIC_THREADS__| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/pointer addition/;
$printable_key{$key} = q|pointer addition| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_out_nosync/;
$printable_key{$key} = q|UPC_OUT_NOSYNC| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/file hints/;
$printable_key{$key} = q|file hints| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/allstrict/;
$printable_key{$key} = q|AllStrict| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc/;
$printable_key{$key} = q|UPC| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/object/;
$printable_key{$key} = q|object| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_lock_t/;
$printable_key{$key} = q|upc_lock_t| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/parallel loop/;
$printable_key{$key} = q|parallel loop| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_shared_memvec/;
$printable_key{$key} = q|upc_shared_memvec| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/prefix reduction/;
$printable_key{$key} = q|prefix reduction| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/feature macros/;
$printable_key{$key} = q|feature macros| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/asynchronous i\/o/;
$printable_key{$key} = q|asynchronous I/O| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/pointer-to-shared, generic/;
$printable_key{$key} = q|pointer-to-shared, generic| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/pointer-to-shared, conversion/;
$printable_key{$key} = q|pointer-to-shared, conversion| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/blocking factor/;
$printable_key{$key} = q|blocking factor| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_all_fwrite_list_local_async/;
$printable_key{$key} = q|upc_all_fwrite_list_local_async| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_memset/;
$printable_key{$key} = q|upc_memset| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/__upc__/;
$printable_key{$key} = q|__UPC__| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_file_t/;
$printable_key{$key} = q|upc_file_t| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_memget/;
$printable_key{$key} = q|upc_memget| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_all_fopen/;
$printable_key{$key} = q|upc_all_fopen| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/file seek/;
$printable_key{$key} = q|file seek| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/shared declarations, examples/;
$printable_key{$key} = q|shared declarations, examples| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_resetphase/;
$printable_key{$key} = q|upc_resetphase| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/file open/;
$printable_key{$key} = q|file open| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/file pointer/;
$printable_key{$key} = q|file pointer| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/file reading/;
$printable_key{$key} = q|file reading| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_lock_attempt/;
$printable_key{$key} = q|upc_lock_attempt| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_xor/;
$printable_key{$key} = q|UPC_XOR| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/shared array/;
$printable_key{$key} = q|shared array| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/tokens/;
$printable_key{$key} = q|tokens| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_get_fp/;
$printable_key{$key} = q|UPC_GET_FP| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/end of file/;
$printable_key{$key} = q|end of file| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/memory consistency, non-collective library/;
$printable_key{$key} = q|memory consistency, non-collective library| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_create/;
$printable_key{$key} = q|UPC_CREATE| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_delete_on_close/;
$printable_key{$key} = q|UPC_DELETE_ON_CLOSE| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/null strict access/;
$printable_key{$key} = q|null strict access| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/permute/;
$printable_key{$key} = q|permute| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_strong_ca/;
$printable_key{$key} = q|UPC_STRONG_CA| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_all_exchange/;
$printable_key{$key} = q|upc_all_exchange| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/file close/;
$printable_key{$key} = q|file close| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/memory consistency, examples/;
$printable_key{$key} = q|memory consistency, examples| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/list i\/o/;
$printable_key{$key} = q|list I/O| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_all_fread_list_local_async/;
$printable_key{$key} = q|upc_all_fread_list_local_async| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_all_permute/;
$printable_key{$key} = q|upc_all_permute| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/local access/;
$printable_key{$key} = q|local access| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/work sharing/;
$printable_key{$key} = q|work sharing| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_get_ca_semantics/;
$printable_key{$key} = q|UPC_GET_CA_SEMANTICS| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/synchronization phase/;
$printable_key{$key} = q|synchronization phase| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/proposed extensions/;
$printable_key{$key} = q|proposed extensions| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_all_reduce/;
$printable_key{$key} = q|upc_all_reduce| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_all_fcntl/;
$printable_key{$key} = q|upc_all_fcntl| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/mutual exclusion/;
$printable_key{$key} = q|mutual exclusion| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/program startup/;
$printable_key{$key} = q|program startup| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_all_gather/;
$printable_key{$key} = q|upc_all_gather| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_affinitysize/;
$printable_key{$key} = q|upc_affinitysize| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/barriers/;
$printable_key{$key} = q|barriers| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_global_lock_alloc/;
$printable_key{$key} = q|upc_global_lock_alloc| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_all_broadcast/;
$printable_key{$key} = q|upc_all_broadcast| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/file consistency/;
$printable_key{$key} = q|file consistency| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/strict/;
$printable_key{$key} = q|strict| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_all_fclose/;
$printable_key{$key} = q|upc_all_fclose| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_lock/;
$printable_key{$key} = q|upc_lock| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/block size, default/;
$printable_key{$key} = q|block size, default| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/strictonthreads/;
$printable_key{$key} = q|StrictOnThreads| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_in_mysync/;
$printable_key{$key} = q|UPC_IN_MYSYNC| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/shared declarations, scalar/;
$printable_key{$key} = q|shared declarations, scalar| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/strict shared read/;
$printable_key{$key} = q|strict shared read| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_and/;
$printable_key{$key} = q|UPC_AND| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/pointer-to-shared, casts/;
$printable_key{$key} = q|pointer-to-shared, casts| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_blocksizeof/;
$printable_key{$key} = q|upc_blocksizeof| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_hint/;
$printable_key{$key} = q|upc_hint| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_threadof/;
$printable_key{$key} = q|upc_threadof| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/program order/;
$printable_key{$key} = q|program order| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_max/;
$printable_key{$key} = q|UPC_MAX| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/block size, conversion/;
$printable_key{$key} = q|block size, conversion| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_all_ftest_async/;
$printable_key{$key} = q|upc_all_ftest_async| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_all_fwrite_list_shared/;
$printable_key{$key} = q|upc_all_fwrite_list_shared| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/__upc_version__/;
$printable_key{$key} = q|__UPC_VERSION__| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_lock_free/;
$printable_key{$key} = q|upc_lock_free| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/precedes/;
$printable_key{$key} = q|Precedes| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_get_hints/;
$printable_key{$key} = q|UPC_GET_HINTS| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/__upc_io__/;
$printable_key{$key} = q|__UPC_IO__| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_rdwr/;
$printable_key{$key} = q|UPC_RDWR| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_all_fread_local_async/;
$printable_key{$key} = q|upc_all_fread_local_async| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_in_nosync/;
$printable_key{$key} = q|UPC_IN_NOSYNC| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/memory consistency/;
$printable_key{$key} = q|memory consistency| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/common file pointer/;
$printable_key{$key} = q|common file pointer| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_io.h/;
$printable_key{$key} = q|upc_io.h| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_relaxed.h/;
$printable_key{$key} = q|upc_relaxed.h| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_excl/;
$printable_key{$key} = q|UPC_EXCL| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_all_fwrite_list_local/;
$printable_key{$key} = q|upc_all_fwrite_list_local| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_all_fwrite_local_async/;
$printable_key{$key} = q|upc_all_fwrite_local_async| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_trunc/;
$printable_key{$key} = q|UPC_TRUNC| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_set_weak_ca_semantics/;
$printable_key{$key} = q|UPC_SET_WEAK_CA_SEMANTICS| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_barrier/;
$printable_key{$key} = q|upc_barrier| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_async_outstanding/;
$printable_key{$key} = q|UPC_ASYNC_OUTSTANDING| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/file writing/;
$printable_key{$key} = q|file writing| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/locks/;
$printable_key{$key} = q|locks| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/definite block size/;
$printable_key{$key} = q|definite block size| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_logand/;
$printable_key{$key} = q|UPC_LOGAND| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_all_fwrite_list_shared_async/;
$printable_key{$key} = q|upc_all_fwrite_list_shared_async| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/predefined macros/;
$printable_key{$key} = q|predefined macros| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/sizeof/;
$printable_key{$key} = q|sizeof| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/broadcast/;
$printable_key{$key} = q|broadcast| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/shared declarations, array/;
$printable_key{$key} = q|shared declarations, array| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/block size, definite/;
$printable_key{$key} = q|block size, definite| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/__upc_collective__/;
$printable_key{$key} = q|__UPC_COLLECTIVE__| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_all_gather_all/;
$printable_key{$key} = q|upc_all_gather_all| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_set_common_fp/;
$printable_key{$key} = q|UPC_SET_COMMON_FP| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/implicit barriers/;
$printable_key{$key} = q|implicit barriers| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_out_mysync/;
$printable_key{$key} = q|UPC_OUT_MYSYNC| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_elemsizeof/;
$printable_key{$key} = q|upc_elemsizeof| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_phaseof/;
$printable_key{$key} = q|upc_phaseof| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/file size/;
$printable_key{$key} = q|file size| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/memory copy/;
$printable_key{$key} = q|memory copy| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/block size, automatically-computed/;
$printable_key{$key} = q|block size, automatically-computed| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/main/;
$printable_key{$key} = q|main| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_out_allsync/;
$printable_key{$key} = q|UPC_OUT_ALLSYNC| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_common_fp/;
$printable_key{$key} = q|UPC_COMMON_FP| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/program termination/;
$printable_key{$key} = q|program termination| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/private object/;
$printable_key{$key} = q|private object| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_strict.h/;
$printable_key{$key} = q|upc_strict.h| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/continue/;
$printable_key{$key} = q|continue| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_all_fread_list_shared_async/;
$printable_key{$key} = q|upc_all_fread_list_shared_async| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/shared declarations, restrictions/;
$printable_key{$key} = q|shared declarations, restrictions| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_noncomm_func/;
$printable_key{$key} = q|UPC_NONCOMM_FUNC| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/block size, indefinite/;
$printable_key{$key} = q|block size, indefinite| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/pointer equality/;
$printable_key{$key} = q|pointer equality| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/pointer-to-shared, type compatibility/;
$printable_key{$key} = q|pointer-to-shared, type compatibility| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/affinity/;
$printable_key{$key} = q|affinity| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_all_fread_shared_async/;
$printable_key{$key} = q|upc_all_fread_shared_async| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/strictpairs/;
$printable_key{$key} = q|StrictPairs| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/potentialraces/;
$printable_key{$key} = q|PotentialRaces| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/indefinite/;
$printable_key{$key} = q|indefinite| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/memory consistency, fence/;
$printable_key{$key} = q|memory consistency, fence| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_wait/;
$printable_key{$key} = q|upc_wait| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/collective libarary/;
$printable_key{$key} = q|collective libarary| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/static threads environment/;
$printable_key{$key} = q|static THREADS environment| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/data races/;
$printable_key{$key} = q|data races| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_all_fseek/;
$printable_key{$key} = q|upc_all_fseek| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_flag_t/;
$printable_key{$key} = q|upc_flag_t| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_alloc/;
$printable_key{$key} = q|upc_alloc| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_fence/;
$printable_key{$key} = q|upc_fence| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/thread creation/;
$printable_key{$key} = q|thread creation| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/memory consistency, locks/;
$printable_key{$key} = q|memory consistency, locks| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/scatter/;
$printable_key{$key} = q|scatter| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_set_strong_ca_semantics/;
$printable_key{$key} = q|UPC_SET_STRONG_CA_SEMANTICS| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/threads/;
$printable_key{$key} = q|THREADS| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/iso c/;
$printable_key{$key} = q|ISO C| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/gather/;
$printable_key{$key} = q|gather| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/relaxed shared read/;
$printable_key{$key} = q|relaxed shared read| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/block size, declaration/;
$printable_key{$key} = q|block size, declaration| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/conflicting/;
$printable_key{$key} = q|Conflicting| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/pointer subtraction/;
$printable_key{$key} = q|pointer subtraction| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/single-valued/;
$printable_key{$key} = q|single-valued| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

1;

