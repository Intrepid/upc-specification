# LaTeX2HTML 2008 (1.71)
# Associate index original text with physical files.


$key = q/upc_threadof###7578/;
$index{$key} .= q|<A NAME="tex2html166" HREF="|."$dir".q|upc-lang-spec.html#2500">|; 
$noresave{$key} = "$nosave";

$key = q/synchronization###7496/;
$index{$key} .= q|<A NAME="tex2html113" HREF="|."$dir".q|upc-lang-spec.html#763">|; 
$noresave{$key} = "$nosave";

$key = q/upc_barrier###7498/;
$index{$key} .= q|<A NAME="tex2html115" HREF="|."$dir".q|upc-lang-spec.html#765">|; 
$noresave{$key} = "$nosave";

$key = q/upc_lock_free###7601/;
$index{$key} .= q|<A NAME="tex2html181" HREF="|."$dir".q|upc-lang-spec.html#2594">|; 
$noresave{$key} = "$nosave";

$key = q/shared declarations, array###7477/;
$index{$key} .= q|<A NAME="tex2html99" HREF="|."$dir".q|upc-lang-spec.html#689">|; 
$noresave{$key} = "$nosave";

$key = q/phase###7579/;
$index{$key} .= q|<A NAME="tex2html167" HREF="|."$dir".q|upc-lang-spec.html#2501">|; 
$noresave{$key} = "$nosave";

$key = q/DependsOnThreads###7764/;
$index{$key} .= q|<A NAME="tex2html219" HREF="|."$dir".q|upc-lang-spec.html#3744">|; 
$noresave{$key} = "$nosave";

$key = q/upc_forall###7523/;
$index{$key} .= q|<A NAME="tex2html127" HREF="|."$dir".q|upc-lang-spec.html#869">|; 
$noresave{$key} = "$nosave";

$key = q/upc_global_alloc###7561/;
$index{$key} .= q|<A NAME="tex2html156" HREF="|."$dir".q|upc-lang-spec.html#2413">|; 
$noresave{$key} = "$nosave";

$key = q/AllStrict###7721/;
$index{$key} .= q|<A NAME="tex2html215" HREF="|."$dir".q|upc-lang-spec.html#3733">|; 
$noresave{$key} = "$nosave";

$key = q/upc_all_alloc###7563/;
$index{$key} .= q|<A NAME="tex2html157" HREF="|."$dir".q|upc-lang-spec.html#2426">|; 
$noresave{$key} = "$nosave";

$key = q/data races###7354/;
$index{$key} .= q|<A NAME="tex2html28" HREF="|."$dir".q|upc-lang-spec.html#159">|; 
$noresave{$key} = "$nosave";

$key = q/UPC_OUT_NOSYNC###7625/;
$index{$key} .= q|<A NAME="tex2html196" HREF="|."$dir".q|upc-lang-spec.html#3464">|; 
$noresave{$key} = "$nosave";

$key = q/synchronization phase###7501/;
$index{$key} .= q|<A NAME="tex2html118" HREF="|."$dir".q|upc-lang-spec.html#768">|; 
$noresave{$key} = "$nosave";

$key = q/pointer subtraction###7418/;
$index{$key} .= q|<A NAME="tex2html62" HREF="|."$dir".q|upc-lang-spec.html#477">|; 
$noresave{$key} = "$nosave";

$key = q/memory consistency, fence###7769/;
$index{$key} .= q|<A NAME="tex2html222" HREF="|."$dir".q|upc-lang-spec.html#3777">|; 
$noresave{$key} = "$nosave";

$key = q/upc_free###7570/;
$index{$key} .= q|<A NAME="tex2html161" HREF="|."$dir".q|upc-lang-spec.html#2469">|; 
$noresave{$key} = "$nosave";

$key = q/shared declarations, examples###7462/;
$index{$key} .= q|<A NAME="tex2html94" HREF="|."$dir".q|upc-lang-spec.html#622">|; 
$noresave{$key} = "$nosave";

$key = q/memory consistency, collective library###7816/;
$index{$key} .= q|<A NAME="tex2html227" HREF="|."$dir".q|upc-lang-spec.html#3803">|; 
$noresave{$key} = "$nosave";

$key = q/main###7339/;
$index{$key} .= q|<A NAME="tex2html15" HREF="|."$dir".q|upc-lang-spec.html#136">|; 
$noresave{$key} = "$nosave";

$key = q/parallel loop###7526/;
$index{$key} .= q|<A NAME="tex2html130" HREF="|."$dir".q|upc-lang-spec.html#872">|; 
$noresave{$key} = "$nosave";

$key = q/MYTHREAD###7376/;
$index{$key} .= q|<A NAME="tex2html31" HREF="|."$dir".q|upc-lang-spec.html#359">|; 
$noresave{$key} = "$nosave";

$key = q/mutual exclusion###7592/;
$index{$key} .= q|<A NAME="tex2html176" HREF="|."$dir".q|upc-lang-spec.html#2559">|; 
$noresave{$key} = "$nosave";

$key = q/static THREADS environment###7546/;
$index{$key} .= q|<A NAME="tex2html147" HREF="|."$dir".q|upc-lang-spec.html#963">|; 
$noresave{$key} = "$nosave";

$key = q/pragmas###7529/;
$index{$key} .= q|<A NAME="tex2html131" HREF="|."$dir".q|upc-lang-spec.html#930">|; 
$noresave{$key} = "$nosave";

$key = q/global address space###7316/;
$index{$key} .= q|<A NAME="tex2html3" HREF="|."$dir".q|upc-lang-spec.html#65">|; 
$noresave{$key} = "$nosave";

$key = q/upc_alloc###7565/;
$index{$key} .= q|<A NAME="tex2html158" HREF="|."$dir".q|upc-lang-spec.html#2442">|; 
$noresave{$key} = "$nosave";

$key = q/static THREADS environment###7331/;
$index{$key} .= q|<A NAME="tex2html9" HREF="|."$dir".q|upc-lang-spec.html#122">|; 
$noresave{$key} = "$nosave";

$key = q/shared access###7347/;
$index{$key} .= q|<A NAME="tex2html21" HREF="|."$dir".q|upc-lang-spec.html#152">|; 
$noresave{$key} = "$nosave";

$key = q/block size, conversion###7431/;
$index{$key} .= q|<A NAME="tex2html74" HREF="|."$dir".q|upc-lang-spec.html#510">|; 
$noresave{$key} = "$nosave";

$key = q/__UPC_STATIC_THREADS__###7545/;
$index{$key} .= q|<A NAME="tex2html146" HREF="|."$dir".q|upc-lang-spec.html#962">|; 
$noresave{$key} = "$nosave";

$key = q/block size###7398/;
$index{$key} .= q|<A NAME="tex2html49" HREF="|."$dir".q|upc-lang-spec.html#396">|; 
$noresave{$key} = "$nosave";

$key = q/upc_phaseof###7414/;
$index{$key} .= q|<A NAME="tex2html58" HREF="|."$dir".q|upc-lang-spec.html#473">|; 
$noresave{$key} = "$nosave";

$key = q/shared layout qualifier###7446/;
$index{$key} .= q|<A NAME="tex2html81" HREF="|."$dir".q|upc-lang-spec.html#564">|; 
$noresave{$key} = "$nosave";

$key = q/strict###7530/;
$index{$key} .= q|<A NAME="tex2html132" HREF="|."$dir".q|upc-lang-spec.html#931">|; 
$noresave{$key} = "$nosave";

$key = q/upc_lock_attempt###7606/;
$index{$key} .= q|<A NAME="tex2html184" HREF="|."$dir".q|upc-lang-spec.html#2624">|; 
$noresave{$key} = "$nosave";

$key = q/shared object, copying###7610/;
$index{$key} .= q|<A NAME="tex2html186" HREF="|."$dir".q|upc-lang-spec.html#2643">|; 
$noresave{$key} = "$nosave";

$key = q/shared declarations, examples###7483/;
$index{$key} .= q|<A NAME="tex2html105" HREF="|."$dir".q|upc-lang-spec.html#701">|; 
$noresave{$key} = "$nosave";

$key = q/memory consistency, non-collective library###7790/;
$index{$key} .= q|<A NAME="tex2html224" HREF="|."$dir".q|upc-lang-spec.html#3793">|; 
$noresave{$key} = "$nosave";

$key = q/pointer equality###7417/;
$index{$key} .= q|<A NAME="tex2html61" HREF="|."$dir".q|upc-lang-spec.html#476">|; 
$noresave{$key} = "$nosave";

$key = q/memory consistency###7648/;
$index{$key} .= q|<A NAME="tex2html207" HREF="|."$dir".q|upc-lang-spec.html#3702">|; 
$noresave{$key} = "$nosave";

$key = q/upc_notify###7384/;
$index{$key} .= q|<A NAME="tex2html39" HREF="|."$dir".q|upc-lang-spec.html#367">|; 
$noresave{$key} = "$nosave";

$key = q/UPC_MAX_BLOCK_SIZE###7542/;
$index{$key} .= q|<A NAME="tex2html143" HREF="|."$dir".q|upc-lang-spec.html#953">|; 
$noresave{$key} = "$nosave";

$key = q/strict shared write###7349/;
$index{$key} .= q|<A NAME="tex2html23" HREF="|."$dir".q|upc-lang-spec.html#154">|; 
$noresave{$key} = "$nosave";

$key = q/relaxed shared write###7351/;
$index{$key} .= q|<A NAME="tex2html25" HREF="|."$dir".q|upc-lang-spec.html#156">|; 
$noresave{$key} = "$nosave";

$key = q/pointer-to-shared, null###7429/;
$index{$key} .= q|<A NAME="tex2html72" HREF="|."$dir".q|upc-lang-spec.html#508">|; 
$noresave{$key} = "$nosave";

$key = q/implicit barriers###7335/;
$index{$key} .= q|<A NAME="tex2html12" HREF="|."$dir".q|upc-lang-spec.html#128">|; 
$noresave{$key} = "$nosave";

$key = q/pointer-to-local###7412/;
$index{$key} .= q|<A NAME="tex2html56" HREF="|."$dir".q|upc-lang-spec.html#471">|; 
$noresave{$key} = "$nosave";

$key = q/relaxed shared write###7717/;
$index{$key} .= q|<A NAME="tex2html212" HREF="|."$dir".q|upc-lang-spec.html#3710">|; 
$noresave{$key} = "$nosave";

$key = q/collective###7553/;
$index{$key} .= q|<A NAME="tex2html152" HREF="|."$dir".q|upc-lang-spec.html#2395">|; 
$noresave{$key} = "$nosave";

$key = q/upc_barrier###7377/;
$index{$key} .= q|<A NAME="tex2html32" HREF="|."$dir".q|upc-lang-spec.html#360">|; 
$noresave{$key} = "$nosave";

$key = q/strict shared read###7348/;
$index{$key} .= q|<A NAME="tex2html22" HREF="|."$dir".q|upc-lang-spec.html#153">|; 
$noresave{$key} = "$nosave";

$key = q/definite block size###7460/;
$index{$key} .= q|<A NAME="tex2html92" HREF="|."$dir".q|upc-lang-spec.html#615">|; 
$noresave{$key} = "$nosave";

$key = q/upc_unlock###7608/;
$index{$key} .= q|<A NAME="tex2html185" HREF="|."$dir".q|upc-lang-spec.html#2634">|; 
$noresave{$key} = "$nosave";

$key = q/phase###7582/;
$index{$key} .= q|<A NAME="tex2html169" HREF="|."$dir".q|upc-lang-spec.html#2512">|; 
$noresave{$key} = "$nosave";

$key = q/upc_wait###7500/;
$index{$key} .= q|<A NAME="tex2html117" HREF="|."$dir".q|upc-lang-spec.html#767">|; 
$noresave{$key} = "$nosave";

$key = q/static THREADS environment###7479/;
$index{$key} .= q|<A NAME="tex2html101" HREF="|."$dir".q|upc-lang-spec.html#691">|; 
$noresave{$key} = "$nosave";

$key = q/upc_global_lock_alloc###7596/;
$index{$key} .= q|<A NAME="tex2html178" HREF="|."$dir".q|upc-lang-spec.html#2574">|; 
$noresave{$key} = "$nosave";

$key = q/MYTHREAD###7548/;
$index{$key} .= q|<A NAME="tex2html149" HREF="|."$dir".q|upc-lang-spec.html#967">|; 
$noresave{$key} = "$nosave";

$key = q/upc_memcpy###7613/;
$index{$key} .= q|<A NAME="tex2html188" HREF="|."$dir".q|upc-lang-spec.html#2647">|; 
$noresave{$key} = "$nosave";

$key = q/keywords###7374/;
$index{$key} .= q|<A NAME="tex2html29" HREF="|."$dir".q|upc-lang-spec.html#357">|; 
$noresave{$key} = "$nosave";

$key = q/relaxed###7441/;
$index{$key} .= q|<A NAME="tex2html77" HREF="|."$dir".q|upc-lang-spec.html#531">|; 
$noresave{$key} = "$nosave";

$key = q/upc_global_exit###7556/;
$index{$key} .= q|<A NAME="tex2html153" HREF="|."$dir".q|upc-lang-spec.html#2402">|; 
$noresave{$key} = "$nosave";

$key = q/upc_affinitysize###7587/;
$index{$key} .= q|<A NAME="tex2html172" HREF="|."$dir".q|upc-lang-spec.html#2530">|; 
$noresave{$key} = "$nosave";

$key = q/UPC_MAX_BLOCK_SIZE###7397/;
$index{$key} .= q|<A NAME="tex2html48" HREF="|."$dir".q|upc-lang-spec.html#395">|; 
$noresave{$key} = "$nosave";

$key = q/pointer-to-shared###7411/;
$index{$key} .= q|<A NAME="tex2html55" HREF="|."$dir".q|upc-lang-spec.html#470">|; 
$noresave{$key} = "$nosave";

$key = q/memory consistency###7622/;
$index{$key} .= q|<A NAME="tex2html193" HREF="|."$dir".q|upc-lang-spec.html#3461">|; 
$noresave{$key} = "$nosave";

$key = q/memory consistency, locks###7767/;
$index{$key} .= q|<A NAME="tex2html220" HREF="|."$dir".q|upc-lang-spec.html#3775">|; 
$noresave{$key} = "$nosave";

$key = q/strict shared read###7714/;
$index{$key} .= q|<A NAME="tex2html209" HREF="|."$dir".q|upc-lang-spec.html#3707">|; 
$noresave{$key} = "$nosave";

$key = q/ISO C###7318/;
$index{$key} .= q|<A NAME="tex2html4" HREF="|."$dir".q|upc-lang-spec.html#67">|; 
$noresave{$key} = "$nosave";

$key = q/memory copy###7611/;
$index{$key} .= q|<A NAME="tex2html187" HREF="|."$dir".q|upc-lang-spec.html#2644">|; 
$noresave{$key} = "$nosave";

$key = q/dynamic THREADS environment###7478/;
$index{$key} .= q|<A NAME="tex2html100" HREF="|."$dir".q|upc-lang-spec.html#690">|; 
$noresave{$key} = "$nosave";

$key = q/locks###7590/;
$index{$key} .= q|<A NAME="tex2html174" HREF="|."$dir".q|upc-lang-spec.html#2557">|; 
$noresave{$key} = "$nosave";

$key = q/block size, automatically-computed###7455/;
$index{$key} .= q|<A NAME="tex2html87" HREF="|."$dir".q|upc-lang-spec.html#607">|; 
$noresave{$key} = "$nosave";

$key = q/upc_relaxed.h###7552/;
$index{$key} .= q|<A NAME="tex2html151" HREF="|."$dir".q|upc-lang-spec.html#2392">|; 
$noresave{$key} = "$nosave";

$key = q/upc_local_alloc###7567/;
$index{$key} .= q|<A NAME="tex2html159" HREF="|."$dir".q|upc-lang-spec.html#2455">|; 
$noresave{$key} = "$nosave";

$key = q/pointer-to-shared, conversion###7428/;
$index{$key} .= q|<A NAME="tex2html71" HREF="|."$dir".q|upc-lang-spec.html#507">|; 
$noresave{$key} = "$nosave";

$key = q/ISO C###7314/;
$index{$key} .= q|<A NAME="tex2html1" HREF="|."$dir".q|upc-lang-spec.html#63">|; 
$noresave{$key} = "$nosave";

$key = q/upc_global_exit###7343/;
$index{$key} .= q|<A NAME="tex2html18" HREF="|."$dir".q|upc-lang-spec.html#142">|; 
$noresave{$key} = "$nosave";

$key = q/program order###7353/;
$index{$key} .= q|<A NAME="tex2html27" HREF="|."$dir".q|upc-lang-spec.html#158">|; 
$noresave{$key} = "$nosave";

$key = q/__UPC_DYNAMIC_THREADS__###7543/;
$index{$key} .= q|<A NAME="tex2html144" HREF="|."$dir".q|upc-lang-spec.html#958">|; 
$noresave{$key} = "$nosave";

$key = q/affinity###7419/;
$index{$key} .= q|<A NAME="tex2html63" HREF="|."$dir".q|upc-lang-spec.html#478">|; 
$noresave{$key} = "$nosave";

$key = q/block size, definite###7453/;
$index{$key} .= q|<A NAME="tex2html85" HREF="|."$dir".q|upc-lang-spec.html#605">|; 
$noresave{$key} = "$nosave";

$key = q/indefinite###7459/;
$index{$key} .= q|<A NAME="tex2html91" HREF="|."$dir".q|upc-lang-spec.html#613">|; 
$noresave{$key} = "$nosave";

$key = q/upc_localsizeof###7378/;
$index{$key} .= q|<A NAME="tex2html33" HREF="|."$dir".q|upc-lang-spec.html#361">|; 
$noresave{$key} = "$nosave";

$key = q/upc_resetphase###7581/;
$index{$key} .= q|<A NAME="tex2html168" HREF="|."$dir".q|upc-lang-spec.html#2511">|; 
$noresave{$key} = "$nosave";

$key = q/memory consistency###7502/;
$index{$key} .= q|<A NAME="tex2html119" HREF="|."$dir".q|upc-lang-spec.html#769">|; 
$noresave{$key} = "$nosave";

$key = q/pointer-to-shared, casts###7427/;
$index{$key} .= q|<A NAME="tex2html70" HREF="|."$dir".q|upc-lang-spec.html#506">|; 
$noresave{$key} = "$nosave";

$key = q/upc_elemsizeof###7409/;
$index{$key} .= q|<A NAME="tex2html54" HREF="|."$dir".q|upc-lang-spec.html#460">|; 
$noresave{$key} = "$nosave";

$key = q/memory consistency###7346/;
$index{$key} .= q|<A NAME="tex2html20" HREF="|."$dir".q|upc-lang-spec.html#151">|; 
$noresave{$key} = "$nosave";

$key = q/StrictOnThreads###7720/;
$index{$key} .= q|<A NAME="tex2html214" HREF="|."$dir".q|upc-lang-spec.html#3732">|; 
$noresave{$key} = "$nosave";

$key = q/upc_fence###7386/;
$index{$key} .= q|<A NAME="tex2html41" HREF="|."$dir".q|upc-lang-spec.html#369">|; 
$noresave{$key} = "$nosave";

$key = q/null strict access###7506/;
$index{$key} .= q|<A NAME="tex2html123" HREF="|."$dir".q|upc-lang-spec.html#792">|; 
$noresave{$key} = "$nosave";

$key = q/shared object, clearing###7620/;
$index{$key} .= q|<A NAME="tex2html192" HREF="|."$dir".q|upc-lang-spec.html#2697">|; 
$noresave{$key} = "$nosave";

$key = q/sequential consistency###7352/;
$index{$key} .= q|<A NAME="tex2html26" HREF="|."$dir".q|upc-lang-spec.html#157">|; 
$noresave{$key} = "$nosave";

$key = q/relaxed shared read###7716/;
$index{$key} .= q|<A NAME="tex2html211" HREF="|."$dir".q|upc-lang-spec.html#3709">|; 
$noresave{$key} = "$nosave";

$key = q/block size, declaration###7473/;
$index{$key} .= q|<A NAME="tex2html96" HREF="|."$dir".q|upc-lang-spec.html#635">|; 
$noresave{$key} = "$nosave";

$key = q/pointer-to-shared, type compatibility###7461/;
$index{$key} .= q|<A NAME="tex2html93" HREF="|."$dir".q|upc-lang-spec.html#616">|; 
$noresave{$key} = "$nosave";

$key = q/upc_lock_t###7594/;
$index{$key} .= q|<A NAME="tex2html177" HREF="|."$dir".q|upc-lang-spec.html#2561">|; 
$noresave{$key} = "$nosave";

$key = q/sequential consistency###7842/;
$index{$key} .= q|<A NAME="tex2html231" HREF="|."$dir".q|upc-lang-spec.html#3822">|; 
$noresave{$key} = "$nosave";

$key = q/dynamic THREADS environment###7332/;
$index{$key} .= q|<A NAME="tex2html10" HREF="|."$dir".q|upc-lang-spec.html#123">|; 
$noresave{$key} = "$nosave";

$key = q/program termination###7342/;
$index{$key} .= q|<A NAME="tex2html17" HREF="|."$dir".q|upc-lang-spec.html#141">|; 
$noresave{$key} = "$nosave";

$key = q/UPC_OUT_ALLSYNC###7623/;
$index{$key} .= q|<A NAME="tex2html194" HREF="|."$dir".q|upc-lang-spec.html#3462">|; 
$noresave{$key} = "$nosave";

$key = q/upc_blocksizeof###7380/;
$index{$key} .= q|<A NAME="tex2html35" HREF="|."$dir".q|upc-lang-spec.html#363">|; 
$noresave{$key} = "$nosave";

$key = q/relaxed shared write###7536/;
$index{$key} .= q|<A NAME="tex2html138" HREF="|."$dir".q|upc-lang-spec.html#937">|; 
$noresave{$key} = "$nosave";

$key = q/UPC_IN_ALLSYNC###7626/;
$index{$key} .= q|<A NAME="tex2html197" HREF="|."$dir".q|upc-lang-spec.html#3465">|; 
$noresave{$key} = "$nosave";

$key = q/upc_memset###7619/;
$index{$key} .= q|<A NAME="tex2html191" HREF="|."$dir".q|upc-lang-spec.html#2696">|; 
$noresave{$key} = "$nosave";

$key = q/thread creation###7334/;
$index{$key} .= q|<A NAME="tex2html11" HREF="|."$dir".q|upc-lang-spec.html#127">|; 
$noresave{$key} = "$nosave";

$key = q/strict###7385/;
$index{$key} .= q|<A NAME="tex2html40" HREF="|."$dir".q|upc-lang-spec.html#368">|; 
$noresave{$key} = "$nosave";

$key = q/sizeof###7403/;
$index{$key} .= q|<A NAME="tex2html51" HREF="|."$dir".q|upc-lang-spec.html#433">|; 
$noresave{$key} = "$nosave";

$key = q/upc_notify###7499/;
$index{$key} .= q|<A NAME="tex2html116" HREF="|."$dir".q|upc-lang-spec.html#766">|; 
$noresave{$key} = "$nosave";

$key = q/UPC_MAX_BLOCK_SIZE###7381/;
$index{$key} .= q|<A NAME="tex2html36" HREF="|."$dir".q|upc-lang-spec.html#364">|; 
$noresave{$key} = "$nosave";

$key = q/relaxed###7445/;
$index{$key} .= q|<A NAME="tex2html80" HREF="|."$dir".q|upc-lang-spec.html#563">|; 
$noresave{$key} = "$nosave";

$key = q/upc_addrfield###7416/;
$index{$key} .= q|<A NAME="tex2html60" HREF="|."$dir".q|upc-lang-spec.html#475">|; 
$noresave{$key} = "$nosave";

$key = q/indefinite block size###7456/;
$index{$key} .= q|<A NAME="tex2html88" HREF="|."$dir".q|upc-lang-spec.html#608">|; 
$noresave{$key} = "$nosave";

$key = q/barriers###7497/;
$index{$key} .= q|<A NAME="tex2html114" HREF="|."$dir".q|upc-lang-spec.html#764">|; 
$noresave{$key} = "$nosave";

$key = q/shared###7382/;
$index{$key} .= q|<A NAME="tex2html37" HREF="|."$dir".q|upc-lang-spec.html#365">|; 
$noresave{$key} = "$nosave";

$key = q/UPC_OUT_MYSYNC###7624/;
$index{$key} .= q|<A NAME="tex2html195" HREF="|."$dir".q|upc-lang-spec.html#3463">|; 
$noresave{$key} = "$nosave";

$key = q/upc_memget###7615/;
$index{$key} .= q|<A NAME="tex2html189" HREF="|."$dir".q|upc-lang-spec.html#2663">|; 
$noresave{$key} = "$nosave";

$key = q/upc_all_lock_alloc###7598/;
$index{$key} .= q|<A NAME="tex2html179" HREF="|."$dir".q|upc-lang-spec.html#2584">|; 
$noresave{$key} = "$nosave";

$key = q/shared declarations, restrictions###7474/;
$index{$key} .= q|<A NAME="tex2html97" HREF="|."$dir".q|upc-lang-spec.html#681">|; 
$noresave{$key} = "$nosave";

$key = q/strict###7444/;
$index{$key} .= q|<A NAME="tex2html79" HREF="|."$dir".q|upc-lang-spec.html#562">|; 
$noresave{$key} = "$nosave";

$key = q/affinity###7575/;
$index{$key} .= q|<A NAME="tex2html164" HREF="|."$dir".q|upc-lang-spec.html#2488">|; 
$noresave{$key} = "$nosave";

$key = q/collective###7503/;
$index{$key} .= q|<A NAME="tex2html120" HREF="|."$dir".q|upc-lang-spec.html#770">|; 
$noresave{$key} = "$nosave";

$key = q/work sharing###7525/;
$index{$key} .= q|<A NAME="tex2html129" HREF="|."$dir".q|upc-lang-spec.html#871">|; 
$noresave{$key} = "$nosave";

$key = q/relaxed###7379/;
$index{$key} .= q|<A NAME="tex2html34" HREF="|."$dir".q|upc-lang-spec.html#362">|; 
$noresave{$key} = "$nosave";

$key = q/StrictPairs###7719/;
$index{$key} .= q|<A NAME="tex2html213" HREF="|."$dir".q|upc-lang-spec.html#3731">|; 
$noresave{$key} = "$nosave";

$key = q/shared object, allocation###7558/;
$index{$key} .= q|<A NAME="tex2html154" HREF="|."$dir".q|upc-lang-spec.html#2409">|; 
$noresave{$key} = "$nosave";

$key = q/dynamic THREADS environment###7544/;
$index{$key} .= q|<A NAME="tex2html145" HREF="|."$dir".q|upc-lang-spec.html#959">|; 
$noresave{$key} = "$nosave";

$key = q/__UPC__###7540/;
$index{$key} .= q|<A NAME="tex2html141" HREF="|."$dir".q|upc-lang-spec.html#949">|; 
$noresave{$key} = "$nosave";

$key = q/Precedes###7990/;
$index{$key} .= q|<A NAME="tex2html235" HREF="|."$dir".q|upc-lang-spec.html#4063">|; 
$noresave{$key} = "$nosave";

$key = q/program startup###7338/;
$index{$key} .= q|<A NAME="tex2html14" HREF="|."$dir".q|upc-lang-spec.html#135">|; 
$noresave{$key} = "$nosave";

$key = q/exit###7344/;
$index{$key} .= q|<A NAME="tex2html19" HREF="|."$dir".q|upc-lang-spec.html#143">|; 
$noresave{$key} = "$nosave";

$key = q/program order###7991/;
$index{$key} .= q|<A NAME="tex2html236" HREF="|."$dir".q|upc-lang-spec.html#4064">|; 
$noresave{$key} = "$nosave";

$key = q/struct field, address-of###7433/;
$index{$key} .= q|<A NAME="tex2html75" HREF="|."$dir".q|upc-lang-spec.html#523">|; 
$noresave{$key} = "$nosave";

$key = q/THREADS###7388/;
$index{$key} .= q|<A NAME="tex2html43" HREF="|."$dir".q|upc-lang-spec.html#371">|; 
$noresave{$key} = "$nosave";

$key = q/pointer addition###7413/;
$index{$key} .= q|<A NAME="tex2html57" HREF="|."$dir".q|upc-lang-spec.html#472">|; 
$noresave{$key} = "$nosave";

$key = q/UPC###7315/;
$index{$key} .= q|<A NAME="tex2html2" HREF="|."$dir".q|upc-lang-spec.html#64">|; 
$noresave{$key} = "$nosave";

$key = q/upc_strict.h###7551/;
$index{$key} .= q|<A NAME="tex2html150" HREF="|."$dir".q|upc-lang-spec.html#2389">|; 
$noresave{$key} = "$nosave";

$key = q/MYTHREAD###7394/;
$index{$key} .= q|<A NAME="tex2html46" HREF="|."$dir".q|upc-lang-spec.html#389">|; 
$noresave{$key} = "$nosave";

$key = q/UPC_IN_MYSYNC###7627/;
$index{$key} .= q|<A NAME="tex2html198" HREF="|."$dir".q|upc-lang-spec.html#3466">|; 
$noresave{$key} = "$nosave";

$key = q/UPC_IN_NOSYNC###7628/;
$index{$key} .= q|<A NAME="tex2html199" HREF="|."$dir".q|upc-lang-spec.html#3467">|; 
$noresave{$key} = "$nosave";

$key = q/memory consistency, examples###7845/;
$index{$key} .= q|<A NAME="tex2html233" HREF="|."$dir".q|upc-lang-spec.html#3841">|; 
$noresave{$key} = "$nosave";

$key = q/relaxed shared read###7350/;
$index{$key} .= q|<A NAME="tex2html24" HREF="|."$dir".q|upc-lang-spec.html#155">|; 
$noresave{$key} = "$nosave";

$key = q/block size, indefinite###7452/;
$index{$key} .= q|<A NAME="tex2html84" HREF="|."$dir".q|upc-lang-spec.html#604">|; 
$noresave{$key} = "$nosave";

$key = q/shared access###7713/;
$index{$key} .= q|<A NAME="tex2html208" HREF="|."$dir".q|upc-lang-spec.html#3706">|; 
$noresave{$key} = "$nosave";

$key = q/upc_localsizeof###7588/;
$index{$key} .= q|<A NAME="tex2html173" HREF="|."$dir".q|upc-lang-spec.html#2531">|; 
$noresave{$key} = "$nosave";

$key = q/upc_localsizeof###7405/;
$index{$key} .= q|<A NAME="tex2html52" HREF="|."$dir".q|upc-lang-spec.html#438">|; 
$noresave{$key} = "$nosave";

$key = q/memory allocation###7559/;
$index{$key} .= q|<A NAME="tex2html155" HREF="|."$dir".q|upc-lang-spec.html#2410">|; 
$noresave{$key} = "$nosave";

$key = q/block size, default###7454/;
$index{$key} .= q|<A NAME="tex2html86" HREF="|."$dir".q|upc-lang-spec.html#606">|; 
$noresave{$key} = "$nosave";

$key = q/upc_forall###7389/;
$index{$key} .= q|<A NAME="tex2html44" HREF="|."$dir".q|upc-lang-spec.html#372">|; 
$noresave{$key} = "$nosave";

$key = q/upc_blocksizeof###7407/;
$index{$key} .= q|<A NAME="tex2html53" HREF="|."$dir".q|upc-lang-spec.html#447">|; 
$noresave{$key} = "$nosave";

$key = q/relaxed###7531/;
$index{$key} .= q|<A NAME="tex2html133" HREF="|."$dir".q|upc-lang-spec.html#932">|; 
$noresave{$key} = "$nosave";

$key = q/strict shared write###7715/;
$index{$key} .= q|<A NAME="tex2html210" HREF="|."$dir".q|upc-lang-spec.html#3708">|; 
$noresave{$key} = "$nosave";

$key = q/strict shared write###7534/;
$index{$key} .= q|<A NAME="tex2html136" HREF="|."$dir".q|upc-lang-spec.html#935">|; 
$noresave{$key} = "$nosave";

$key = q/definite block size###7457/;
$index{$key} .= q|<A NAME="tex2html89" HREF="|."$dir".q|upc-lang-spec.html#609">|; 
$noresave{$key} = "$nosave";

$key = q/upc_threadof###7415/;
$index{$key} .= q|<A NAME="tex2html59" HREF="|."$dir".q|upc-lang-spec.html#474">|; 
$noresave{$key} = "$nosave";

$key = q/__UPC_VERSION__###7541/;
$index{$key} .= q|<A NAME="tex2html142" HREF="|."$dir".q|upc-lang-spec.html#951">|; 
$noresave{$key} = "$nosave";

$key = q/strict shared read###7533/;
$index{$key} .= q|<A NAME="tex2html135" HREF="|."$dir".q|upc-lang-spec.html#934">|; 
$noresave{$key} = "$nosave";

$key = q/upc_fence###7505/;
$index{$key} .= q|<A NAME="tex2html122" HREF="|."$dir".q|upc-lang-spec.html#787">|; 
$noresave{$key} = "$nosave";

$key = q/feature macros###7646/;
$index{$key} .= q|<A NAME="tex2html206" HREF="|."$dir".q|upc-lang-spec.html#3666">|; 
$noresave{$key} = "$nosave";

$key = q/synchronization###7325/;
$index{$key} .= q|<A NAME="tex2html8" HREF="|."$dir".q|upc-lang-spec.html#109">|; 
$noresave{$key} = "$nosave";

$key = q/upc_memput###7617/;
$index{$key} .= q|<A NAME="tex2html190" HREF="|."$dir".q|upc-lang-spec.html#2680">|; 
$noresave{$key} = "$nosave";

$key = q/upc_threadof###7574/;
$index{$key} .= q|<A NAME="tex2html163" HREF="|."$dir".q|upc-lang-spec.html#2487">|; 
$noresave{$key} = "$nosave";

$key = q/block size###7442/;
$index{$key} .= q|<A NAME="tex2html78" HREF="|."$dir".q|upc-lang-spec.html#532">|; 
$noresave{$key} = "$nosave";

$key = q/predefined macros###7539/;
$index{$key} .= q|<A NAME="tex2html140" HREF="|."$dir".q|upc-lang-spec.html#945">|; 
$noresave{$key} = "$nosave";

$key = q/upc_elemsizeof###7383/;
$index{$key} .= q|<A NAME="tex2html38" HREF="|."$dir".q|upc-lang-spec.html#366">|; 
$noresave{$key} = "$nosave";

$key = q/pointer-to-shared, generic###7430/;
$index{$key} .= q|<A NAME="tex2html73" HREF="|."$dir".q|upc-lang-spec.html#509">|; 
$noresave{$key} = "$nosave";

$key = q/THREADS###7547/;
$index{$key} .= q|<A NAME="tex2html148" HREF="|."$dir".q|upc-lang-spec.html#966">|; 
$noresave{$key} = "$nosave";

$key = q/shared declarations, scalar###7475/;
$index{$key} .= q|<A NAME="tex2html98" HREF="|."$dir".q|upc-lang-spec.html#686">|; 
$noresave{$key} = "$nosave";

$key = q/THREADS###7392/;
$index{$key} .= q|<A NAME="tex2html45" HREF="|."$dir".q|upc-lang-spec.html#384">|; 
$noresave{$key} = "$nosave";

$key = q/implicit barriers###7504/;
$index{$key} .= q|<A NAME="tex2html121" HREF="|."$dir".q|upc-lang-spec.html#771">|; 
$noresave{$key} = "$nosave";

$key = q/Conflicting###7763/;
$index{$key} .= q|<A NAME="tex2html218" HREF="|."$dir".q|upc-lang-spec.html#3743">|; 
$noresave{$key} = "$nosave";

$key = q/PotentialRaces###7843/;
$index{$key} .= q|<A NAME="tex2html232" HREF="|."$dir".q|upc-lang-spec.html#3828">|; 
$noresave{$key} = "$nosave";

$key = q/proposed extensions###7644/;
$index{$key} .= q|<A NAME="tex2html204" HREF="|."$dir".q|upc-lang-spec.html#3660">|; 
$noresave{$key} = "$nosave";

$key = q/tokens###7375/;
$index{$key} .= q|<A NAME="tex2html30" HREF="|."$dir".q|upc-lang-spec.html#358">|; 
$noresave{$key} = "$nosave";

$key = q/upc_lock###7604/;
$index{$key} .= q|<A NAME="tex2html183" HREF="|."$dir".q|upc-lang-spec.html#2612">|; 
$noresave{$key} = "$nosave";

$key = q/upc_phaseof###7482/;
$index{$key} .= q|<A NAME="tex2html104" HREF="|."$dir".q|upc-lang-spec.html#698">|; 
$noresave{$key} = "$nosave";

$key = q/upc_wait###7387/;
$index{$key} .= q|<A NAME="tex2html42" HREF="|."$dir".q|upc-lang-spec.html#370">|; 
$noresave{$key} = "$nosave";

$key = q/shared access###7532/;
$index{$key} .= q|<A NAME="tex2html134" HREF="|."$dir".q|upc-lang-spec.html#933">|; 
$noresave{$key} = "$nosave";

$key = q/memory consistency, barriers###7768/;
$index{$key} .= q|<A NAME="tex2html221" HREF="|."$dir".q|upc-lang-spec.html#3776">|; 
$noresave{$key} = "$nosave";

$key = q/strict###7440/;
$index{$key} .= q|<A NAME="tex2html76" HREF="|."$dir".q|upc-lang-spec.html#530">|; 
$noresave{$key} = "$nosave";

$key = q/upc_addrfield###7585/;
$index{$key} .= q|<A NAME="tex2html171" HREF="|."$dir".q|upc-lang-spec.html#2521">|; 
$noresave{$key} = "$nosave";

$key = q/continue###7524/;
$index{$key} .= q|<A NAME="tex2html128" HREF="|."$dir".q|upc-lang-spec.html#870">|; 
$noresave{$key} = "$nosave";

$key = q/phase###7420/;
$index{$key} .= q|<A NAME="tex2html64" HREF="|."$dir".q|upc-lang-spec.html#479">|; 
$noresave{$key} = "$nosave";

$key = q/synchronization###7591/;
$index{$key} .= q|<A NAME="tex2html175" HREF="|."$dir".q|upc-lang-spec.html#2558">|; 
$noresave{$key} = "$nosave";

$key = q/blocking factor###7458/;
$index{$key} .= q|<A NAME="tex2html90" HREF="|."$dir".q|upc-lang-spec.html#610">|; 
$noresave{$key} = "$nosave";

$key = q/relaxed shared read###7535/;
$index{$key} .= q|<A NAME="tex2html137" HREF="|."$dir".q|upc-lang-spec.html#936">|; 
$noresave{$key} = "$nosave";

$key = q/upc_flag_t###7629/;
$index{$key} .= q|<A NAME="tex2html200" HREF="|."$dir".q|upc-lang-spec.html#3468">|; 
$noresave{$key} = "$nosave";
