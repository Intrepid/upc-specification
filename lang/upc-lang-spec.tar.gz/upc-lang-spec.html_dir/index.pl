# LaTeX2HTML 2008 (1.71)
# Associate index original text with physical files.


$key = q/individual file pointer/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1579">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#1658">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">3</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#1887">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">8</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_global_alloc/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#823"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_all_fwait_async/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1593">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#2199">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">7</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#2300">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">9</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/shared layout qualifier/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#388"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">5</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_all_fread_list_shared/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#2131">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/shared object, clearing/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1107"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">5</SPAN>.<SPAN CLASS="arabic">4</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/keywords/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#181"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/dependsonthreads/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#2371">B..<SPAN CLASS="arabic">2</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_logor/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1396"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/shared access/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#3150"><SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#147"><SPAN CLASS="arabic">5</SPAN>.<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">3</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#757"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#2333">B..<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_all_fpreallocate/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1839">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">7</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_max_block_size/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#188"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#219"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">3</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#777"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_all_scatter/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1220"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_rdonly/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1664">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_all_fread_local/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1967">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">4</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_all_fset_size/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1807">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">5</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_all_fget_size/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1828">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">6</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/shared object, allocation/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#819"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/relaxed/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#186"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#355"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">5</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#387"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">5</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#756"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_global_exit/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#137"><SPAN CLASS="arabic">5</SPAN>.<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#812"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_local_alloc/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#865"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">4</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/reduction/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1438"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_all_fsync/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1603">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">3</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#1776">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">3</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_local_memvec/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#2075">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">6</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_collective.h/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1178"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">3</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/synchronization/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#104"><SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#587"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#968"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">4</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_individual_fp/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1668">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_append/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1669">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_filevec/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#2077">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">6</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_off_t/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1639">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_memcpy/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1057"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">5</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_seek_set/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1796">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">4</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/relaxed shared write/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#3190"><SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">4</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#151"><SPAN CLASS="arabic">5</SPAN>.<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">3</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#761"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#2337">B..<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/memory consistency, collective library/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#2430">B..<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_unlock/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1044"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">4</SPAN>.<SPAN CLASS="arabic">7</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/memory consistency, barriers/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#2403">B..<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_all_lock_alloc/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#994"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">4</SPAN>.<SPAN CLASS="arabic">3</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_all_fread_list_local/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#2111">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_all_fread_shared/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1985">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">4</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_get_fl/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1908">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">8</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/phase/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#3230"><SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#303"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">4</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#911"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#922"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">3</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_notify/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#191"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#590"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_set_hint/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1938">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">8</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_wronly/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1665">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/gather, to all/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1286"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">4</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/access/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#3140"><SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">6</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_func/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1399"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_seek_end/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1798">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">4</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_localsizeof/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#185"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#262"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">4</SPAN>.<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#941"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">5</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/sequential consistency/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#152"><SPAN CLASS="arabic">5</SPAN>.<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">3</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#2449">B..<SPAN CLASS="arabic">4</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/__upc_static_threads__/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#786"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_set_individual_fp/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1901">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">8</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_all_alloc/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#836"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/exchange/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1320"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">5</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_all_fwrite_local/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#2022">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">5</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_seek_cur/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1797">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">4</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_all_fwrite_shared/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#2042">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">5</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/file atomicity/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1566">A..<SPAN CLASS="arabic">1</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#1599">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">3</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#1953">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">8</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/shared object/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#3068"><SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/mythread/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#183"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#213"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#791"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_addrfield/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#299"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">4</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#931"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">4</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/collective/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#3210"><SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">7</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#594"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#805"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/exit/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#138"><SPAN CLASS="arabic">5</SPAN>.<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/pointer-to-shared/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#3120"><SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">4</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#294"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">4</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/pointer-to-local/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#3130"><SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">5</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#295"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">4</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_memput/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1090"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">5</SPAN>.<SPAN CLASS="arabic">3</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/file interoperability/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1633">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">4</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/shared/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#189"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/shared object, copying/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1053"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">5</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/strict shared write/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#3170"><SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#149"><SPAN CLASS="arabic">5</SPAN>.<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">3</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#759"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#2335">B..<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/struct field, address-of/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#347"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">4</SPAN>.<SPAN CLASS="arabic">4</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/indefinite block size/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#432"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">5</SPAN>.<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/pragmas/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#754"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/memory allocation/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#820"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_get_fn/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1916">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">8</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_add/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1390"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/pointer-to-shared, null/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#332"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">4</SPAN>.<SPAN CLASS="arabic">3</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/file flush/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1777">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">3</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_all_fwrite_shared_async/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#2245">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">4</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/dynamic threads environment/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#118"><SPAN CLASS="arabic">5</SPAN>.<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#514"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">5</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#783"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_free/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#879"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">5</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_min/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1397"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_all_reduce_prefix/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1437"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/global address space/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#72"><SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_op_t/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1389"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/block size/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#220"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">3</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#356"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">5</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/thread/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#3048"><SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_in_allsync/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1128"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">6</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_or/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1393"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_forall/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#196"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#693"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_mult/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1391"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/__upc_dynamic_threads__/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#782"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/pointer addition/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#296"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">4</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_out_nosync/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1127"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">6</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/file hints/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1720">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#1927">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">8</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/allstrict/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#2360">B..<SPAN CLASS="arabic">2</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#71"><SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/object/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#3058"><SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_lock_t/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#971"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">4</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/parallel loop/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#696"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_shared_memvec/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#2076">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">6</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/prefix reduction/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1439"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/feature macros/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1542">A.</A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/asynchronous i\/o/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1591">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#1947">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">8</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#2195">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">7</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/pointer-to-shared, generic/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#333"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">4</SPAN>.<SPAN CLASS="arabic">3</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/pointer-to-shared, conversion/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#331"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">4</SPAN>.<SPAN CLASS="arabic">3</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/blocking factor/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#434"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">5</SPAN>.<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_all_fwrite_list_local_async/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#2278">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">7</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_memset/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1106"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">5</SPAN>.<SPAN CLASS="arabic">4</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/__upc__/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#773"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_file_t/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1642">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_memget/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1073"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">5</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_all_fopen/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1663">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/file seek/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1789">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">4</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/shared declarations, examples/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#446"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">5</SPAN>.<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#525"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">5</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_resetphase/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#921"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">3</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/file open/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1662">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/file pointer/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1577">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#1656">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">3</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#1885">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">8</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/file reading/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1962">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">4</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#2110">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#2130">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#2196">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">7</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_lock_attempt/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1034"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">4</SPAN>.<SPAN CLASS="arabic">6</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_xor/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1394"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/shared array/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#3100"><SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">3</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/tokens/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#182"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_get_fp/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1888">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">8</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/end of file/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1558">A..<SPAN CLASS="arabic">1</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#1809">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">5</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/memory consistency, non-collective library/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#2420">B..<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_create/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1670">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_delete_on_close/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1674">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/null strict access/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#616"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/permute/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1354"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">6</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_strong_ca/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1615">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">3</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#1672">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_all_exchange/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1319"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">5</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/file close/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1760">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/memory consistency, examples/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#2468">B..<SPAN CLASS="arabic">5</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/list i\/o/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#2073">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">6</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_all_fread_list_local_async/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#2256">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">5</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_all_permute/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1353"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">6</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/local access/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#3200"><SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/work sharing/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#695"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_get_ca_semantics/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1865">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">8</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/synchronization phase/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#592"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/proposed extensions/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1536">A.</A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_all_reduce/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1436"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_all_fcntl/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1855">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">8</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/mutual exclusion/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#969"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">4</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/program startup/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#130"><SPAN CLASS="arabic">5</SPAN>.<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_all_gather/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1252"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">3</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_affinitysize/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#940"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">5</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/barriers/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#588"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_global_lock_alloc/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#984"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">4</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_all_broadcast/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1185"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/file consistency/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1565">A..<SPAN CLASS="arabic">1</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#1598">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">3</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#1952">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">8</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/strict/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#192"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#354"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">5</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#386"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">5</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#755"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_all_fclose/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1759">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_lock/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1022"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">4</SPAN>.<SPAN CLASS="arabic">5</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/block size, default/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#430"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">5</SPAN>.<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/strictonthreads/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#2359">B..<SPAN CLASS="arabic">2</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_in_mysync/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1129"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">6</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/shared declarations, scalar/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#510"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">5</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/strict shared read/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#3160"><SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#148"><SPAN CLASS="arabic">5</SPAN>.<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">3</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#758"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#2334">B..<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_and/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1392"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/pointer-to-shared, casts/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#330"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">4</SPAN>.<SPAN CLASS="arabic">3</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_blocksizeof/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#187"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#271"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">4</SPAN>.<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">3</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_hint/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1719">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#1926">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">8</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_threadof/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#298"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">4</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#897"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#910"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/program order/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#153"><SPAN CLASS="arabic">5</SPAN>.<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">3</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#2691">B..<SPAN CLASS="arabic">6</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_max/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1398"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/block size, conversion/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#334"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">4</SPAN>.<SPAN CLASS="arabic">3</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_all_ftest_async/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1592">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#2200">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">7</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#2311">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">10</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_all_fwrite_list_shared/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#2175">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">4</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/__upc_version__/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#775"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_lock_free/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1004"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">4</SPAN>.<SPAN CLASS="arabic">4</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/precedes/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#2690">B..<SPAN CLASS="arabic">6</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_get_hints/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1928">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">8</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/__upc_io__/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1547">A..<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_rdwr/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1666">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_all_fread_local_async/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#2212">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_in_nosync/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1130"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">6</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/memory consistency/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#146"><SPAN CLASS="arabic">5</SPAN>.<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">3</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#593"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#1124"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">6</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#2329">B.</A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/common file pointer/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1578">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#1657">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">3</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#1886">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">8</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_io.h/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1548">A..<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_relaxed.h/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#802"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_excl/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1671">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_all_fwrite_list_local/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#2153">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">3</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_all_fwrite_local_async/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#2234">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">3</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_trunc/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1673">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_set_weak_ca_semantics/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1871">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">8</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_barrier/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#184"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#589"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_async_outstanding/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1948">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">8</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/file writing/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#2017">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">5</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#2152">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">3</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#2174">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">4</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#2197">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">7</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/locks/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#967"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">4</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/definite block size/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#433"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">5</SPAN>.<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#439"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">5</SPAN>.<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_logand/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1395"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_all_fwrite_list_shared_async/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#2289">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">8</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/predefined macros/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#769"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/sizeof/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#257"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">4</SPAN>.<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/broadcast/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1186"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/shared declarations, array/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#513"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">5</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/block size, definite/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#429"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">5</SPAN>.<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/__upc_collective__/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1177"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">3</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_all_gather_all/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1285"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">4</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_set_common_fp/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1894">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">8</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/implicit barriers/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#123"><SPAN CLASS="arabic">5</SPAN>.<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#595"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_out_mysync/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1126"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">6</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_elemsizeof/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#190"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#284"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">4</SPAN>.<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">4</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_phaseof/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#297"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">4</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#522"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">5</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/file size/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1808">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">5</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#1829">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">6</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#1840">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">7</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/memory copy/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1054"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">5</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/block size, automatically-computed/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#431"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">5</SPAN>.<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/main/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#131"><SPAN CLASS="arabic">5</SPAN>.<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_out_allsync/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1125"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">6</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_common_fp/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1667">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/program termination/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#136"><SPAN CLASS="arabic">5</SPAN>.<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/private object/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#3084"><SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_strict.h/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#799"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/continue/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#694"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_all_fread_list_shared_async/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#2267">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">6</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/shared declarations, restrictions/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#505"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">5</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_noncomm_func/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1400"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/block size, indefinite/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#428"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">5</SPAN>.<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/pointer equality/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#300"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">4</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/pointer-to-shared, type compatibility/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#440"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">5</SPAN>.<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/affinity/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#3110"><SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">3</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#302"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">4</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#898"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_all_fread_shared_async/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#2223">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/strictpairs/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#2358">B..<SPAN CLASS="arabic">2</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/potentialraces/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#2455">B..<SPAN CLASS="arabic">4</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/indefinite/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#437"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">5</SPAN>.<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/memory consistency, fence/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#2404">B..<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_wait/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#194"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#591"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/collective libarary/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1176"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">3</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/static threads environment/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#117"><SPAN CLASS="arabic">5</SPAN>.<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#515"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">5</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#787"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/data races/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#154"><SPAN CLASS="arabic">5</SPAN>.<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">3</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_all_fseek/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1788">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">4</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_flag_t/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1131"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">6</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#1551">A..<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_alloc/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#852"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">3</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_fence/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#193"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#611"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/thread creation/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#122"><SPAN CLASS="arabic">5</SPAN>.<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/memory consistency, locks/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#2402">B..<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/scatter/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1221"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/upc_set_strong_ca_semantics/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1616">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">3</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#1878">A..<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">8</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/threads/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#195"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#208"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#790"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/iso c/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#70"><SPAN CLASS="arabic">1</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#74"><SPAN CLASS="arabic">2</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/gather/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#1253"><SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">3</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/relaxed shared read/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#3180"><SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">3</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#150"><SPAN CLASS="arabic">5</SPAN>.<SPAN CLASS="arabic">1</SPAN>.<SPAN CLASS="arabic">2</SPAN>.<SPAN CLASS="arabic">3</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#760"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert <A HREF="|."$dir".q|upc-lang-spec.html#2336">B..<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/block size, declaration/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#459"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">5</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/conflicting/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#2370">B..<SPAN CLASS="arabic">2</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/pointer subtraction/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#301"><SPAN CLASS="arabic">6</SPAN>.<SPAN CLASS="arabic">4</SPAN>.<SPAN CLASS="arabic">2</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

$key = q/single-valued/;
$index{$key} .= q|<A HREF="|."$dir".q|upc-lang-spec.html#3220"><SPAN CLASS="arabic">3</SPAN>.<SPAN CLASS="arabic">7</SPAN>.<SPAN CLASS="arabic">1</SPAN></A>
 \vert |; 
$noresave{$key} = "$nosave";

# LaTeX2HTML 2008 (1.71)
# Printable index-keys from printable_key array.


$key = q/individual file pointer/;
$printable_key{$key} = q|individual file pointer| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_global_alloc/;
$printable_key{$key} = q|upc_global_alloc| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_all_fwait_async/;
$printable_key{$key} = q|upc_all_fwait_async| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/shared layout qualifier/;
$printable_key{$key} = q|shared layout qualifier| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_all_fread_list_shared/;
$printable_key{$key} = q|upc_all_fread_list_shared| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/shared object, clearing/;
$printable_key{$key} = q|shared object, clearing| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/keywords/;
$printable_key{$key} = q|keywords| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/dependsonthreads/;
$printable_key{$key} = q|DependsOnThreads| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_logor/;
$printable_key{$key} = q|UPC_LOGOR| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/shared access/;
$printable_key{$key} = q|shared access| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_all_fpreallocate/;
$printable_key{$key} = q|upc_all_fpreallocate| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_max_block_size/;
$printable_key{$key} = q|UPC_MAX_BLOCK_SIZE| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_all_scatter/;
$printable_key{$key} = q|upc_all_scatter| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_rdonly/;
$printable_key{$key} = q|UPC_RDONLY| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_all_fread_local/;
$printable_key{$key} = q|upc_all_fread_local| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_all_fset_size/;
$printable_key{$key} = q|upc_all_fset_size| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_all_fget_size/;
$printable_key{$key} = q|upc_all_fget_size| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/shared object, allocation/;
$printable_key{$key} = q|shared object, allocation| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/relaxed/;
$printable_key{$key} = q|relaxed| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_global_exit/;
$printable_key{$key} = q|upc_global_exit| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_local_alloc/;
$printable_key{$key} = q|upc_local_alloc| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/reduction/;
$printable_key{$key} = q|reduction| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_all_fsync/;
$printable_key{$key} = q|upc_all_fsync| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_local_memvec/;
$printable_key{$key} = q|upc_local_memvec| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_collective.h/;
$printable_key{$key} = q|upc_collective.h| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/synchronization/;
$printable_key{$key} = q|synchronization| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_individual_fp/;
$printable_key{$key} = q|UPC_INDIVIDUAL_FP| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_append/;
$printable_key{$key} = q|UPC_APPEND| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_filevec/;
$printable_key{$key} = q|upc_filevec| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_off_t/;
$printable_key{$key} = q|upc_off_t| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_memcpy/;
$printable_key{$key} = q|upc_memcpy| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_seek_set/;
$printable_key{$key} = q|UPC_SEEK_SET| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/relaxed shared write/;
$printable_key{$key} = q|relaxed shared write| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/memory consistency, collective library/;
$printable_key{$key} = q|memory consistency, collective library| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_unlock/;
$printable_key{$key} = q|upc_unlock| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/memory consistency, barriers/;
$printable_key{$key} = q|memory consistency, barriers| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_all_lock_alloc/;
$printable_key{$key} = q|upc_all_lock_alloc| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_all_fread_list_local/;
$printable_key{$key} = q|upc_all_fread_list_local| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_all_fread_shared/;
$printable_key{$key} = q|upc_all_fread_shared| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_get_fl/;
$printable_key{$key} = q|UPC_GET_FL| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/phase/;
$printable_key{$key} = q|phase| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_notify/;
$printable_key{$key} = q|upc_notify| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_set_hint/;
$printable_key{$key} = q|UPC_SET_HINT| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_wronly/;
$printable_key{$key} = q|UPC_WRONLY| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/gather, to all/;
$printable_key{$key} = q|gather, to all| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/access/;
$printable_key{$key} = q|access| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_func/;
$printable_key{$key} = q|UPC_FUNC| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_seek_end/;
$printable_key{$key} = q|UPC_SEEK_END| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_localsizeof/;
$printable_key{$key} = q|upc_localsizeof| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/sequential consistency/;
$printable_key{$key} = q|sequential consistency| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/__upc_static_threads__/;
$printable_key{$key} = q|__UPC_STATIC_THREADS__| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_set_individual_fp/;
$printable_key{$key} = q|UPC_SET_INDIVIDUAL_FP| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_all_alloc/;
$printable_key{$key} = q|upc_all_alloc| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/exchange/;
$printable_key{$key} = q|exchange| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_all_fwrite_local/;
$printable_key{$key} = q|upc_all_fwrite_local| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_seek_cur/;
$printable_key{$key} = q|UPC_SEEK_CUR| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_all_fwrite_shared/;
$printable_key{$key} = q|upc_all_fwrite_shared| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/file atomicity/;
$printable_key{$key} = q|file atomicity| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/shared object/;
$printable_key{$key} = q|shared object| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/mythread/;
$printable_key{$key} = q|MYTHREAD| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_addrfield/;
$printable_key{$key} = q|upc_addrfield| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/collective/;
$printable_key{$key} = q|collective| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/exit/;
$printable_key{$key} = q|exit| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/pointer-to-shared/;
$printable_key{$key} = q|pointer-to-shared| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/pointer-to-local/;
$printable_key{$key} = q|pointer-to-local| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_memput/;
$printable_key{$key} = q|upc_memput| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/file interoperability/;
$printable_key{$key} = q|file interoperability| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/shared/;
$printable_key{$key} = q|shared| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/shared object, copying/;
$printable_key{$key} = q|shared object, copying| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/strict shared write/;
$printable_key{$key} = q|strict shared write| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/struct field, address-of/;
$printable_key{$key} = q|struct field, address-of| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/indefinite block size/;
$printable_key{$key} = q|indefinite block size| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/pragmas/;
$printable_key{$key} = q|pragmas| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/memory allocation/;
$printable_key{$key} = q|memory allocation| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_get_fn/;
$printable_key{$key} = q|UPC_GET_FN| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_add/;
$printable_key{$key} = q|UPC_ADD| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/pointer-to-shared, null/;
$printable_key{$key} = q|pointer-to-shared, null| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/file flush/;
$printable_key{$key} = q|file flush| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_all_fwrite_shared_async/;
$printable_key{$key} = q|upc_all_fwrite_shared_async| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/dynamic threads environment/;
$printable_key{$key} = q|dynamic THREADS environment| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_free/;
$printable_key{$key} = q|upc_free| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_min/;
$printable_key{$key} = q|UPC_MIN| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_all_reduce_prefix/;
$printable_key{$key} = q|upc_all_reduce_prefix| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/global address space/;
$printable_key{$key} = q|global address space| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_op_t/;
$printable_key{$key} = q|upc_op_t| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/block size/;
$printable_key{$key} = q|block size| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/thread/;
$printable_key{$key} = q|thread| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_in_allsync/;
$printable_key{$key} = q|UPC_IN_ALLSYNC| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_or/;
$printable_key{$key} = q|UPC_OR| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_forall/;
$printable_key{$key} = q|upc_forall| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_mult/;
$printable_key{$key} = q|UPC_MULT| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/__upc_dynamic_threads__/;
$printable_key{$key} = q|__UPC_DYNAMIC_THREADS__| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/pointer addition/;
$printable_key{$key} = q|pointer addition| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_out_nosync/;
$printable_key{$key} = q|UPC_OUT_NOSYNC| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/file hints/;
$printable_key{$key} = q|file hints| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/allstrict/;
$printable_key{$key} = q|AllStrict| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc/;
$printable_key{$key} = q|UPC| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/object/;
$printable_key{$key} = q|object| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_lock_t/;
$printable_key{$key} = q|upc_lock_t| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/parallel loop/;
$printable_key{$key} = q|parallel loop| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_shared_memvec/;
$printable_key{$key} = q|upc_shared_memvec| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/prefix reduction/;
$printable_key{$key} = q|prefix reduction| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/feature macros/;
$printable_key{$key} = q|feature macros| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/asynchronous i\/o/;
$printable_key{$key} = q|asynchronous I/O| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/pointer-to-shared, generic/;
$printable_key{$key} = q|pointer-to-shared, generic| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/pointer-to-shared, conversion/;
$printable_key{$key} = q|pointer-to-shared, conversion| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/blocking factor/;
$printable_key{$key} = q|blocking factor| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_all_fwrite_list_local_async/;
$printable_key{$key} = q|upc_all_fwrite_list_local_async| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_memset/;
$printable_key{$key} = q|upc_memset| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/__upc__/;
$printable_key{$key} = q|__UPC__| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_file_t/;
$printable_key{$key} = q|upc_file_t| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_memget/;
$printable_key{$key} = q|upc_memget| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_all_fopen/;
$printable_key{$key} = q|upc_all_fopen| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/file seek/;
$printable_key{$key} = q|file seek| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/shared declarations, examples/;
$printable_key{$key} = q|shared declarations, examples| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_resetphase/;
$printable_key{$key} = q|upc_resetphase| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/file open/;
$printable_key{$key} = q|file open| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/file pointer/;
$printable_key{$key} = q|file pointer| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/file reading/;
$printable_key{$key} = q|file reading| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_lock_attempt/;
$printable_key{$key} = q|upc_lock_attempt| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_xor/;
$printable_key{$key} = q|UPC_XOR| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/shared array/;
$printable_key{$key} = q|shared array| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/tokens/;
$printable_key{$key} = q|tokens| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_get_fp/;
$printable_key{$key} = q|UPC_GET_FP| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/end of file/;
$printable_key{$key} = q|end of file| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/memory consistency, non-collective library/;
$printable_key{$key} = q|memory consistency, non-collective library| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_create/;
$printable_key{$key} = q|UPC_CREATE| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_delete_on_close/;
$printable_key{$key} = q|UPC_DELETE_ON_CLOSE| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/null strict access/;
$printable_key{$key} = q|null strict access| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/permute/;
$printable_key{$key} = q|permute| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_strong_ca/;
$printable_key{$key} = q|UPC_STRONG_CA| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_all_exchange/;
$printable_key{$key} = q|upc_all_exchange| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/file close/;
$printable_key{$key} = q|file close| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/memory consistency, examples/;
$printable_key{$key} = q|memory consistency, examples| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/list i\/o/;
$printable_key{$key} = q|list I/O| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_all_fread_list_local_async/;
$printable_key{$key} = q|upc_all_fread_list_local_async| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_all_permute/;
$printable_key{$key} = q|upc_all_permute| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/local access/;
$printable_key{$key} = q|local access| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/work sharing/;
$printable_key{$key} = q|work sharing| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_get_ca_semantics/;
$printable_key{$key} = q|UPC_GET_CA_SEMANTICS| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/synchronization phase/;
$printable_key{$key} = q|synchronization phase| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/proposed extensions/;
$printable_key{$key} = q|proposed extensions| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_all_reduce/;
$printable_key{$key} = q|upc_all_reduce| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_all_fcntl/;
$printable_key{$key} = q|upc_all_fcntl| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/mutual exclusion/;
$printable_key{$key} = q|mutual exclusion| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/program startup/;
$printable_key{$key} = q|program startup| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_all_gather/;
$printable_key{$key} = q|upc_all_gather| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_affinitysize/;
$printable_key{$key} = q|upc_affinitysize| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/barriers/;
$printable_key{$key} = q|barriers| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_global_lock_alloc/;
$printable_key{$key} = q|upc_global_lock_alloc| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_all_broadcast/;
$printable_key{$key} = q|upc_all_broadcast| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/file consistency/;
$printable_key{$key} = q|file consistency| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/strict/;
$printable_key{$key} = q|strict| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_all_fclose/;
$printable_key{$key} = q|upc_all_fclose| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_lock/;
$printable_key{$key} = q|upc_lock| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/block size, default/;
$printable_key{$key} = q|block size, default| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/strictonthreads/;
$printable_key{$key} = q|StrictOnThreads| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_in_mysync/;
$printable_key{$key} = q|UPC_IN_MYSYNC| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/shared declarations, scalar/;
$printable_key{$key} = q|shared declarations, scalar| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/strict shared read/;
$printable_key{$key} = q|strict shared read| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_and/;
$printable_key{$key} = q|UPC_AND| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/pointer-to-shared, casts/;
$printable_key{$key} = q|pointer-to-shared, casts| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_blocksizeof/;
$printable_key{$key} = q|upc_blocksizeof| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_hint/;
$printable_key{$key} = q|upc_hint| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_threadof/;
$printable_key{$key} = q|upc_threadof| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/program order/;
$printable_key{$key} = q|program order| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_max/;
$printable_key{$key} = q|UPC_MAX| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/block size, conversion/;
$printable_key{$key} = q|block size, conversion| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_all_ftest_async/;
$printable_key{$key} = q|upc_all_ftest_async| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_all_fwrite_list_shared/;
$printable_key{$key} = q|upc_all_fwrite_list_shared| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/__upc_version__/;
$printable_key{$key} = q|__UPC_VERSION__| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_lock_free/;
$printable_key{$key} = q|upc_lock_free| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/precedes/;
$printable_key{$key} = q|Precedes| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_get_hints/;
$printable_key{$key} = q|UPC_GET_HINTS| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/__upc_io__/;
$printable_key{$key} = q|__UPC_IO__| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_rdwr/;
$printable_key{$key} = q|UPC_RDWR| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_all_fread_local_async/;
$printable_key{$key} = q|upc_all_fread_local_async| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_in_nosync/;
$printable_key{$key} = q|UPC_IN_NOSYNC| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/memory consistency/;
$printable_key{$key} = q|memory consistency| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/common file pointer/;
$printable_key{$key} = q|common file pointer| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_io.h/;
$printable_key{$key} = q|upc_io.h| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_relaxed.h/;
$printable_key{$key} = q|upc_relaxed.h| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_excl/;
$printable_key{$key} = q|UPC_EXCL| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_all_fwrite_list_local/;
$printable_key{$key} = q|upc_all_fwrite_list_local| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_all_fwrite_local_async/;
$printable_key{$key} = q|upc_all_fwrite_local_async| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_trunc/;
$printable_key{$key} = q|UPC_TRUNC| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_set_weak_ca_semantics/;
$printable_key{$key} = q|UPC_SET_WEAK_CA_SEMANTICS| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_barrier/;
$printable_key{$key} = q|upc_barrier| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_async_outstanding/;
$printable_key{$key} = q|UPC_ASYNC_OUTSTANDING| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/file writing/;
$printable_key{$key} = q|file writing| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/locks/;
$printable_key{$key} = q|locks| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/definite block size/;
$printable_key{$key} = q|definite block size| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_logand/;
$printable_key{$key} = q|UPC_LOGAND| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_all_fwrite_list_shared_async/;
$printable_key{$key} = q|upc_all_fwrite_list_shared_async| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/predefined macros/;
$printable_key{$key} = q|predefined macros| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/sizeof/;
$printable_key{$key} = q|sizeof| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/broadcast/;
$printable_key{$key} = q|broadcast| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/shared declarations, array/;
$printable_key{$key} = q|shared declarations, array| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/block size, definite/;
$printable_key{$key} = q|block size, definite| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/__upc_collective__/;
$printable_key{$key} = q|__UPC_COLLECTIVE__| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_all_gather_all/;
$printable_key{$key} = q|upc_all_gather_all| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_set_common_fp/;
$printable_key{$key} = q|UPC_SET_COMMON_FP| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/implicit barriers/;
$printable_key{$key} = q|implicit barriers| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_out_mysync/;
$printable_key{$key} = q|UPC_OUT_MYSYNC| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_elemsizeof/;
$printable_key{$key} = q|upc_elemsizeof| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_phaseof/;
$printable_key{$key} = q|upc_phaseof| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/file size/;
$printable_key{$key} = q|file size| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/memory copy/;
$printable_key{$key} = q|memory copy| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/block size, automatically-computed/;
$printable_key{$key} = q|block size, automatically-computed| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/main/;
$printable_key{$key} = q|main| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_out_allsync/;
$printable_key{$key} = q|UPC_OUT_ALLSYNC| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_common_fp/;
$printable_key{$key} = q|UPC_COMMON_FP| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/program termination/;
$printable_key{$key} = q|program termination| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/private object/;
$printable_key{$key} = q|private object| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_strict.h/;
$printable_key{$key} = q|upc_strict.h| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/continue/;
$printable_key{$key} = q|continue| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_all_fread_list_shared_async/;
$printable_key{$key} = q|upc_all_fread_list_shared_async| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/shared declarations, restrictions/;
$printable_key{$key} = q|shared declarations, restrictions| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_noncomm_func/;
$printable_key{$key} = q|UPC_NONCOMM_FUNC| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/block size, indefinite/;
$printable_key{$key} = q|block size, indefinite| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/pointer equality/;
$printable_key{$key} = q|pointer equality| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/pointer-to-shared, type compatibility/;
$printable_key{$key} = q|pointer-to-shared, type compatibility| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/affinity/;
$printable_key{$key} = q|affinity| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_all_fread_shared_async/;
$printable_key{$key} = q|upc_all_fread_shared_async| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/strictpairs/;
$printable_key{$key} = q|StrictPairs| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/potentialraces/;
$printable_key{$key} = q|PotentialRaces| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/indefinite/;
$printable_key{$key} = q|indefinite| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/memory consistency, fence/;
$printable_key{$key} = q|memory consistency, fence| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_wait/;
$printable_key{$key} = q|upc_wait| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/collective libarary/;
$printable_key{$key} = q|collective libarary| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/static threads environment/;
$printable_key{$key} = q|static THREADS environment| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/data races/;
$printable_key{$key} = q|data races| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_all_fseek/;
$printable_key{$key} = q|upc_all_fseek| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_flag_t/;
$printable_key{$key} = q|upc_flag_t| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_alloc/;
$printable_key{$key} = q|upc_alloc| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_fence/;
$printable_key{$key} = q|upc_fence| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/thread creation/;
$printable_key{$key} = q|thread creation| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/memory consistency, locks/;
$printable_key{$key} = q|memory consistency, locks| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/scatter/;
$printable_key{$key} = q|scatter| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/upc_set_strong_ca_semantics/;
$printable_key{$key} = q|UPC_SET_STRONG_CA_SEMANTICS| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/threads/;
$printable_key{$key} = q|THREADS| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/iso c/;
$printable_key{$key} = q|ISO C| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/gather/;
$printable_key{$key} = q|gather| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/relaxed shared read/;
$printable_key{$key} = q|relaxed shared read| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/block size, declaration/;
$printable_key{$key} = q|block size, declaration| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/conflicting/;
$printable_key{$key} = q|Conflicting| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/pointer subtraction/;
$printable_key{$key} = q|pointer subtraction| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/single-valued/;
$printable_key{$key} = q|single-valued| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

1;

