# LaTeX2HTML 2008 (1.71)
# Associate sections original text with physical files.


$key = q/0 0 0 10 2 2 3 0 0 0 0 0 0 0 0 0 0 0 0 0/;

$key = q/0 0 0 9 4 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$section_info{$key} = '5%:%'."$dir".q|upc-lang-spec.html%:%<SPAN CLASS="arabic">3</SPAN> Cast and assignment expressions%:%| unless ($section_info{$key}); 
$noresave{$key} = "$nosave";
$done{"${dir}upc-lang-spec.html"} = 1;

$key = q/0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$section_info{$key} = '3%:%'."$dir".q|upc-lang-spec.html%:%Acknowledgments%:%| unless ($section_info{$key}); 
$noresave{$key} = "$nosave";
$done{"${dir}upc-lang-spec.html"} = 1;

$key = q/0 0 0 9 4 1 3 0 0 0 0 0 0 0 0 0 0 0 0 0/;

$key = q/0 0 0 10 2 2 2 0 0 0 0 0 0 0 0 0 0 0 0 0/;

$key = q/0 0 0 9 4 1 4 0 0 0 0 0 0 0 0 0 0 0 0 0/;

$key = q/0 0 0 12 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$section_info{$key} = '4%:%'."$dir".q|upc-lang-spec.html%:%<SPAN CLASS="arabic">4</SPAN> Properties Implied by the Specification%:%| unless ($section_info{$key}); 
$noresave{$key} = "$nosave";
$done{"${dir}upc-lang-spec.html"} = 1;

$key = q/0 0 0 9 3 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$section_info{$key} = '5%:%'."$dir".q|upc-lang-spec.html%:%<SPAN CLASS="arabic">3</SPAN> <TT>UPC_MAX_BLOCK_SIZE</TT>%:%| unless ($section_info{$key}); 
$noresave{$key} = "$nosave";
$done{"${dir}upc-lang-spec.html"} = 1;

$key = q/0 0 0 10 2 5 1 0 0 0 0 0 0 0 0 0 0 0 0 0/;

$key = q/0 0 0 9 7 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$section_info{$key} = '4%:%'."$dir".q|upc-lang-spec.html%:%<SPAN CLASS="arabic">7</SPAN> Preprocessing directives%:%| unless ($section_info{$key}); 
$noresave{$key} = "$nosave";
$done{"${dir}upc-lang-spec.html"} = 1;

$key = q/0 0 0 12 6 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$section_info{$key} = '4%:%'."$dir".q|upc-lang-spec.html%:%<SPAN CLASS="arabic">6</SPAN> Formal Definition of Precedes%:%| unless ($section_info{$key}); 
$noresave{$key} = "$nosave";
$done{"${dir}upc-lang-spec.html"} = 1;

$key = q/0 0 0 10 2 3 2 0 0 0 0 0 0 0 0 0 0 0 0 0/;

$key = q/0 0 0 7 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$section_info{$key} = '3%:%'."$dir".q|upc-lang-spec.html%:%<SPAN CLASS="arabic">4</SPAN> Conformance%:%| unless ($section_info{$key}); 
$noresave{$key} = "$nosave";
$done{"${dir}upc-lang-spec.html"} = 1;

$key = q/0 0 0 10 2 4 5 0 0 0 0 0 0 0 0 0 0 0 0 0/;

$key = q/0 0 0 10 2 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$section_info{$key} = '5%:%'."$dir".q|upc-lang-spec.html%:%<SPAN CLASS="arabic">4</SPAN> Lock functions%:%| unless ($section_info{$key}); 
$noresave{$key} = "$nosave";
$done{"${dir}upc-lang-spec.html"} = 1;

$key = q/0 0 0 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$section_info{$key} = '3%:%'."$dir".q|upc-lang-spec.html%:%<SPAN CLASS="arabic">1</SPAN> Scope%:%| unless ($section_info{$key}); 
$noresave{$key} = "$nosave";
$done{"${dir}upc-lang-spec.html"} = 1;

$key = q/0 0 0 12 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$section_info{$key} = '3%:%'."$dir".q|upc-lang-spec.html%:%B. Formal UPC Memory Consistency Semantics%:%| unless ($section_info{$key}); 
$noresave{$key} = "$nosave";
$done{"${dir}upc-lang-spec.html"} = 1;

$key = q/0 0 0 16 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$section_info{$key} = '3%:%'."$dir".q|upc-lang-spec.html%:%About this document ...%:%| unless ($section_info{$key}); 
$noresave{$key} = "$nosave";
$done{"${dir}upc-lang-spec.html"} = 1;

$key = q/0 0 0 12 5 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$section_info{$key} = '4%:%'."$dir".q|upc-lang-spec.html%:%<SPAN CLASS="arabic">5</SPAN> Examples%:%| unless ($section_info{$key}); 
$noresave{$key} = "$nosave";
$done{"${dir}upc-lang-spec.html"} = 1;

$key = q/0 0 0 9 4 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$section_info{$key} = '5%:%'."$dir".q|upc-lang-spec.html%:%<SPAN CLASS="arabic">1</SPAN> Unary Operators%:%| unless ($section_info{$key}); 
$noresave{$key} = "$nosave";
$done{"${dir}upc-lang-spec.html"} = 1;

$key = q/0 0 0 11 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$section_info{$key} = '3%:%'."$dir".q|upc-lang-spec.html%:%A. Proposed Additions and Extensions%:%| unless ($section_info{$key}); 
$noresave{$key} = "$nosave";
$done{"${dir}upc-lang-spec.html"} = 1;

$key = q/0 0 0 9 6 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$section_info{$key} = '4%:%'."$dir".q|upc-lang-spec.html%:%<SPAN CLASS="arabic">6</SPAN> Statements and blocks%:%| unless ($section_info{$key}); 
$noresave{$key} = "$nosave";
$done{"${dir}upc-lang-spec.html"} = 1;

$key = q/0 0 0 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$section_info{$key} = '3%:%'."$dir".q|upc-lang-spec.html%:%Introduction%:%| unless ($section_info{$key}); 
$noresave{$key} = "$nosave";
$done{"${dir}upc-lang-spec.html"} = 1;

$key = q/0 0 0 9 4 1 2 0 0 0 0 0 0 0 0 0 0 0 0 0/;

$key = q/0 0 0 12 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$section_info{$key} = '4%:%'."$dir".q|upc-lang-spec.html%:%<SPAN CLASS="arabic">2</SPAN> Memory Access Model%:%| unless ($section_info{$key}); 
$noresave{$key} = "$nosave";
$done{"${dir}upc-lang-spec.html"} = 1;

$key = q/0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$section_info{$key} = '0%:%'."$dir".q|upc-lang-spec.html%:%UPC Language Specifications
V1.3 %:%| unless ($section_info{$key}); 
$noresave{$key} = "$nosave";
$done{"${dir}upc-lang-spec.html"} = 1;

$key = q/0 0 0 12 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$section_info{$key} = '4%:%'."$dir".q|upc-lang-spec.html%:%<SPAN CLASS="arabic">1</SPAN> Definitions%:%| unless ($section_info{$key}); 
$noresave{$key} = "$nosave";
$done{"${dir}upc-lang-spec.html"} = 1;

$key = q/0 0 0 8 1 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$section_info{$key} = '5%:%'."$dir".q|upc-lang-spec.html%:%<SPAN CLASS="arabic">1</SPAN> Translation environment%:%| unless ($section_info{$key}); 
$noresave{$key} = "$nosave";
$done{"${dir}upc-lang-spec.html"} = 1;

$key = q/0 0 0 10 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$section_info{$key} = '3%:%'."$dir".q|upc-lang-spec.html%:%<SPAN CLASS="arabic">7</SPAN> Library%:%| unless ($section_info{$key}); 
$noresave{$key} = "$nosave";
$done{"${dir}upc-lang-spec.html"} = 1;

$key = q/0 0 0 10 2 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$section_info{$key} = '5%:%'."$dir".q|upc-lang-spec.html%:%<SPAN CLASS="arabic">2</SPAN> Shared memory allocation functions%:%| unless ($section_info{$key}); 
$noresave{$key} = "$nosave";
$done{"${dir}upc-lang-spec.html"} = 1;

$key = q/0 0 0 10 2 2 1 0 0 0 0 0 0 0 0 0 0 0 0 0/;

$key = q/0 0 0 8 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$section_info{$key} = '3%:%'."$dir".q|upc-lang-spec.html%:%<SPAN CLASS="arabic">5</SPAN> Environment%:%| unless ($section_info{$key}); 
$noresave{$key} = "$nosave";
$done{"${dir}upc-lang-spec.html"} = 1;

$key = q/0 0 0 10 2 5 2 0 0 0 0 0 0 0 0 0 0 0 0 0/;

$key = q/0 0 0 5 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$section_info{$key} = '3%:%'."$dir".q|upc-lang-spec.html%:%<SPAN CLASS="arabic">2</SPAN> Normative references%:%| unless ($section_info{$key}); 
$noresave{$key} = "$nosave";
$done{"${dir}upc-lang-spec.html"} = 1;

$key = q/0 0 0 10 2 5 4 0 0 0 0 0 0 0 0 0 0 0 0 0/;

$key = q/0 0 0 9 4 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$section_info{$key} = '5%:%'."$dir".q|upc-lang-spec.html%:%<SPAN CLASS="arabic">4</SPAN> Address operators%:%| unless ($section_info{$key}); 
$noresave{$key} = "$nosave";
$done{"${dir}upc-lang-spec.html"} = 1;

$key = q/0 0 0 8 1 1 1 0 0 0 0 0 0 0 0 0 0 0 0 0/;

$key = q/0 0 0 9 4 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$section_info{$key} = '5%:%'."$dir".q|upc-lang-spec.html%:%<SPAN CLASS="arabic">2</SPAN> Pointer-to-shared arithmetic%:%| unless ($section_info{$key}); 
$noresave{$key} = "$nosave";
$done{"${dir}upc-lang-spec.html"} = 1;

$key = q/0 0 0 8 1 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$section_info{$key} = '5%:%'."$dir".q|upc-lang-spec.html%:%<SPAN CLASS="arabic">2</SPAN> Execution environment%:%| unless ($section_info{$key}); 
$noresave{$key} = "$nosave";
$done{"${dir}upc-lang-spec.html"} = 1;

$key = q/0 0 0 9 7 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$section_info{$key} = '5%:%'."$dir".q|upc-lang-spec.html%:%<SPAN CLASS="arabic">1</SPAN> UPC pragmas%:%| unless ($section_info{$key}); 
$noresave{$key} = "$nosave";
$done{"${dir}upc-lang-spec.html"} = 1;

$key = q/0 0 0 10 2 5 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$section_info{$key} = '5%:%'."$dir".q|upc-lang-spec.html%:%<SPAN CLASS="arabic">5</SPAN> Shared string handling functions%:%| unless ($section_info{$key}); 
$noresave{$key} = "$nosave";
$done{"${dir}upc-lang-spec.html"} = 1;

$key = q/0 0 0 9 6 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$section_info{$key} = '5%:%'."$dir".q|upc-lang-spec.html%:%<SPAN CLASS="arabic">2</SPAN> Iteration statements%:%| unless ($section_info{$key}); 
$noresave{$key} = "$nosave";
$done{"${dir}upc-lang-spec.html"} = 1;

$key = q/0 0 0 10 2 3 3 0 0 0 0 0 0 0 0 0 0 0 0 0/;

$key = q/0 0 0 9 5 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$section_info{$key} = '5%:%'."$dir".q|upc-lang-spec.html%:%<SPAN CLASS="arabic">2</SPAN> Declarators%:%| unless ($section_info{$key}); 
$noresave{$key} = "$nosave";
$done{"${dir}upc-lang-spec.html"} = 1;

$key = q/0 0 0 10 2 6 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$section_info{$key} = '5%:%'."$dir".q|upc-lang-spec.html%:%<SPAN CLASS="arabic">6</SPAN> Memory Semantics of Library Functions%:%| unless ($section_info{$key}); 
$noresave{$key} = "$nosave";
$done{"${dir}upc-lang-spec.html"} = 1;

$key = q/0 0 0 12 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$section_info{$key} = '4%:%'."$dir".q|upc-lang-spec.html%:%<SPAN CLASS="arabic">3</SPAN> Consistency Semantics of Standard Libraries and Language Operations%:%| unless ($section_info{$key}); 
$noresave{$key} = "$nosave";
$done{"${dir}upc-lang-spec.html"} = 1;

$key = q/0 0 0 12 3 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$section_info{$key} = '5%:%'."$dir".q|upc-lang-spec.html%:%<SPAN CLASS="arabic">2</SPAN> Consistency Semantics of Standard Library Calls%:%| unless ($section_info{$key}); 
$noresave{$key} = "$nosave";
$done{"${dir}upc-lang-spec.html"} = 1;

$key = q/0 0 0 12 3 2 1 0 0 0 0 0 0 0 0 0 0 0 0 0/;

$key = q/0 0 0 15 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$section_info{$key} = '3%:%'."$dir".q|upc-lang-spec.html%:%Index%:%| unless ($section_info{$key}); 
$noresave{$key} = "$nosave";
$done{"${dir}upc-lang-spec.html"} = 1;

$key = q/0 0 0 8 1 2 2 0 0 0 0 0 0 0 0 0 0 0 0 0/;

$key = q/0 0 0 10 2 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$section_info{$key} = '5%:%'."$dir".q|upc-lang-spec.html%:%<SPAN CLASS="arabic">1</SPAN> Termination of all threads%:%| unless ($section_info{$key}); 
$noresave{$key} = "$nosave";
$done{"${dir}upc-lang-spec.html"} = 1;

$key = q/0 0 0 10 2 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$section_info{$key} = '5%:%'."$dir".q|upc-lang-spec.html%:%<SPAN CLASS="arabic">3</SPAN> Pointer-to-shared manipulation functions%:%| unless ($section_info{$key}); 
$noresave{$key} = "$nosave";
$done{"${dir}upc-lang-spec.html"} = 1;

$key = q/0 0 0 8 1 2 1 0 0 0 0 0 0 0 0 0 0 0 0 0/;

$key = q/0 0 0 12 3 2 2 0 0 0 0 0 0 0 0 0 0 0 0 0/;

$key = q/0 0 0 10 2 4 3 0 0 0 0 0 0 0 0 0 0 0 0 0/;

$key = q/0 0 0 14 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$section_info{$key} = '3%:%'."$dir".q|upc-lang-spec.html%:%References%:%| unless ($section_info{$key}); 
$noresave{$key} = "$nosave";
$done{"${dir}upc-lang-spec.html"} = 1;

$key = q/0 0 0 9 4 1 1 0 0 0 0 0 0 0 0 0 0 0 0 0/;

$key = q/0 0 0 9 5 2 1 0 0 0 0 0 0 0 0 0 0 0 0 0/;

$key = q/0 0 0 10 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$section_info{$key} = '4%:%'."$dir".q|upc-lang-spec.html%:%<SPAN CLASS="arabic">1</SPAN> Standard headers%:%| unless ($section_info{$key}); 
$noresave{$key} = "$nosave";
$done{"${dir}upc-lang-spec.html"} = 1;

$key = q/0 0 0 10 2 3 4 0 0 0 0 0 0 0 0 0 0 0 0 0/;

$key = q/0 0 0 9 7 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$section_info{$key} = '5%:%'."$dir".q|upc-lang-spec.html%:%<SPAN CLASS="arabic">2</SPAN> Predefined macro names%:%| unless ($section_info{$key}); 
$noresave{$key} = "$nosave";
$done{"${dir}upc-lang-spec.html"} = 1;

$key = q/0 0 0 10 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$section_info{$key} = '4%:%'."$dir".q|upc-lang-spec.html%:%<SPAN CLASS="arabic">2</SPAN> UPC utilities <TT>&lt;upc.h&gt;</TT>%:%| unless ($section_info{$key}); 
$noresave{$key} = "$nosave";
$done{"${dir}upc-lang-spec.html"} = 1;

$key = q/0 0 0 10 2 3 5 0 0 0 0 0 0 0 0 0 0 0 0 0/;

$key = q/0 0 0 9 6 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$section_info{$key} = '5%:%'."$dir".q|upc-lang-spec.html%:%<SPAN CLASS="arabic">1</SPAN> Barrier statements%:%| unless ($section_info{$key}); 
$noresave{$key} = "$nosave";
$done{"${dir}upc-lang-spec.html"} = 1;

$key = q/0 0 0 9 3 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$section_info{$key} = '5%:%'."$dir".q|upc-lang-spec.html%:%<SPAN CLASS="arabic">1</SPAN> <TT>THREADS</TT>%:%| unless ($section_info{$key}); 
$noresave{$key} = "$nosave";
$done{"${dir}upc-lang-spec.html"} = 1;

$key = q/0 0 0 10 2 4 2 0 0 0 0 0 0 0 0 0 0 0 0 0/;

$key = q/0 0 0 9 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$section_info{$key} = '4%:%'."$dir".q|upc-lang-spec.html%:%<SPAN CLASS="arabic">3</SPAN> Predefined identifiers%:%| unless ($section_info{$key}); 
$noresave{$key} = "$nosave";
$done{"${dir}upc-lang-spec.html"} = 1;

$key = q/0 0 0 10 2 5 3 0 0 0 0 0 0 0 0 0 0 0 0 0/;

$key = q/0 0 0 9 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$section_info{$key} = '4%:%'."$dir".q|upc-lang-spec.html%:%<SPAN CLASS="arabic">1</SPAN> Notations%:%| unless ($section_info{$key}); 
$noresave{$key} = "$nosave";
$done{"${dir}upc-lang-spec.html"} = 1;

$key = q/0 0 0 9 3 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$section_info{$key} = '5%:%'."$dir".q|upc-lang-spec.html%:%<SPAN CLASS="arabic">2</SPAN> <TT>MYTHREAD</TT>%:%| unless ($section_info{$key}); 
$noresave{$key} = "$nosave";
$done{"${dir}upc-lang-spec.html"} = 1;

$key = q/0 0 0 9 5 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$section_info{$key} = '4%:%'."$dir".q|upc-lang-spec.html%:%<SPAN CLASS="arabic">5</SPAN> Declarations%:%| unless ($section_info{$key}); 
$noresave{$key} = "$nosave";
$done{"${dir}upc-lang-spec.html"} = 1;

$key = q/0 0 0 9 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$section_info{$key} = '3%:%'."$dir".q|upc-lang-spec.html%:%<SPAN CLASS="arabic">6</SPAN> Language%:%| unless ($section_info{$key}); 
$noresave{$key} = "$nosave";
$done{"${dir}upc-lang-spec.html"} = 1;

$key = q/0 0 0 13 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$section_info{$key} = '3%:%'."$dir".q|upc-lang-spec.html%:%C. UPC versus C Standard Section Numbering%:%| unless ($section_info{$key}); 
$noresave{$key} = "$nosave";
$done{"${dir}upc-lang-spec.html"} = 1;

$key = q/0 0 0 6 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$section_info{$key} = '3%:%'."$dir".q|upc-lang-spec.html%:%<SPAN CLASS="arabic">3</SPAN> Terms, definitions and symbols%:%| unless ($section_info{$key}); 
$noresave{$key} = "$nosave";
$done{"${dir}upc-lang-spec.html"} = 1;

$key = q/0 0 0 8 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$section_info{$key} = '4%:%'."$dir".q|upc-lang-spec.html%:%<SPAN CLASS="arabic">1</SPAN> Conceptual models%:%| unless ($section_info{$key}); 
$noresave{$key} = "$nosave";
$done{"${dir}upc-lang-spec.html"} = 1;

$key = q/0 0 0 10 2 3 1 0 0 0 0 0 0 0 0 0 0 0 0 0/;

$key = q/0 0 0 12 3 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$section_info{$key} = '5%:%'."$dir".q|upc-lang-spec.html%:%<SPAN CLASS="arabic">1</SPAN> Consistency Semantics of Synchronization Operations%:%| unless ($section_info{$key}); 
$noresave{$key} = "$nosave";
$done{"${dir}upc-lang-spec.html"} = 1;

$key = q/0 0 0 10 2 2 5 0 0 0 0 0 0 0 0 0 0 0 0 0/;

$key = q/0 0 0 9 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$section_info{$key} = '4%:%'."$dir".q|upc-lang-spec.html%:%<SPAN CLASS="arabic">2</SPAN> Keywords%:%| unless ($section_info{$key}); 
$noresave{$key} = "$nosave";
$done{"${dir}upc-lang-spec.html"} = 1;

$key = q/0 0 0 9 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$section_info{$key} = '4%:%'."$dir".q|upc-lang-spec.html%:%<SPAN CLASS="arabic">4</SPAN> Expressions%:%| unless ($section_info{$key}); 
$noresave{$key} = "$nosave";
$done{"${dir}upc-lang-spec.html"} = 1;

$key = q/0 0 0 10 2 4 1 0 0 0 0 0 0 0 0 0 0 0 0 0/;

$key = q/0 0 0 8 1 2 3 0 0 0 0 0 0 0 0 0 0 0 0 0/;

$key = q/0 0 0 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$section_info{$key} = '3%:%'."$dir".q|upc-lang-spec.html%:%Contents%:%| unless ($section_info{$key}); 
$noresave{$key} = "$nosave";
$done{"${dir}upc-lang-spec.html"} = 1;

$key = q/0 0 0 9 5 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$section_info{$key} = '5%:%'."$dir".q|upc-lang-spec.html%:%<SPAN CLASS="arabic">1</SPAN> Type qualifiers%:%| unless ($section_info{$key}); 
$noresave{$key} = "$nosave";
$done{"${dir}upc-lang-spec.html"} = 1;

$key = q/0 0 0 10 2 4 7 0 0 0 0 0 0 0 0 0 0 0 0 0/;

$key = q/0 0 0 10 2 4 6 0 0 0 0 0 0 0 0 0 0 0 0 0/;

$key = q/0 0 0 10 2 2 4 0 0 0 0 0 0 0 0 0 0 0 0 0/;

$key = q/0 0 0 9 5 1 1 0 0 0 0 0 0 0 0 0 0 0 0 0/;

$key = q/0 0 0 10 2 4 4 0 0 0 0 0 0 0 0 0 0 0 0 0/;

1;

