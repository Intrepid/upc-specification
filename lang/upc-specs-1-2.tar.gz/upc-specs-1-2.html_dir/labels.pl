# LaTeX2HTML 2008 (1.71)
# Associate labels original text with physical files.


$key = q/upc-flag-t/;
$external_labels{$key} = "$URL/" . q|upc-specs-1-2.html|; 
$noresave{$key} = "$nosave";

$key = q/upc_barrier/;
$external_labels{$key} = "$URL/" . q|upc-specs-1-2.html|; 
$noresave{$key} = "$nosave";

$key = q/upc_addrfield/;
$external_labels{$key} = "$URL/" . q|upc-specs-1-2.html|; 
$noresave{$key} = "$nosave";

$key = q/upc-io-common/;
$external_labels{$key} = "$URL/" . q|upc-specs-1-2.html|; 
$noresave{$key} = "$nosave";

$key = q/io-func-read/;
$external_labels{$key} = "$URL/" . q|upc-specs-1-2.html|; 
$noresave{$key} = "$nosave";

$key = q/strict_relaxed/;
$external_labels{$key} = "$URL/" . q|upc-specs-1-2.html|; 
$noresave{$key} = "$nosave";

$key = q/max_block_size/;
$external_labels{$key} = "$URL/" . q|upc-specs-1-2.html|; 
$noresave{$key} = "$nosave";

$key = q/declarator/;
$external_labels{$key} = "$URL/" . q|upc-specs-1-2.html|; 
$noresave{$key} = "$nosave";

$key = q/upc_threadof/;
$external_labels{$key} = "$URL/" . q|upc-specs-1-2.html|; 
$noresave{$key} = "$nosave";

$key = q/upc-op-t-section/;
$external_labels{$key} = "$URL/" . q|upc-specs-1-2.html|; 
$noresave{$key} = "$nosave";

$key = q/def-access/;
$external_labels{$key} = "$URL/" . q|upc-specs-1-2.html|; 
$noresave{$key} = "$nosave";

$key = q/pragmas/;
$external_labels{$key} = "$URL/" . q|upc-specs-1-2.html|; 
$noresave{$key} = "$nosave";

$key = q/upc-op-t-item/;
$external_labels{$key} = "$URL/" . q|upc-specs-1-2.html|; 
$noresave{$key} = "$nosave";

$key = q/shared_array/;
$external_labels{$key} = "$URL/" . q|upc-specs-1-2.html|; 
$noresave{$key} = "$nosave";

$key = q/upc_phaseof/;
$external_labels{$key} = "$URL/" . q|upc-specs-1-2.html|; 
$noresave{$key} = "$nosave";

$key = q/pointer-arithmetic/;
$external_labels{$key} = "$URL/" . q|upc-specs-1-2.html|; 
$noresave{$key} = "$nosave";

$key = q/io-func-write/;
$external_labels{$key} = "$URL/" . q|upc-specs-1-2.html|; 
$noresave{$key} = "$nosave";

$key = q/upc_global_exit/;
$external_labels{$key} = "$URL/" . q|upc-specs-1-2.html|; 
$noresave{$key} = "$nosave";

$key = q/threads/;
$external_labels{$key} = "$URL/" . q|upc-specs-1-2.html|; 
$noresave{$key} = "$nosave";

$key = q/reduction/;
$external_labels{$key} = "$URL/" . q|upc-specs-1-2.html|; 
$noresave{$key} = "$nosave";

$key = q/io-func-open/;
$external_labels{$key} = "$URL/" . q|upc-specs-1-2.html|; 
$noresave{$key} = "$nosave";

$key = q/localDepend/;
$external_labels{$key} = "$URL/" . q|upc-specs-1-2.html|; 
$noresave{$key} = "$nosave";

$key = q/MemModelPrecedes/;
$external_labels{$key} = "$URL/" . q|upc-specs-1-2.html|; 
$noresave{$key} = "$nosave";

$key = q/type_qualifiers/;
$external_labels{$key} = "$URL/" . q|upc-specs-1-2.html|; 
$noresave{$key} = "$nosave";

$key = q/upc_lock/;
$external_labels{$key} = "$URL/" . q|upc-specs-1-2.html|; 
$noresave{$key} = "$nosave";

$key = q/mem-semantics/;
$external_labels{$key} = "$URL/" . q|upc-specs-1-2.html|; 
$noresave{$key} = "$nosave";

$key = q/indefinite_block_size/;
$external_labels{$key} = "$URL/" . q|upc-specs-1-2.html|; 
$noresave{$key} = "$nosave";

$key = q/MemoryAccessModel/;
$external_labels{$key} = "$URL/" . q|upc-specs-1-2.html|; 
$noresave{$key} = "$nosave";

$key = q/MemModelExamples/;
$external_labels{$key} = "$URL/" . q|upc-specs-1-2.html|; 
$noresave{$key} = "$nosave";

$key = q/upc-collective/;
$external_labels{$key} = "$URL/" . q|upc-specs-1-2.html|; 
$noresave{$key} = "$nosave";

$key = q/io-func-list/;
$external_labels{$key} = "$URL/" . q|upc-specs-1-2.html|; 
$noresave{$key} = "$nosave";

1;


# LaTeX2HTML 2008 (1.71)
# labels from external_latex_labels array.


$key = q/upc-flag-t/;
$external_latex_labels{$key} = q|7.2.6|; 
$noresave{$key} = "$nosave";

$key = q/upc_barrier/;
$external_latex_labels{$key} = q|6.6.1|; 
$noresave{$key} = "$nosave";

$key = q/upc_addrfield/;
$external_latex_labels{$key} = q|7.2.3.4|; 
$noresave{$key} = "$nosave";

$key = q/upc-io-common/;
$external_latex_labels{$key} = q|A.1.3|; 
$noresave{$key} = "$nosave";

$key = q/io-func-read/;
$external_latex_labels{$key} = q|A.1.4|; 
$noresave{$key} = "$nosave";

$key = q/strict_relaxed/;
$external_latex_labels{$key} = q|5.1.2.3|; 
$noresave{$key} = "$nosave";

$key = q/max_block_size/;
$external_latex_labels{$key} = q|6.3.3|; 
$noresave{$key} = "$nosave";

$key = q/declarator/;
$external_latex_labels{$key} = q|6.5.2|; 
$noresave{$key} = "$nosave";

$key = q/upc_threadof/;
$external_latex_labels{$key} = q|7.2.3.1|; 
$noresave{$key} = "$nosave";

$key = q/upc-op-t-section/;
$external_latex_labels{$key} = q|7.3.2|; 
$noresave{$key} = "$nosave";

$key = q/def-access/;
$external_latex_labels{$key} = q|3.5|; 
$noresave{$key} = "$nosave";

$key = q/pragmas/;
$external_latex_labels{$key} = q|6.7.1|; 
$noresave{$key} = "$nosave";

$key = q/upc-op-t-item/;
$external_latex_labels{$key} = q|7.3.2|; 
$noresave{$key} = "$nosave";

$key = q/shared_array/;
$external_latex_labels{$key} = q|6.5.2.1|; 
$noresave{$key} = "$nosave";

$key = q/upc_phaseof/;
$external_latex_labels{$key} = q|7.2.3.2|; 
$noresave{$key} = "$nosave";

$key = q/pointer-arithmetic/;
$external_latex_labels{$key} = q|6.4.2|; 
$noresave{$key} = "$nosave";

$key = q/io-func-write/;
$external_latex_labels{$key} = q|A.1.5|; 
$noresave{$key} = "$nosave";

$key = q/upc_global_exit/;
$external_latex_labels{$key} = q|7.2.1|; 
$noresave{$key} = "$nosave";

$key = q/threads/;
$external_latex_labels{$key} = q|6.3.1|; 
$noresave{$key} = "$nosave";

$key = q/reduction/;
$external_latex_labels{$key} = q|7.3.2.1|; 
$noresave{$key} = "$nosave";

$key = q/io-func-open/;
$external_latex_labels{$key} = q|A.1.3.1|; 
$noresave{$key} = "$nosave";

$key = q/localDepend/;
$external_latex_labels{$key} = q|1|; 
$noresave{$key} = "$nosave";

$key = q/MemModelPrecedes/;
$external_latex_labels{$key} = q|B.6|; 
$noresave{$key} = "$nosave";

$key = q/type_qualifiers/;
$external_latex_labels{$key} = q|6.5.1.1|; 
$noresave{$key} = "$nosave";

$key = q/upc_lock/;
$external_latex_labels{$key} = q|7.2.4|; 
$noresave{$key} = "$nosave";

$key = q/mem-semantics/;
$external_latex_labels{$key} = q|B|; 
$noresave{$key} = "$nosave";

$key = q/indefinite_block_size/;
$external_latex_labels{$key} = q|6.5.1.1|; 
$noresave{$key} = "$nosave";

$key = q/MemoryAccessModel/;
$external_latex_labels{$key} = q|B.2|; 
$noresave{$key} = "$nosave";

$key = q/MemModelExamples/;
$external_latex_labels{$key} = q|B.5|; 
$noresave{$key} = "$nosave";

$key = q/upc-collective/;
$external_latex_labels{$key} = q|7.3|; 
$noresave{$key} = "$nosave";

$key = q/io-func-list/;
$external_latex_labels{$key} = q|A.1.6|; 
$noresave{$key} = "$nosave";

1;

