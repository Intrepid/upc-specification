# LaTeX2HTML 2008 (1.71)
# Associate images original text with physical files.


$key = q/nomath_inline}xymatrix{RW(x,1)ar@{=>}[r]&SW(y,1)}nomath_inline};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="211" HEIGHT="34" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img140.png"
 ALT="\xymatrix{
RW(x,1) \ar@{=&gt;}[r] &amp; SW(y,1)
}">|; 

$key = q/RW(x,1)Rightarrowupc_notifyRightarrowupc_waitRightarrowRR(x,0);MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="404" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img148.png"
 ALT="$RW(x,1) \Rightarrow upc\_notify \Rightarrow upc\_wait \Rightarrow RR(x,0)$">|; 

$key = q/{displaymath}AllStrict(M){defatop=}StrictPairs(M)cupStrictOnThreads(M){displaymath};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="489" HEIGHT="46" BORDER="0"
 SRC="|."$dir".q|img44.png"
 ALT="\begin{displaymath}
AllStrict(M) {def \atop =} StrictPairs(M) \cup StrictOnThreads(M)
\end{displaymath}">|; 

$key = q/{displaymath}Conflicting(M){defatop=}left{(m_1,m_2)left|array{{lc}Location(m_1)=_2)land(m_1inW(M)lorm_2inW(M))array{right.right}{displaymath};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="577" HEIGHT="55" BORDER="0"
 SRC="|."$dir".q|img46.png"
 ALT="\begin{displaymath}
Conflicting(M) {def \atop =} \left\{ (m_1, m_2) \left\vert...
... \in W(M) \lor m_2 \in W(M) ) \end{array} \right. \right\}
\end{displaymath}">|; 

$key = q/nomath_inline}xymatrix{RW(x,1)&RW(y,1)ar[dl]SR(y,1)ar@{=>}[r]ar@slash^1pcslash[r]&SR(x,0)ar[ul]}nomath_inline};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="213" HEIGHT="168" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img138.png"
 ALT="\xymatrix{
RW(x,1) &amp; RW(y,1) \ar[dl] \\\\
SR(y,1) \ar@{=&gt;}[r] \ar@/^1pc/[r] &amp; SR(x,0) \ar[ul]
}">|; 

$key = q/SW(l_{synch},0);MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="111" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img61.png"
 ALT="$SW(l_{synch}, 0)$">|; 

$key = q/shown.;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="63" HEIGHT="20" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img146.png"
 ALT="$ shown.$">|; 

$key = q/;|;;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="21" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img5.png"
 ALT="$\;\vert\;$">|; 

$key = q/O;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="19" HEIGHT="17" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img14.png"
 ALT="$O$">|; 

$key = q/textstyleparbox{3.25in}{Alloftheedgesshownarerequired,butthisisnotavalid{<_{Strict}{,sinceitcontainsacycle.};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="378" HEIGHT="58" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img107.png"
 ALT="$\textstyle \parbox{3.25in}{All of the edges shown are required, but this \\\\
is not a valid $&lt;_{Strict}$, since it contains a cycle. }$">|; 

$key = q/upc_lock();MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="87" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img64.png"
 ALT="$upc\_lock()$">|; 

$key = q/RW(x,1)<_{Strict}RR(x,0);MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="215" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img149.png"
 ALT="$RW(x,1) &lt;_{Strict} RR(x,0)$">|; 

$key = q/j;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="14" HEIGHT="34" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img7.png"
 ALT="$j$">|; 

$key = q/local_y==2;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="109" HEIGHT="35" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img73.png"
 ALT="$local\_y == 2$">|; 

$key = q/DependOnThreads(M);MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="199" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img56.png"
 ALT="$DependOnThreads(M)$">|; 

$key = q/LW(M);MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="72" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img34.png"
 ALT="$LW(M)$">|; 

$key = q/upc_memcpy;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="108" HEIGHT="35" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img69.png"
 ALT="$upc\_memcpy$">|; 

$key = q/DependOnThreads(M_0);MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="205" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img135.png"
 ALT="$DependOnThreads(M_0)$">|; 

$key = q/{eqnarraystar}W(M){defatop=}SW(M)cupRW(M)cupLW(M){eqnarraystar};MSF=1.6;LFS=12;TAGS=R;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="370" HEIGHT="46" BORDER="0"
 SRC="|."$dir".q|img36.png"
 ALT="\begin{eqnarray*}
W(M) {def \atop =} SW(M) \cup RW(M) \cup LW(M)
\end{eqnarray*}">|; 

$key = q/<_{Strict};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="56" HEIGHT="35" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img52.png"
 ALT="$&lt;_{Strict}$">|; 

$key = q/textstyleparbox{2.5in}{<_0{conformsto{<_{Strict}{.Otherorderingsarepossible.};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="292" HEIGHT="58" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img128.png"
 ALT="$\textstyle \parbox{2.5in}{$&lt;_0$ conforms to $&lt;_{Strict}$. Other orderings are possible.}$">|; 

$key = q/textstyleparbox{3in}{Tosatisfywrite-to-readdataflowin{<_1{,RW(x,1)mustfollowRR(xrethreeothervalid{<_1{orderingswhichsatisfytheseconstraints.};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="350" HEIGHT="124" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img113.png"
 ALT="$\textstyle \parbox{3in}{To satisfy write-to-read data flow in $&lt;_1$,
RW(x,1) m...
...There are three other valid $&lt;_1$ orderings
which satisfy these constraints.}$">|; 

$key = q/RR(M);MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="68" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img31.png"
 ALT="$RR(M)$">|; 

$key = q/textstyleparbox{2.5in}{Relaxedreadsfromthread1donotappearin{<_0{};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="292" HEIGHT="58" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img142.png"
 ALT="$\textstyle \parbox{2.5in}{Relaxed reads from thread 1 do not appear in $&lt;_0$}$">|; 

$key = q/nomath_inline}xymatrix{RW(x,1)ar@{=>}[r]&*txt{{upc_notify{{(=SW*){}ar@{=>}[d]RW(]&*txt{{upc_notify{{(=SW*){}ar@{=>}[r]&RR(x,0)}nomath_inline};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="235" HEIGHT="89" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img155.png"
 ALT="\xymatrix{
RW(x,1) \ar@{=&gt;}[r] &amp; *\txt{$upc\_notify$\ $(=SW*)$} \ar@{=&gt;}[d] \\\\
RW(y,1) \ar@{=&gt;}[r] &amp; *\txt{$upc\_notify$\ $(=SW*)$} \ar@{=&gt;}[r] &amp; RR(x,0)
}">|; 

$key = q/local_x;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="61" HEIGHT="20" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img82.png"
 ALT="$local\_x$">|; 

$key = q/textstyleparbox{2.5in}{Thisistheonly{<_1{thatconformsto{<_{Strict}{and{DependOnThreads(M_1){.Thesecondreadofxcannotreturn1-itmustreturn3.};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="292" HEIGHT="124" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img130.png"
 ALT="$\textstyle \parbox{2.5in}{This is the only $&lt;_1$ that conforms to $&lt;_{Strict}$...
...ependOnThreads(M_1)$.
The second read of x cannot return 1 - it must return 3.}$">|; 

$key = q/textstyleparbox{3in}{T0{observesonlyitsownwrites.Thewritesarenon-conflicting,soeitherorderingconstitutesavalid{<_0{.};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="350" HEIGHT="83" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img111.png"
 ALT="$\textstyle \parbox{3in}{$T0$ observes only its own writes. \\\\
The writes are non-conflicting, so either ordering constitutes a valid $&lt;_0$.}$">|; 

$key = q/Rightarrow;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="24" HEIGHT="19" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img97.png"
 ALT="$\Rightarrow$">|; 

$key = q/textstyleparbox{2.5in}{<_1{conformsto{<_{Strict}{.T1'soperationsonxdonotconflictrrelativelyreorderedin{<_1{.Oneother{<_1{orderingispossible.};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="292" HEIGHT="129" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img125.png"
 ALT="$\textstyle \parbox{2.5in}{$&lt;_1$ conforms to $&lt;_{Strict}$.
T1's operations on x...
... appear relatively reordered in $&lt;_1$.
One other $&lt;_1$ ordering is possible.}$">|; 

$key = q/>;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="19" HEIGHT="35" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img2.png"
 ALT="$&gt;$">|; 

$key = q/StrictOnThreads(M_t);MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="189" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img49.png"
 ALT="$StrictOnThreads(M_t)$">|; 

$key = q/vinV;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="53" HEIGHT="35" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img20.png"
 ALT="$v \in V$">|; 

$key = q/PotentialRaces;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="134" HEIGHT="20" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img91.png"
 ALT="$PotentialRaces$">|; 

$key = q/upc_mem-{put,get,cpy};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="196" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img67.png"
 ALT="$upc\_mem\-\{put,get,cpy\}$">|; 

$key = q/RW(M);MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="74" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img32.png"
 ALT="$RW(M)$">|; 

$key = q/PotentialRaces(M);MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="168" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img86.png"
 ALT="$PotentialRaces(M)$">|; 

$key = q/Precedes();MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="95" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img92.png"
 ALT="$Precedes()$">|; 

$key = q/MLN=6;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="19" HEIGHT="17" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img161.png"
 ALT="$MLN=6$">|; 

$key = q/nomath_inline}xymatrix{RW(x,1)ar@{=>}[r]&*txt{{upc_notify{{(=SW*){}ar@{=>}[r]ar@upc_wait{{(=SR*){}ar@{=>}[r]ar@{=>}[u]&RR(x,0)}nomath_inline};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="445" HEIGHT="204" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img145.png"
 ALT="\xymatrix{
RW(x,1) \ar@{=&gt;}[r] &amp; *\txt{$upc\_notify$\ $(=SW*)$} \ar@{=&gt;}[r] \ar...
...\ar@{=&gt;}[ur] &amp; *\txt{$upc\_wait$\ $(=SR*)$} \ar@{=&gt;}[r] \ar@{=&gt;}[u] &amp; RR(x,0)
}">|; 

$key = q/RW(x,1)Rightarrowupc_notifyRightarrowupc_notifyRightarrowRR(x,0);MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="29" HEIGHT="35" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img157.png"
 ALT="$RW(x,1) \Rightarrow upc\_notify \Rightarrow upc\_notify \Rightarrow RR(x,0)$">|; 

$key = q/nomath_inline}xymatrix{RW(x,1)ar@{=>}[r]ar@slash^1pcslash[r]&SW(y,1)ar[dl]RR(y,1)ar[r]&RR(x,1)&RR(x,0)ar[ull]}nomath_inline};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="330" HEIGHT="168" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img143.png"
 ALT="\xymatrix{
RW(x,1) \ar@{=&gt;}[r] \ar@/^1pc/[r] &amp; SW(y,1) \ar[dl] \\\\
RR(y,1) \ar[r] &amp; RR(x,1) &amp; RR(x,0) \ar[ull]
}">|; 

$key = q/0leq;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="34" HEIGHT="35" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img11.png"
 ALT="$0 \leq$">|; 

$key = q/nomath_inline}xymatrix{RW(x,1)ar[r]&RW(x,2)ar[dl]SR(x,2)ar@{=>}[r]ar@slash^1pcslash[r]&SR(x,?)}nomath_inline};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="214" HEIGHT="168" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img133.png"
 ALT="\xymatrix{
RW(x,1) \ar[r] &amp; RW(x,2) \ar[dl] \\\\
SR(x,2) \ar@{=&gt;}[r] \ar@/^1pc/[r] &amp; SR(x,?)
}">|; 

$key = q/linL;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="47" HEIGHT="35" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img19.png"
 ALT="$l \in
L$">|; 

$key = q/textstyleparbox{2.5in}{Thisistheonly{<_0{thatconformsto{<_{Strict}{and{DependOnThreads(M_0){.Thesecondreadofxcannotreturn1-itmustreturn2.};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="292" HEIGHT="124" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img134.png"
 ALT="$\textstyle \parbox{2.5in}{This is the only $&lt;_0$ that conforms to $&lt;_{Strict}$...
...ependOnThreads(M_0)$.
The second read of x cannot return 1 - it must return 2.}$">|; 

$key = q/l;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="11" HEIGHT="20" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img25.png"
 ALT="$l$">|; 

$key = q/textstyleparbox{3in}{T0{observes{T1{'swritehappeningbeforeitsownread.};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="350" HEIGHT="56" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img102.png"
 ALT="$\textstyle \parbox{3in}{$T0$ observes $T1$'s write happening before its own read.}$">|; 

$key = q/*;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="14" HEIGHT="19" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img8.png"
 ALT="$*$">|; 

$key = q/opluscdotsoplus;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="63" HEIGHT="35" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img10.png"
 ALT="$\oplus \cdots \oplus$">|; 

$key = q/DependOnThreads(M_t);MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="203" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img45.png"
 ALT="$DependOnThreads(M_t)$">|; 

$key = q/upc_wait;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="76" HEIGHT="34" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img62.png"
 ALT="$upc\_wait$">|; 

$key = q/Conflicting(M_t);MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="143" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img48.png"
 ALT="$Conflicting(M_t)$">|; 

$key = q/upc_notify;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="94" HEIGHT="35" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img60.png"
 ALT="$upc\_notify$">|; 

$key = q/i;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="11" HEIGHT="17" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img6.png"
 ALT="$i$">|; 

$key = q/Thread(m);MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="97" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img23.png"
 ALT="$Thread(m)$">|; 

$key = q/local_y;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="60" HEIGHT="35" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img81.png"
 ALT="$local\_y$">|; 

$key = q/<;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="19" HEIGHT="35" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img1.png"
 ALT="$&lt;$">|; 

$key = q/nomath_inline}xymatrix{RW(x,1)ar@{=>}[r]ar@slash^1pcslash[r]&SW(y,1)}nomath_inline};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="213" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img141.png"
 ALT="\xymatrix{
RW(x,1) \ar@{=&gt;}[r] \ar@/^1pc/[r] &amp; SW(y,1)
}">|; 

$key = q/O_t;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="25" HEIGHT="35" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img16.png"
 ALT="$O_t$">|; 

$key = q/nomath_inline}xymatrix{RW(x,1)ar@{=>}[r]ar@slash^1pcslash[r]&SW(y,1)ar@{=>}[r]arW(x,2)ar[dll]RR(x,2)ar[r]&RW(x,3)ar[r]&RR(x,?)}nomath_inline};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="339" HEIGHT="168" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img129.png"
 ALT="\xymatrix{
RW(x,1) \ar@{=&gt;}[r] \ar@/^1pc/[r] &amp; SW(y,1) \ar@{=&gt;}[r] \ar@/^1pc/[r] &amp; RW(x,2) \ar[dll] \\\\
RR(x,2) \ar[r] &amp; RW(x,3) \ar[r] &amp; RR(x,?)
}">|; 

$key = q/textstyleparbox{3in}{Analogoussituationwithawrite-after-read,thistimeonx.Severalothervalid{<_1{orderingsarepossible.};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="350" HEIGHT="83" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img117.png"
 ALT="$\textstyle \parbox{3in}{Analogous situation with a write-after-read, this time on x.
Several other valid $&lt;_1$ orderings are possible.}$">|; 

$key = q/m_1<_{Strict}m_2;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="114" HEIGHT="35" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img93.png"
 ALT="$m_1 &lt;_{Strict} m_2$">|; 

$key = q/SW(l_{synch},0);SR(l_{synch},0);MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="233" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img59.png"
 ALT="$SW(l_{synch}, 0) ; SR(l_{synch}, 0)$">|; 

$key = q/m_2;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="54" HEIGHT="16" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img159.png"
 ALT="$m_2$">|; 

$key = q/t;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="11" HEIGHT="19" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img15.png"
 ALT="$t$">|; 

$key = q/Precedes;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="81" HEIGHT="20" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img51.png"
 ALT="$Precedes$">|; 

$key = q/{displaymath}array{{l}DependOnThreads(M){defatop=}left{langlem_1,m_2rangleleft|aOnThreads(M)array{right)array{right.right}array{{displaymath};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="679" HEIGHT="124" BORDER="0"
 SRC="|."$dir".q|img47.png"
 ALT="\begin{displaymath}
\begin{array}{l}
DependOnThreads(M) {def \atop =}
\left\{ \...
...) \end{array}\right) \end{array} \right. \right\}
\end{array}\end{displaymath}">|; 

$key = q/Strict(M);MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="89" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img37.png"
 ALT="$Strict(M)$">|; 

$key = q/C;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="22" HEIGHT="16" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img162.png"
 ALT="$C$">|; 

$key = q/z;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="14" HEIGHT="19" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img79.png"
 ALT="$z$">|; 

$key = q/z[0];MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="34" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img83.png"
 ALT="$z[0]$">|; 

$key = q/m;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="21" HEIGHT="19" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img21.png"
 ALT="$m$">|; 

$key = q/_{opt};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="24" HEIGHT="35" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img4.png"
 ALT="$_{opt}$">|; 

$key = q/m_1<_tm_2;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="83" HEIGHT="35" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img95.png"
 ALT="$m_1 &lt;_t m_2$">|; 

$key = q/SW(M);MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="72" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img30.png"
 ALT="$SW(M)$">|; 

$key = q/<_{Strict}.;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="350" HEIGHT="84" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img152.png"
 ALT="$ $&lt;_{Strict}$.$">|; 

$key = q/L;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="17" HEIGHT="16" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img17.png"
 ALT="$L$">|; 

$key = q/upc_unlock;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="95" HEIGHT="35" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img66.png"
 ALT="$upc\_unlock$">|; 

$key = q/<_t;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="25" HEIGHT="35" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img53.png"
 ALT="$&lt;_t$">|; 

$key = q/nomath_inline}xymatrix{RW(x,1)ar[r]&RW(y,1)}nomath_inline};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="213" HEIGHT="34" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img110.png"
 ALT="\xymatrix{
RW(x,1) \ar[r] &amp; RW(y,1) \\\\
}">|; 

$key = q/{displaymath}StrictOnThreads(M){defatop=}left{(m_1,m_2)left|array{{l}m_1neqm_2la1inStrict(M)lorm_2inStrict(M))array{right.right}{displaymath};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="681" HEIGHT="76" BORDER="0"
 SRC="|."$dir".q|img43.png"
 ALT="\begin{displaymath}
StrictOnThreads(M) {def \atop =} \left\{ (m_1, m_2) \left\...
...t(M) \lor m_2 \in Strict(M) ) \end{array} \right. \right\}
\end{displaymath}">|; 

$key = q/T;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="18" HEIGHT="16" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img13.png"
 ALT="$T$">|; 

$key = q/bullet;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="14" HEIGHT="19" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img22.png"
 ALT="$\bullet$">|; 

$key = q/nomath_inline}xymatrix{RW(x,1)ar@{=>}[r]&*txt{{upc_notify{{(=SW*){}ar@{=>}[r]ar@]&*txt{{upc_notify{{(=SW*){}ar@{=>}[r]&RR(x,0)}nomath_inline};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="335" HEIGHT="204" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img151.png"
 ALT="\xymatrix{
RW(x,1) \ar@{=&gt;}[r] &amp; *\txt{$upc\_notify$\ $(=SW*)$} \ar@{=&gt;}[r] \ar...
...
RW(y,1) \ar@{=&gt;}[r] &amp; *\txt{$upc\_notify$\ $(=SW*)$} \ar@{=&gt;}[r] &amp; RR(x,0)
}">|; 

$key = q/nomath_inline}xymatrix{&RW(x,2)ar[dl]RR(x,2)ar[r]&RW(x,1)}nomath_inline};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="208" HEIGHT="168" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img104.png"
 ALT="\xymatrix{
&amp; RW(x,2) \ar[dl] \\\\
RR(x,2) \ar[r] &amp; RW(x,1)
}">|; 

$key = q/T1;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="28" HEIGHT="16" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img99.png"
 ALT="$T1$">|; 

$key = q/nomath_inline}xymatrix{RW(x,1)RW(y,1)ar[r]&RR(x,0)ar[ul]}nomath_inline};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="208" HEIGHT="168" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img116.png"
 ALT="\xymatrix{
RW(x,1) \\\\
RW(y,1) \ar[r] &amp; RR(x,0) \ar[ul]
}">|; 

$key = q/upc_fence;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="87" HEIGHT="35" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img58.png"
 ALT="$upc\_fence$">|; 

$key = q/V;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="20" HEIGHT="17" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img18.png"
 ALT="$V$">|; 

$key = q/upc_mem{put,get,cpy};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="196" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img70.png"
 ALT="$upc\_mem\{put,get,cpy\}$">|; 

$key = q/nomath_inline}xymatrix{RW(x,1)ar@{=>}[r]ar[dr]&SW(y,1)ar@{=>}[r]ar@slash^1pcslash[r]&RW(x,2)ar[dll]RR(x,2)&RR(x,1)ar[u]}nomath_inline};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="336" HEIGHT="168" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img124.png"
 ALT="\xymatrix{
RW(x,1) \ar@{=&gt;}[r] \ar[dr] &amp; SW(y,1) \ar@{=&gt;}[r] \ar@/^1pc/[r] &amp; RW(x,2) \ar[dll] \\\\
RR(x,2) &amp; RR(x,1) \ar[u]
}">|; 

$key = q/Location(m);MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="108" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img24.png"
 ALT="$Location(m)$">|; 

$key = q/x,y,z[0];MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="71" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img71.png"
 ALT="$x, y, z[0]$">|; 

$key = q/nomath_inline}xymatrix{RW(x,1)&RW(y,1)ar[dl]RR(y,1)ar[r]&RR(x,0)ar[ul]}nomath_inline};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="213" HEIGHT="168" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img112.png"
 ALT="\xymatrix{
RW(x,1) &amp; RW(y,1) \ar[dl] \\\\
RR(y,1) \ar[r] &amp; RR(x,0) \ar[ul]
}">|; 

$key = q/textstyleparbox{2.5in}{DependOnThreads(M_1){impliesthisistheonlyvalid{<_{Strict}{orderingover{StrictOnThreads(M){};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="292" HEIGHT="85" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img132.png"
 ALT="$\textstyle \parbox{2.5in}{$DependOnThreads(M_1)$ implies this is the only valid $&lt;_{Strict}$ ordering
over $StrictOnThreads(M)$}$">|; 

$key = q/upc_memput;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="108" HEIGHT="35" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img80.png"
 ALT="$upc\_memput$">|; 

$key = q/{displaymath}forall(m_1,m_2)inPotentialRaces(M):(m_1<_{Strict}m_2)lor(m_2<_{Strict}m_1){displaymath};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="568" HEIGHT="33" BORDER="0"
 SRC="|."$dir".q|img90.png"
 ALT="\begin{displaymath}
\forall (m_1, m_2) \in PotentialRaces(M) : ( m_1 &lt;_{Strict} m_2 ) \lor ( m_2 &lt;_{Strict} m_1 )
\end{displaymath}">|; 

$key = q/local_z1==-4;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="133" HEIGHT="35" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img74.png"
 ALT="$local\_z1 == -4$">|; 

$key = q/nomath_inline}xymatrix{RW(x,1)ar@{=>}[r]ar@slash^1pcslash[r]&*txt{{upc_notify{{(r@slash^1pcslash[r]&*txt{{upc_notify{{(=SW*){}}nomath_inline};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="335" HEIGHT="204" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img154.png"
 ALT="\xymatrix{
RW(x,1) \ar@{=&gt;}[r] \ar@/^1pc/[r] &amp; *\txt{$upc\_notify$\ $(=SW*)$} \...
...[dll] \\\\
RW(y,1) \ar@{=&gt;}[r] \ar@/^1pc/[r] &amp; *\txt{$upc\_notify$\ $(=SW*)$}
}">|; 

$key = q/nomath_inline}xymatrix{SR(x,1)ar@{=>}[r]&SW(x,2)ar@{=>}[dl]SR(x,2)ar@{=>}[r]&SW(x,1)ar@{=>}[ul]}nomath_inline};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="204" HEIGHT="168" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img106.png"
 ALT="\xymatrix{
SR(x,1) \ar@{=&gt;}[r] &amp; SW(x,2) \ar@{=&gt;}[dl] \\\\
SR(x,2) \ar@{=&gt;}[r] &amp; SW(x,1) \ar@{=&gt;}[ul]
}">|; 

$key = q/M;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="25" HEIGHT="16" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img28.png"
 ALT="$M$">|; 

$key = q/M_t;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="28" HEIGHT="35" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img27.png"
 ALT="$M_t$">|; 

$key = q/nomath_inline}xymatrix{RR(x,1)ar[r]&RW(x,2)&RW(x,1)ar[ul]}nomath_inline};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="208" HEIGHT="168" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img101.png"
 ALT="\xymatrix{
RR(x,1) \ar[r] &amp; RW(x,2) \\\\
&amp; RW(x,1) \ar[ul]
}">|; 

$key = q/nomath_inline}xymatrix{RW(x,1)ar@{=>}[r]&SW(y,1)ar@{=>}[r]&RW(x,2)}nomath_inline};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="336" HEIGHT="34" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img119.png"
 ALT="\xymatrix{
RW(x,1) \ar@{=&gt;}[r] &amp; SW(y,1) \ar@{=&gt;}[r] &amp; RW(x,2)
}">|; 

$key = q/local_z0==0;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="118" HEIGHT="20" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img75.png"
 ALT="$local\_z0 == 0$">|; 

$key = q/upc_all_broadcast;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="147" HEIGHT="35" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img68.png"
 ALT="$upc\_all\_broadcast$">|; 

$key = q/textstyleparbox{2in}{vspace{0.5in}Readcannotreturn0.};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="421" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img156.png"
 ALT="$\textstyle \parbox{2in}{ \vspace{0.5in} Read cannot return 0. }$">|; 

$key = q/{displaymath}PotentialRaces(M){defatop=}left{(m_1,m_2)left|array{{l}Location(m_1_2)land(m_1inW(M)lorm_2inW(M))array{right.right}{displaymath};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="595" HEIGHT="76" BORDER="0"
 SRC="|."$dir".q|img88.png"
 ALT="\begin{displaymath}
PotentialRaces(M) {def \atop =} \left\{(m_1, m_2)\left\vert\...
... m_1 \in W(M) \lor m_2 \in W(M) )\end{array}\right.\right\}
\end{displaymath}">|; 

$key = q/<_1;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="27" HEIGHT="35" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img123.png"
 ALT="$&lt;_1$">|; 

$key = q/StrictOnThreads(M);MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="185" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img40.png"
 ALT="$StrictOnThreads(M)$">|; 

$key = q/<_0,<_1;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="57" HEIGHT="35" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img137.png"
 ALT="$&lt;_0,&lt;_1$">|; 

$key = q/z[1];MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="34" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img72.png"
 ALT="$z[1]$">|; 

$key = q/m_1rightarrowm_2;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="82" HEIGHT="35" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img96.png"
 ALT="$m_1 \rightarrow m_2$">|; 

$key = q/m_1;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="29" HEIGHT="35" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img158.png"
 ALT="$m_1$">|; 

$key = q/MsubseteqO;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="65" HEIGHT="35" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img26.png"
 ALT="$M \subseteq O$">|; 

$key = q/SR(l_{synch},0);MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="106" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img63.png"
 ALT="$SR(l_{synch}, 0)$">|; 

$key = q/<_1:;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="32" HEIGHT="35" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img103.png"
 ALT="$&lt;_1:$">|; 

$key = q/SR(M)cupSW(M);MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="167" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img150.png"
 ALT="$SR(M) \cup SW(M)$">|; 

$key = q/LR(M);MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="66" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img33.png"
 ALT="$LR(M)$">|; 

$key = q/l_{synch}inL;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="82" HEIGHT="35" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img57.png"
 ALT="$l_{synch} \in L$">|; 

$key = q/local_z1;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="69" HEIGHT="20" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img78.png"
 ALT="$local\_z1$">|; 

$key = q/textstyleparbox{2.5in}{Thewritesarenon-conflicting,thereforenotorderedby{DependOnThreads(M_0){.};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="292" HEIGHT="84" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img139.png"
 ALT="$\textstyle \parbox{2.5in}{The writes are non-conflicting, therefore not ordered by $DependOnThreads(M_0)$.}$">|; 

$key = q/oplus;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="20" HEIGHT="35" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img9.png"
 ALT="$\oplus$">|; 

$key = q/local_x==0;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="110" HEIGHT="20" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img76.png"
 ALT="$local\_x == 0$">|; 

$key = q/<_0;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="27" HEIGHT="35" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img100.png"
 ALT="$&lt;_0$">|; 

$key = q/nomath_inline}xymatrix{SR(x,2)ar@{=>}[r]&SR(x,1)}nomath_inline};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="198" HEIGHT="149" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img131.png"
 ALT="\xymatrix{
\\\\
SR(x,2) \ar@{=&gt;}[r] &amp; SR(x,1)
}">|; 

$key = q/nomath_inline}xymatrix{RW(x,1)ar@{=>}[r]ar@slash^1pcslash[r]&SW(y,1)ar@{=>}[r]ar@slash^1pcslash[r]&RW(x,2)ar[dl]&RW(x,3)}nomath_inline};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="339" HEIGHT="168" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img127.png"
 ALT="\xymatrix{
RW(x,1) \ar@{=&gt;}[r] \ar@/^1pc/[r] &amp; SW(y,1) \ar@{=&gt;}[r] \ar@/^1pc/[r] &amp; RW(x,2) \ar[dl] \\\\
&amp; RW(x,3)
}">|; 

$key = q/(m_1,m_2);MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="75" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img87.png"
 ALT="$(m_1, m_2)$">|; 

$key = q/textstyleparbox{2.5in}{DependOnThreads(M_0){impliesthisistheonlyvalid{<_{Strict}{orderingover{StrictOnThreads(M){};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="292" HEIGHT="85" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img120.png"
 ALT="$\textstyle \parbox{2.5in}{$DependOnThreads(M_0)$ implies this is the only valid $&lt;_{Strict}$ ordering
over $StrictOnThreads(M)$}$">|; 

$key = q/textstyleparbox{2.3in}{DependOnThreads(M)andthesynchronizationsemanticsofbarrierimplythat<_{Strict}mustrespectalltheedgesshown.footnotemark};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="269" HEIGHT="107" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img147.png"
 ALT="$\textstyle \parbox{2.3in}{$DependOnThreads(M)$ and the synchronization semanti...
...rrier imply
that $&lt;_{Strict}$ must respect all the edges shown.\footnotemark }$">|; 

$key = q/y;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="14" HEIGHT="35" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img108.png"
 ALT="$y$">|; 

$key = q/(m_1,m_2)inPotentialRaces(M);MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="262" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img89.png"
 ALT="$(m_1, m_2) \in PotentialRaces(M)$">|; 

$key = q/StrictPairs(M);MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="137" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img39.png"
 ALT="$StrictPairs(M)$">|; 

$key = q/upc_flag_t;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="90" HEIGHT="35" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img84.png"
 ALT="$upc\_flag\_t$">|; 

$key = q/nomath_inline}xymatrix{RW(x,1)ar@{=>}[r]ar@slash^1pcslash[r]&SW(y,1)ar@{=>}[r]ar@slash^1pcslash[r]&RW(x,2)}nomath_inline};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="338" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img121.png"
 ALT="\xymatrix{
RW(x,1) \ar@{=&gt;}[r] \ar@/^1pc/[r] &amp; SW(y,1) \ar@{=&gt;}[r] \ar@/^1pc/[r] &amp; RW(x,2)
}">|; 

$key = q/MLN;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="89" HEIGHT="17" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img160.png"
 ALT="$MLN$">|; 

$key = q/local_z0;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="69" HEIGHT="20" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img77.png"
 ALT="$local\_z0$">|; 

$key = q/textstyleparbox{3in}{DependOnThreads(M_0)impliestheseedgesinStrictOnThreads(M)mustberespectedby<_{Strict}.footnotemark};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="334" HEIGHT="203" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img153.png"
 ALT="$\textstyle \parbox{3in}{$DependOnThreads(M_0)$ implies these edges in $StrictOnThreads(M)$ must be
respected by $&lt;_{Strict}$.\footnotemark }$">|; 

$key = q/{eqnarraystar}Strict(M){defatop=}SR(M)cupSW(M){eqnarraystar};MSF=1.6;LFS=12;TAGS=R;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="290" HEIGHT="46" BORDER="0"
 SRC="|."$dir".q|img38.png"
 ALT="\begin{eqnarray*}
Strict(M) {def \atop =} SR(M) \cup SW(M)
\end{eqnarray*}">|; 

$key = q/x;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="15" HEIGHT="19" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img109.png"
 ALT="$x$">|; 

$key = q/{displaymath}StrictPairs(M){defatop=}left{(m_1,m_2)left|array{{l}m_1neqm_2landm_1inStrict(M)landm_2inStrict(M)array{right.right}{displaymath};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="565" HEIGHT="55" BORDER="0"
 SRC="|."$dir".q|img42.png"
 ALT="\begin{displaymath}
StrictPairs(M) {def \atop =} \left\{ (m_1, m_2) \left\vert...
...) \land \\\\
m_2 \in Strict(M) \end{array} \right. \right\}
\end{displaymath}">|; 

$key = q/<_{t};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="25" HEIGHT="35" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img55.png"
 ALT="$&lt;_{t}$">|; 

$key = q/textstyleparbox{3in}{T1{mustobserveitsownprogramorderforconflictingoperations,butitsees{T0{'swriteasthefirstoperation.};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="350" HEIGHT="83" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img105.png"
 ALT="$\textstyle \parbox{3in}{$T1$ must observe its own program order for conflicting operations,
but it sees $T0$'s write as the first operation.}$">|; 

$key = q/Precedes(m_1,m_2);MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="152" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img50.png"
 ALT="$Precedes(m_1, m_2)$">|; 

$key = q/nomath_inline}xymatrix{RW(x,1)ar[r]&RR(y,0)ar[dl]RW(y,1)}nomath_inline};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="207" HEIGHT="168" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img114.png"
 ALT="\xymatrix{
RW(x,1) \ar[r] &amp; RR(y,0) \ar[dl] \\\\
RW(y,1)
}">|; 

$key = q/textstyleparbox{2.5in}{<_0{conformsto{<_{Strict}{};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="292" HEIGHT="36" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img122.png"
 ALT="$\textstyle \parbox{2.5in}{$&lt;_0$ conforms to $&lt;_{Strict}$}$">|; 

$key = q/textstyleparbox{3in}{Theonlyconstrainton{<_0{isRW(y,1)mustfollowRR(y,0).Severalothervalid{<_0{orderingsarepossible.};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="350" HEIGHT="84" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img115.png"
 ALT="$\textstyle \parbox{3in}{The only constraint on $&lt;_0$ is RW(y,1) must follow RR(y,0).
Several other valid $&lt;_0$ orderings are possible.}$">|; 

$key = q/O_tcupW(M)cupSR(M);MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="209" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img54.png"
 ALT="$O_t \cup W(M) \cup SR(M)$">|; 

$key = q/upc_lock-_attempt();MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="159" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img65.png"
 ALT="$upc\_lock\-\_attempt()$">|; 

$key = q/DependOnThreads(M_1);MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="205" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img126.png"
 ALT="$DependOnThreads(M_1)$">|; 

$key = q/SR(M);MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="66" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img29.png"
 ALT="$SR(M)$">|; 

$key = q/m_1Rightarrowm_2;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="82" HEIGHT="35" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img94.png"
 ALT="$m_1 \Rightarrow m_2$">|; 

$key = q/leq;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="20" HEIGHT="35" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img12.png"
 ALT="$\leq$">|; 

$key = q/expression_{opt};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="114" HEIGHT="34" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img3.png"
 ALT="$expression_{opt}$">|; 

$key = q/nomath_inline}xymatrix{SW(x,2)ar@{<=>}[d]ar@{=>}[r]&SR(x,1)SW(x,1)ar@{=>}[r]&SR(x,2)}nomath_inline};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="204" HEIGHT="168" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img118.png"
 ALT="\xymatrix{
SW(x,2) \ar@{&lt;=&gt;}[d] \ar@{=&gt;}[r] &amp; SR(x,1) \\\\
SW(x,1) \ar@{=&gt;}[r] &amp; SR(x,2)
}">|; 

$key = q/T0;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="28" HEIGHT="17" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img98.png"
 ALT="$T0$">|; 

$key = q/textstyleparbox{2in}{Relaxedreadshavebeenreordered.Other{<_1{ordersarepossible.};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="235" HEIGHT="83" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img144.png"
 ALT="$\textstyle \parbox{2in}{Relaxed reads have been reordered. Other $&lt;_1$ orders are possible.}$">|; 

$key = q/nomath_inline}xymatrix{SR(y,1)ar@{=>}[r]&SR(x,0)}nomath_inline};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="197" HEIGHT="149" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img136.png"
 ALT="\xymatrix{
\\\\
SR(y,1) \ar@{=&gt;}[r] &amp; SR(x,0)
}">|; 

$key = q/upc_barrier;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="99" HEIGHT="35" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img85.png"
 ALT="$upc\_barrier$">|; 

$key = q/W(M);MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="60" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img35.png"
 ALT="$W(M)$">|; 

$key = q/AllStrict(M);MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="115" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img41.png"
 ALT="$AllStrict(M)$">|; 

1;

