# LaTeX2HTML 2008 (1.71)
# Associate internals original text with physical files.


$key = q/upc-flag-t/;
$ref_files{$key} = "$dir".q|upc-specs-1-2.html|; 
$noresave{$key} = "$nosave";

$key = q/upc_barrier/;
$ref_files{$key} = "$dir".q|upc-specs-1-2.html|; 
$noresave{$key} = "$nosave";

$key = q/upc_addrfield/;
$ref_files{$key} = "$dir".q|upc-specs-1-2.html|; 
$noresave{$key} = "$nosave";

$key = q/upc-io-common/;
$ref_files{$key} = "$dir".q|upc-specs-1-2.html|; 
$noresave{$key} = "$nosave";

$key = q/io-func-read/;
$ref_files{$key} = "$dir".q|upc-specs-1-2.html|; 
$noresave{$key} = "$nosave";

$key = q/strict_relaxed/;
$ref_files{$key} = "$dir".q|upc-specs-1-2.html|; 
$noresave{$key} = "$nosave";

$key = q/max_block_size/;
$ref_files{$key} = "$dir".q|upc-specs-1-2.html|; 
$noresave{$key} = "$nosave";

$key = q/declarator/;
$ref_files{$key} = "$dir".q|upc-specs-1-2.html|; 
$noresave{$key} = "$nosave";

$key = q/upc_threadof/;
$ref_files{$key} = "$dir".q|upc-specs-1-2.html|; 
$noresave{$key} = "$nosave";

$key = q/upc-op-t-section/;
$ref_files{$key} = "$dir".q|upc-specs-1-2.html|; 
$noresave{$key} = "$nosave";

$key = q/def-access/;
$ref_files{$key} = "$dir".q|upc-specs-1-2.html|; 
$noresave{$key} = "$nosave";

$key = q/pragmas/;
$ref_files{$key} = "$dir".q|upc-specs-1-2.html|; 
$noresave{$key} = "$nosave";

$key = q/upc-op-t-item/;
$ref_files{$key} = "$dir".q|upc-specs-1-2.html|; 
$noresave{$key} = "$nosave";

$key = q/shared_array/;
$ref_files{$key} = "$dir".q|upc-specs-1-2.html|; 
$noresave{$key} = "$nosave";

$key = q/upc_phaseof/;
$ref_files{$key} = "$dir".q|upc-specs-1-2.html|; 
$noresave{$key} = "$nosave";

$key = q/pointer-arithmetic/;
$ref_files{$key} = "$dir".q|upc-specs-1-2.html|; 
$noresave{$key} = "$nosave";

$key = q/io-func-write/;
$ref_files{$key} = "$dir".q|upc-specs-1-2.html|; 
$noresave{$key} = "$nosave";

$key = q/upc_global_exit/;
$ref_files{$key} = "$dir".q|upc-specs-1-2.html|; 
$noresave{$key} = "$nosave";

$key = q/threads/;
$ref_files{$key} = "$dir".q|upc-specs-1-2.html|; 
$noresave{$key} = "$nosave";

$key = q/reduction/;
$ref_files{$key} = "$dir".q|upc-specs-1-2.html|; 
$noresave{$key} = "$nosave";

$key = q/io-func-open/;
$ref_files{$key} = "$dir".q|upc-specs-1-2.html|; 
$noresave{$key} = "$nosave";

$key = q/localDepend/;
$ref_files{$key} = "$dir".q|upc-specs-1-2.html|; 
$noresave{$key} = "$nosave";

$key = q/MemModelPrecedes/;
$ref_files{$key} = "$dir".q|upc-specs-1-2.html|; 
$noresave{$key} = "$nosave";

$key = q/type_qualifiers/;
$ref_files{$key} = "$dir".q|upc-specs-1-2.html|; 
$noresave{$key} = "$nosave";

$key = q/upc_lock/;
$ref_files{$key} = "$dir".q|upc-specs-1-2.html|; 
$noresave{$key} = "$nosave";

$key = q/mem-semantics/;
$ref_files{$key} = "$dir".q|upc-specs-1-2.html|; 
$noresave{$key} = "$nosave";

$key = q/indefinite_block_size/;
$ref_files{$key} = "$dir".q|upc-specs-1-2.html|; 
$noresave{$key} = "$nosave";

$key = q/MemoryAccessModel/;
$ref_files{$key} = "$dir".q|upc-specs-1-2.html|; 
$noresave{$key} = "$nosave";

$key = q/MemModelExamples/;
$ref_files{$key} = "$dir".q|upc-specs-1-2.html|; 
$noresave{$key} = "$nosave";

$key = q/upc-collective/;
$ref_files{$key} = "$dir".q|upc-specs-1-2.html|; 
$noresave{$key} = "$nosave";

$key = q/io-func-list/;
$ref_files{$key} = "$dir".q|upc-specs-1-2.html|; 
$noresave{$key} = "$nosave";

1;

