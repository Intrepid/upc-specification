Makefile

	Makefile to build the UPC optional library specification.

upc-lib-io.tex

	UPC I/O specification.  UPC I/O is a component of
	the UPC optional library.

upc-lib-optional-spec.tar.gz

	Tar file with both LaTeX and produced PDF files.

upc-lib-optional-spec.tex

	The UPC optional library specification driver file.
