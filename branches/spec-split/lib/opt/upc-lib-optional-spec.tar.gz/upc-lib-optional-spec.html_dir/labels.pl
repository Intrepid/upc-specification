# LaTeX2HTML 2008 (1.71)
# Associate labels original text with physical files.


$key = q/upc-io-common/;
$external_labels{$key} = "$URL/" . q|upc-lib-optional-spec.html|; 
$noresave{$key} = "$nosave";

$key = q/io-func-read/;
$external_labels{$key} = "$URL/" . q|upc-lib-optional-spec.html|; 
$noresave{$key} = "$nosave";

$key = q/io-func-write/;
$external_labels{$key} = "$URL/" . q|upc-lib-optional-spec.html|; 
$noresave{$key} = "$nosave";

$key = q/io-func-open/;
$external_labels{$key} = "$URL/" . q|upc-lib-optional-spec.html|; 
$noresave{$key} = "$nosave";

$key = q/io-func-list/;
$external_labels{$key} = "$URL/" . q|upc-lib-optional-spec.html|; 
$noresave{$key} = "$nosave";

1;


# LaTeX2HTML 2008 (1.71)
# labels from external_latex_labels array.


$key = q/upc-flag-t/;
$external_latex_labels{$key} = q|6.1.8|; 
$noresave{$key} = "$nosave";

$key = q/upc-io-common/;
$external_latex_labels{$key} = q|6.1.3|; 
$noresave{$key} = "$nosave";

$key = q/io-func-read/;
$external_latex_labels{$key} = q|6.1.4|; 
$noresave{$key} = "$nosave";

$key = q/strict_relaxed/;
$external_latex_labels{$key} = q|5.1.2.3|; 
$noresave{$key} = "$nosave";

$key = q/io-func-write/;
$external_latex_labels{$key} = q|6.1.5|; 
$noresave{$key} = "$nosave";

$key = q/io-func-open/;
$external_latex_labels{$key} = q|6.1.3.1|; 
$noresave{$key} = "$nosave";

$key = q/def-access/;
$external_latex_labels{$key} = q|3.5|; 
$noresave{$key} = "$nosave";

$key = q/io-func-list/;
$external_latex_labels{$key} = q|6.1.6|; 
$noresave{$key} = "$nosave";

1;

