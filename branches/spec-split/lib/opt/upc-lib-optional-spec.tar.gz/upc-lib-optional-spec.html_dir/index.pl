# LaTeX2HTML 2008 (1.71)
# Associate index original text with physical files.


$key = q/upc_all_fwrite_local###4172/;
$index{$key} .= q|<A NAME="tex2html82" HREF="|."$dir".q|upc-lib-optional-spec.html#522">|; 
$noresave{$key} = "$nosave";

$key = q/upc_all_fwait_async###4196/;
$index{$key} .= q|<A NAME="tex2html99" HREF="|."$dir".q|upc-lib-optional-spec.html#699">|; 
$noresave{$key} = "$nosave";

$key = q/UPC_DELETE_ON_CLOSE###4117/;
$index{$key} .= q|<A NAME="tex2html39" HREF="|."$dir".q|upc-lib-optional-spec.html#174">|; 
$noresave{$key} = "$nosave";

$key = q/upc_all_fread_local_async###4199/;
$index{$key} .= q|<A NAME="tex2html101" HREF="|."$dir".q|upc-lib-optional-spec.html#712">|; 
$noresave{$key} = "$nosave";

$key = q/upc_all_ftest_async###4197/;
$index{$key} .= q|<A NAME="tex2html100" HREF="|."$dir".q|upc-lib-optional-spec.html#700">|; 
$noresave{$key} = "$nosave";

$key = q/upc_all_fseek###4127/;
$index{$key} .= q|<A NAME="tex2html46" HREF="|."$dir".q|upc-lib-optional-spec.html#288">|; 
$noresave{$key} = "$nosave";

$key = q/upc_all_fopen###4106/;
$index{$key} .= q|<A NAME="tex2html28" HREF="|."$dir".q|upc-lib-optional-spec.html#163">|; 
$noresave{$key} = "$nosave";

$key = q/file writing###4187/;
$index{$key} .= q|<A NAME="tex2html92" HREF="|."$dir".q|upc-lib-optional-spec.html#652">|; 
$noresave{$key} = "$nosave";

$key = q/upc_all_fread_local###4166/;
$index{$key} .= q|<A NAME="tex2html79" HREF="|."$dir".q|upc-lib-optional-spec.html#467">|; 
$noresave{$key} = "$nosave";

$key = q/upc_all_fwrite_shared###4174/;
$index{$key} .= q|<A NAME="tex2html83" HREF="|."$dir".q|upc-lib-optional-spec.html#542">|; 
$noresave{$key} = "$nosave";

$key = q/file size###4141/;
$index{$key} .= q|<A NAME="tex2html57" HREF="|."$dir".q|upc-lib-optional-spec.html#340">|; 
$noresave{$key} = "$nosave";

$key = q/UPC_RDWR###4109/;
$index{$key} .= q|<A NAME="tex2html31" HREF="|."$dir".q|upc-lib-optional-spec.html#166">|; 
$noresave{$key} = "$nosave";

$key = q/file reading###4184/;
$index{$key} .= q|<A NAME="tex2html90" HREF="|."$dir".q|upc-lib-optional-spec.html#630">|; 
$noresave{$key} = "$nosave";

$key = q/asynchronous I\/O###4193/;
$index{$key} .= q|<A NAME="tex2html96" HREF="|."$dir".q|upc-lib-optional-spec.html#695">|; 
$noresave{$key} = "$nosave";

$key = q/end of file###4072/;
$index{$key} .= q|<A NAME="tex2html5" HREF="|."$dir".q|upc-lib-optional-spec.html#58">|; 
$noresave{$key} = "$nosave";

$key = q/upc_all_fread_shared###4168/;
$index{$key} .= q|<A NAME="tex2html80" HREF="|."$dir".q|upc-lib-optional-spec.html#485">|; 
$noresave{$key} = "$nosave";

$key = q/file reading###4194/;
$index{$key} .= q|<A NAME="tex2html97" HREF="|."$dir".q|upc-lib-optional-spec.html#696">|; 
$noresave{$key} = "$nosave";

$key = q/file open###4105/;
$index{$key} .= q|<A NAME="tex2html27" HREF="|."$dir".q|upc-lib-optional-spec.html#162">|; 
$noresave{$key} = "$nosave";

$key = q/UPC_SEEK_END###4131/;
$index{$key} .= q|<A NAME="tex2html50" HREF="|."$dir".q|upc-lib-optional-spec.html#298">|; 
$noresave{$key} = "$nosave";

$key = q/asynchronous I\/O###4081/;
$index{$key} .= q|<A NAME="tex2html11" HREF="|."$dir".q|upc-lib-optional-spec.html#91">|; 
$noresave{$key} = "$nosave";

$key = q/individual file pointer###4149/;
$index{$key} .= q|<A NAME="tex2html64" HREF="|."$dir".q|upc-lib-optional-spec.html#387">|; 
$noresave{$key} = "$nosave";

$key = q/upc_all_fwrite_list_local###4188/;
$index{$key} .= q|<A NAME="tex2html93" HREF="|."$dir".q|upc-lib-optional-spec.html#653">|; 
$noresave{$key} = "$nosave";

$key = q/file pointer###4077/;
$index{$key} .= q|<A NAME="tex2html8" HREF="|."$dir".q|upc-lib-optional-spec.html#77">|; 
$noresave{$key} = "$nosave";

$key = q/UPC_EXCL###4114/;
$index{$key} .= q|<A NAME="tex2html36" HREF="|."$dir".q|upc-lib-optional-spec.html#171">|; 
$noresave{$key} = "$nosave";

$key = q/UPC_GET_FN###4154/;
$index{$key} .= q|<A NAME="tex2html69" HREF="|."$dir".q|upc-lib-optional-spec.html#416">|; 
$noresave{$key} = "$nosave";

$key = q/upc_all_fpreallocate###4140/;
$index{$key} .= q|<A NAME="tex2html56" HREF="|."$dir".q|upc-lib-optional-spec.html#339">|; 
$noresave{$key} = "$nosave";

$key = q/upc_all_fsync###4124/;
$index{$key} .= q|<A NAME="tex2html44" HREF="|."$dir".q|upc-lib-optional-spec.html#276">|; 
$noresave{$key} = "$nosave";

$key = q/UPC_RDONLY###4107/;
$index{$key} .= q|<A NAME="tex2html29" HREF="|."$dir".q|upc-lib-optional-spec.html#164">|; 
$noresave{$key} = "$nosave";

$key = q/upc_all_fwrite_list_shared_async###4213/;
$index{$key} .= q|<A NAME="tex2html108" HREF="|."$dir".q|upc-lib-optional-spec.html#789">|; 
$noresave{$key} = "$nosave";

$key = q/UPC_STRONG_CA###4088/;
$index{$key} .= q|<A NAME="tex2html17" HREF="|."$dir".q|upc-lib-optional-spec.html#115">|; 
$noresave{$key} = "$nosave";

$key = q/file pointer###4096/;
$index{$key} .= q|<A NAME="tex2html22" HREF="|."$dir".q|upc-lib-optional-spec.html#156">|; 
$noresave{$key} = "$nosave";

$key = q/common file pointer###4097/;
$index{$key} .= q|<A NAME="tex2html23" HREF="|."$dir".q|upc-lib-optional-spec.html#157">|; 
$noresave{$key} = "$nosave";

$key = q/UPC_STRONG_CA###4115/;
$index{$key} .= q|<A NAME="tex2html37" HREF="|."$dir".q|upc-lib-optional-spec.html#172">|; 
$noresave{$key} = "$nosave";

$key = q/file atomicity###4086/;
$index{$key} .= q|<A NAME="tex2html15" HREF="|."$dir".q|upc-lib-optional-spec.html#99">|; 
$noresave{$key} = "$nosave";

$key = q/UPC_SEEK_CUR###4130/;
$index{$key} .= q|<A NAME="tex2html49" HREF="|."$dir".q|upc-lib-optional-spec.html#297">|; 
$noresave{$key} = "$nosave";

$key = q/file pointer###4147/;
$index{$key} .= q|<A NAME="tex2html62" HREF="|."$dir".q|upc-lib-optional-spec.html#385">|; 
$noresave{$key} = "$nosave";

$key = q/list I\/O###4176/;
$index{$key} .= q|<A NAME="tex2html84" HREF="|."$dir".q|upc-lib-optional-spec.html#573">|; 
$noresave{$key} = "$nosave";

$key = q/upc_all_fread_shared_async###4201/;
$index{$key} .= q|<A NAME="tex2html102" HREF="|."$dir".q|upc-lib-optional-spec.html#723">|; 
$noresave{$key} = "$nosave";

$key = q/UPC_SEEK_SET###4129/;
$index{$key} .= q|<A NAME="tex2html48" HREF="|."$dir".q|upc-lib-optional-spec.html#296">|; 
$noresave{$key} = "$nosave";

$key = q/upc_io.h###4069/;
$index{$key} .= q|<A NAME="tex2html2" HREF="|."$dir".q|upc-lib-optional-spec.html#48">|; 
$noresave{$key} = "$nosave";

$key = q/__UPC_IO__###4068/;
$index{$key} .= q|<A NAME="tex2html1" HREF="|."$dir".q|upc-lib-optional-spec.html#47">|; 
$noresave{$key} = "$nosave";

$key = q/upc_all_fset_size###4133/;
$index{$key} .= q|<A NAME="tex2html51" HREF="|."$dir".q|upc-lib-optional-spec.html#307">|; 
$noresave{$key} = "$nosave";

$key = q/file interoperability###4091/;
$index{$key} .= q|<A NAME="tex2html19" HREF="|."$dir".q|upc-lib-optional-spec.html#133">|; 
$noresave{$key} = "$nosave";

$key = q/individual file pointer###4098/;
$index{$key} .= q|<A NAME="tex2html24" HREF="|."$dir".q|upc-lib-optional-spec.html#158">|; 
$noresave{$key} = "$nosave";

$key = q/upc_off_t###4093/;
$index{$key} .= q|<A NAME="tex2html20" HREF="|."$dir".q|upc-lib-optional-spec.html#139">|; 
$noresave{$key} = "$nosave";

$key = q/upc_all_fget_size###4137/;
$index{$key} .= q|<A NAME="tex2html54" HREF="|."$dir".q|upc-lib-optional-spec.html#328">|; 
$noresave{$key} = "$nosave";

$key = q/file writing###4190/;
$index{$key} .= q|<A NAME="tex2html94" HREF="|."$dir".q|upc-lib-optional-spec.html#674">|; 
$noresave{$key} = "$nosave";

$key = q/end of file###4135/;
$index{$key} .= q|<A NAME="tex2html53" HREF="|."$dir".q|upc-lib-optional-spec.html#309">|; 
$noresave{$key} = "$nosave";

$key = q/file writing###4170/;
$index{$key} .= q|<A NAME="tex2html81" HREF="|."$dir".q|upc-lib-optional-spec.html#517">|; 
$noresave{$key} = "$nosave";

$key = q/upc_all_fwait_async###4083/;
$index{$key} .= q|<A NAME="tex2html13" HREF="|."$dir".q|upc-lib-optional-spec.html#93">|; 
$noresave{$key} = "$nosave";

$key = q/upc_all_fclose###4121/;
$index{$key} .= q|<A NAME="tex2html42" HREF="|."$dir".q|upc-lib-optional-spec.html#259">|; 
$noresave{$key} = "$nosave";

$key = q/UPC_SET_HINT###4158/;
$index{$key} .= q|<A NAME="tex2html73" HREF="|."$dir".q|upc-lib-optional-spec.html#438">|; 
$noresave{$key} = "$nosave";

$key = q/file hints###4119/;
$index{$key} .= q|<A NAME="tex2html41" HREF="|."$dir".q|upc-lib-optional-spec.html#220">|; 
$noresave{$key} = "$nosave";

$key = q/UPC_GET_FL###4153/;
$index{$key} .= q|<A NAME="tex2html68" HREF="|."$dir".q|upc-lib-optional-spec.html#408">|; 
$noresave{$key} = "$nosave";

$key = q/UPC_ASYNC_OUTSTANDING###4160/;
$index{$key} .= q|<A NAME="tex2html75" HREF="|."$dir".q|upc-lib-optional-spec.html#448">|; 
$noresave{$key} = "$nosave";

$key = q/UPC_SET_WEAK_CA_SEMANTICS###4145/;
$index{$key} .= q|<A NAME="tex2html60" HREF="|."$dir".q|upc-lib-optional-spec.html#371">|; 
$noresave{$key} = "$nosave";

$key = q/UPC_GET_CA_SEMANTICS###4144/;
$index{$key} .= q|<A NAME="tex2html59" HREF="|."$dir".q|upc-lib-optional-spec.html#365">|; 
$noresave{$key} = "$nosave";

$key = q/UPC_SET_INDIVIDUAL_FP###4152/;
$index{$key} .= q|<A NAME="tex2html67" HREF="|."$dir".q|upc-lib-optional-spec.html#401">|; 
$noresave{$key} = "$nosave";

$key = q/upc_all_fwrite_list_shared###4191/;
$index{$key} .= q|<A NAME="tex2html95" HREF="|."$dir".q|upc-lib-optional-spec.html#675">|; 
$noresave{$key} = "$nosave";

$key = q/UPC_GET_HINTS###4157/;
$index{$key} .= q|<A NAME="tex2html72" HREF="|."$dir".q|upc-lib-optional-spec.html#428">|; 
$noresave{$key} = "$nosave";

$key = q/UPC_WRONLY###4108/;
$index{$key} .= q|<A NAME="tex2html30" HREF="|."$dir".q|upc-lib-optional-spec.html#165">|; 
$noresave{$key} = "$nosave";

$key = q/file seek###4128/;
$index{$key} .= q|<A NAME="tex2html47" HREF="|."$dir".q|upc-lib-optional-spec.html#289">|; 
$noresave{$key} = "$nosave";

$key = q/UPC_COMMON_FP###4110/;
$index{$key} .= q|<A NAME="tex2html32" HREF="|."$dir".q|upc-lib-optional-spec.html#167">|; 
$noresave{$key} = "$nosave";

$key = q/upc_all_fread_list_local###4182/;
$index{$key} .= q|<A NAME="tex2html89" HREF="|."$dir".q|upc-lib-optional-spec.html#611">|; 
$noresave{$key} = "$nosave";

$key = q/file size###4138/;
$index{$key} .= q|<A NAME="tex2html55" HREF="|."$dir".q|upc-lib-optional-spec.html#329">|; 
$noresave{$key} = "$nosave";

$key = q/file atomicity###4162/;
$index{$key} .= q|<A NAME="tex2html77" HREF="|."$dir".q|upc-lib-optional-spec.html#453">|; 
$noresave{$key} = "$nosave";

$key = q/file consistency###4073/;
$index{$key} .= q|<A NAME="tex2html6" HREF="|."$dir".q|upc-lib-optional-spec.html#65">|; 
$noresave{$key} = "$nosave";

$key = q/file consistency###4161/;
$index{$key} .= q|<A NAME="tex2html76" HREF="|."$dir".q|upc-lib-optional-spec.html#452">|; 
$noresave{$key} = "$nosave";

$key = q/upc_local_memvec###4177/;
$index{$key} .= q|<A NAME="tex2html85" HREF="|."$dir".q|upc-lib-optional-spec.html#575">|; 
$noresave{$key} = "$nosave";

$key = q/upc_all_fwrite_local_async###4203/;
$index{$key} .= q|<A NAME="tex2html103" HREF="|."$dir".q|upc-lib-optional-spec.html#734">|; 
$noresave{$key} = "$nosave";

$key = q/upc_all_fread_list_shared###4185/;
$index{$key} .= q|<A NAME="tex2html91" HREF="|."$dir".q|upc-lib-optional-spec.html#631">|; 
$noresave{$key} = "$nosave";

$key = q/upc_all_fwrite_shared_async###4205/;
$index{$key} .= q|<A NAME="tex2html104" HREF="|."$dir".q|upc-lib-optional-spec.html#745">|; 
$noresave{$key} = "$nosave";

$key = q/UPC_GET_FP###4150/;
$index{$key} .= q|<A NAME="tex2html65" HREF="|."$dir".q|upc-lib-optional-spec.html#388">|; 
$noresave{$key} = "$nosave";

$key = q/UPC_SET_STRONG_CA_SEMANTICS###4146/;
$index{$key} .= q|<A NAME="tex2html61" HREF="|."$dir".q|upc-lib-optional-spec.html#378">|; 
$noresave{$key} = "$nosave";

$key = q/file atomicity###4074/;
$index{$key} .= q|<A NAME="tex2html7" HREF="|."$dir".q|upc-lib-optional-spec.html#66">|; 
$noresave{$key} = "$nosave";

$key = q/UPC_CREATE###4113/;
$index{$key} .= q|<A NAME="tex2html35" HREF="|."$dir".q|upc-lib-optional-spec.html#170">|; 
$noresave{$key} = "$nosave";

$key = q/upc_all_fsync###4087/;
$index{$key} .= q|<A NAME="tex2html16" HREF="|."$dir".q|upc-lib-optional-spec.html#103">|; 
$noresave{$key} = "$nosave";

$key = q/file hints###4156/;
$index{$key} .= q|<A NAME="tex2html71" HREF="|."$dir".q|upc-lib-optional-spec.html#427">|; 
$noresave{$key} = "$nosave";

$key = q/upc_flag_t###4071/;
$index{$key} .= q|<A NAME="tex2html4" HREF="|."$dir".q|upc-lib-optional-spec.html#51">|; 
$noresave{$key} = "$nosave";

$key = q/file close###4122/;
$index{$key} .= q|<A NAME="tex2html43" HREF="|."$dir".q|upc-lib-optional-spec.html#260">|; 
$noresave{$key} = "$nosave";

$key = q/asynchronous I\/O###4159/;
$index{$key} .= q|<A NAME="tex2html74" HREF="|."$dir".q|upc-lib-optional-spec.html#447">|; 
$noresave{$key} = "$nosave";

$key = q/upc_hint###4118/;
$index{$key} .= q|<A NAME="tex2html40" HREF="|."$dir".q|upc-lib-optional-spec.html#219">|; 
$noresave{$key} = "$nosave";

$key = q/file reading###4164/;
$index{$key} .= q|<A NAME="tex2html78" HREF="|."$dir".q|upc-lib-optional-spec.html#462">|; 
$noresave{$key} = "$nosave";

$key = q/common file pointer###4148/;
$index{$key} .= q|<A NAME="tex2html63" HREF="|."$dir".q|upc-lib-optional-spec.html#386">|; 
$noresave{$key} = "$nosave";

$key = q/upc_all_fread_list_shared_async###4209/;
$index{$key} .= q|<A NAME="tex2html106" HREF="|."$dir".q|upc-lib-optional-spec.html#767">|; 
$noresave{$key} = "$nosave";

$key = q/file reading###4181/;
$index{$key} .= q|<A NAME="tex2html88" HREF="|."$dir".q|upc-lib-optional-spec.html#610">|; 
$noresave{$key} = "$nosave";

$key = q/UPC_TRUNC###4116/;
$index{$key} .= q|<A NAME="tex2html38" HREF="|."$dir".q|upc-lib-optional-spec.html#173">|; 
$noresave{$key} = "$nosave";

$key = q/upc_all_fwait_async###4215/;
$index{$key} .= q|<A NAME="tex2html109" HREF="|."$dir".q|upc-lib-optional-spec.html#800">|; 
$noresave{$key} = "$nosave";

$key = q/common file pointer###4078/;
$index{$key} .= q|<A NAME="tex2html9" HREF="|."$dir".q|upc-lib-optional-spec.html#78">|; 
$noresave{$key} = "$nosave";

$key = q/upc_hint###4155/;
$index{$key} .= q|<A NAME="tex2html70" HREF="|."$dir".q|upc-lib-optional-spec.html#426">|; 
$noresave{$key} = "$nosave";

$key = q/individual file pointer###4079/;
$index{$key} .= q|<A NAME="tex2html10" HREF="|."$dir".q|upc-lib-optional-spec.html#79">|; 
$noresave{$key} = "$nosave";

$key = q/UPC_APPEND###4112/;
$index{$key} .= q|<A NAME="tex2html34" HREF="|."$dir".q|upc-lib-optional-spec.html#169">|; 
$noresave{$key} = "$nosave";

$key = q/UPC_SET_COMMON_FP###4151/;
$index{$key} .= q|<A NAME="tex2html66" HREF="|."$dir".q|upc-lib-optional-spec.html#394">|; 
$noresave{$key} = "$nosave";

$key = q/file flush###4125/;
$index{$key} .= q|<A NAME="tex2html45" HREF="|."$dir".q|upc-lib-optional-spec.html#277">|; 
$noresave{$key} = "$nosave";

$key = q/UPC_INDIVIDUAL_FP###4111/;
$index{$key} .= q|<A NAME="tex2html33" HREF="|."$dir".q|upc-lib-optional-spec.html#168">|; 
$noresave{$key} = "$nosave";

$key = q/upc_file_t###4094/;
$index{$key} .= q|<A NAME="tex2html21" HREF="|."$dir".q|upc-lib-optional-spec.html#142">|; 
$noresave{$key} = "$nosave";

$key = q/upc_all_fcntl###4143/;
$index{$key} .= q|<A NAME="tex2html58" HREF="|."$dir".q|upc-lib-optional-spec.html#355">|; 
$noresave{$key} = "$nosave";

$key = q/file writing###4195/;
$index{$key} .= q|<A NAME="tex2html98" HREF="|."$dir".q|upc-lib-optional-spec.html#697">|; 
$noresave{$key} = "$nosave";

$key = q/UPC_SET_STRONG_CA_SEMANTICS###4089/;
$index{$key} .= q|<A NAME="tex2html18" HREF="|."$dir".q|upc-lib-optional-spec.html#116">|; 
$noresave{$key} = "$nosave";

$key = q/upc_shared_memvec###4178/;
$index{$key} .= q|<A NAME="tex2html86" HREF="|."$dir".q|upc-lib-optional-spec.html#576">|; 
$noresave{$key} = "$nosave";

$key = q/file size###4134/;
$index{$key} .= q|<A NAME="tex2html52" HREF="|."$dir".q|upc-lib-optional-spec.html#308">|; 
$noresave{$key} = "$nosave";

$key = q/upc_all_fwrite_list_local_async###4211/;
$index{$key} .= q|<A NAME="tex2html107" HREF="|."$dir".q|upc-lib-optional-spec.html#778">|; 
$noresave{$key} = "$nosave";

$key = q/file consistency###4085/;
$index{$key} .= q|<A NAME="tex2html14" HREF="|."$dir".q|upc-lib-optional-spec.html#98">|; 
$noresave{$key} = "$nosave";

$key = q/upc_all_ftest_async###4082/;
$index{$key} .= q|<A NAME="tex2html12" HREF="|."$dir".q|upc-lib-optional-spec.html#92">|; 
$noresave{$key} = "$nosave";

$key = q/upc_all_fread_list_local_async###4207/;
$index{$key} .= q|<A NAME="tex2html105" HREF="|."$dir".q|upc-lib-optional-spec.html#756">|; 
$noresave{$key} = "$nosave";

$key = q/upc_filevec###4179/;
$index{$key} .= q|<A NAME="tex2html87" HREF="|."$dir".q|upc-lib-optional-spec.html#577">|; 
$noresave{$key} = "$nosave";

$key = q/upc_all_ftest_async###4218/;
$index{$key} .= q|<A NAME="tex2html111" HREF="|."$dir".q|upc-lib-optional-spec.html#811">|; 
$noresave{$key} = "$nosave";
