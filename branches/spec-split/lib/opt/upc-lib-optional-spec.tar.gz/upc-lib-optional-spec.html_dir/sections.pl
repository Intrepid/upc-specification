# LaTeX2HTML 2008 (1.71)
# Associate sections original text with physical files.


$key = q/0 0 0 2 1 4 1 0 0 0 0 0 0 0 0 0 0 0 0 0/;

$key = q/0 0 0 2 1 7 8 0 0 0 0 0 0 0 0 0 0 0 0 0/;

$key = q/0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$section_info{$key} = '3%:%'."$dir".q|upc-lib-optional-spec.html%:%Contents%:%| unless ($section_info{$key}); 
$noresave{$key} = "$nosave";
$done{"${dir}upc-lib-optional-spec.html"} = 1;

$key = q/0 0 0 2 1 3 6 0 0 0 0 0 0 0 0 0 0 0 0 0/;

$key = q/0 0 0 2 1 7 6 0 0 0 0 0 0 0 0 0 0 0 0 0/;

$key = q/0 0 0 2 1 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$section_info{$key} = '5%:%'."$dir".q|upc-lib-optional-spec.html%:%<SPAN CLASS="arabic">3</SPAN> UPC File Operations%:%| unless ($section_info{$key}); 
$noresave{$key} = "$nosave";
$done{"${dir}upc-lib-optional-spec.html"} = 1;

$key = q/0 0 0 2 1 6 4 0 0 0 0 0 0 0 0 0 0 0 0 0/;

$key = q/0 0 0 2 1 5 1 0 0 0 0 0 0 0 0 0 0 0 0 0/;

$key = q/0 0 0 2 1 3 8 0 0 0 0 0 0 0 0 0 0 0 0 0/;

$key = q/0 0 0 2 1 7 3 0 0 0 0 0 0 0 0 0 0 0 0 0/;

$key = q/0 0 0 2 1 7 1 0 0 0 0 0 0 0 0 0 0 0 0 0/;

$key = q/0 0 0 2 1 3 2 0 0 0 0 0 0 0 0 0 0 0 0 0/;

$key = q/0 0 0 2 1 7 7 0 0 0 0 0 0 0 0 0 0 0 0 0/;

$key = q/0 0 0 2 1 3 7 0 0 0 0 0 0 0 0 0 0 0 0 0/;

$key = q/0 0 0 2 1 1 3 0 0 0 0 0 0 0 0 0 0 0 0 0/;

$key = q/0 0 0 2 1 3 5 0 0 0 0 0 0 0 0 0 0 0 0 0/;

$key = q/0 0 0 2 1 7 9 0 0 0 0 0 0 0 0 0 0 0 0 0/;

$key = q/0 0 0 2 1 6 1 0 0 0 0 0 0 0 0 0 0 0 0 0/;

$key = q/0 0 0 2 1 3 4 0 0 0 0 0 0 0 0 0 0 0 0 0/;

$key = q/0 0 0 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$section_info{$key} = '3%:%'."$dir".q|upc-lib-optional-spec.html%:%About this document ...%:%| unless ($section_info{$key}); 
$noresave{$key} = "$nosave";
$done{"${dir}upc-lib-optional-spec.html"} = 1;

$key = q/0 0 0 2 1 3 3 0 0 0 0 0 0 0 0 0 0 0 0 0/;

$key = q/0 0 0 2 1 6 2 0 0 0 0 0 0 0 0 0 0 0 0 0/;

$key = q/0 0 0 2 1 6 3 0 0 0 0 0 0 0 0 0 0 0 0 0/;

$key = q/0 0 0 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$section_info{$key} = '3%:%'."$dir".q|upc-lib-optional-spec.html%:%Index%:%| unless ($section_info{$key}); 
$noresave{$key} = "$nosave";
$done{"${dir}upc-lib-optional-spec.html"} = 1;

$key = q/0 0 0 2 1 5 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$section_info{$key} = '5%:%'."$dir".q|upc-lib-optional-spec.html%:%<SPAN CLASS="arabic">5</SPAN> Writing Data%:%| unless ($section_info{$key}); 
$noresave{$key} = "$nosave";
$done{"${dir}upc-lib-optional-spec.html"} = 1;

$key = q/0 0 0 2 1 1 1 0 0 0 0 0 0 0 0 0 0 0 0 0/;

$key = q/0 0 0 2 1 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$section_info{$key} = '5%:%'."$dir".q|upc-lib-optional-spec.html%:%<SPAN CLASS="arabic">1</SPAN> Background%:%| unless ($section_info{$key}); 
$noresave{$key} = "$nosave";
$done{"${dir}upc-lib-optional-spec.html"} = 1;

$key = q/0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$section_info{$key} = '0%:%'."$dir".q|upc-lib-optional-spec.html%:%UPC Language Required Library Specifications
V1.2 %:%| unless ($section_info{$key}); 
$noresave{$key} = "$nosave";
$done{"${dir}upc-lib-optional-spec.html"} = 1;

$key = q/0 0 0 2 1 7 10 0 0 0 0 0 0 0 0 0 0 0 0 0/;

$key = q/0 0 0 2 1 7 2 0 0 0 0 0 0 0 0 0 0 0 0 0/;

$key = q/0 0 0 2 1 1 2 0 0 0 0 0 0 0 0 0 0 0 0 0/;

$key = q/0 0 0 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$section_info{$key} = '3%:%'."$dir".q|upc-lib-optional-spec.html%:%<SPAN CLASS="arabic">1</SPAN> Library%:%| unless ($section_info{$key}); 
$noresave{$key} = "$nosave";
$done{"${dir}upc-lib-optional-spec.html"} = 1;

$key = q/0 0 0 2 1 7 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$section_info{$key} = '5%:%'."$dir".q|upc-lib-optional-spec.html%:%<SPAN CLASS="arabic">7</SPAN> Asynchronous I/O%:%| unless ($section_info{$key}); 
$noresave{$key} = "$nosave";
$done{"${dir}upc-lib-optional-spec.html"} = 1;

$key = q/0 0 0 2 1 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$section_info{$key} = '5%:%'."$dir".q|upc-lib-optional-spec.html%:%<SPAN CLASS="arabic">4</SPAN> Reading Data%:%| unless ($section_info{$key}); 
$noresave{$key} = "$nosave";
$done{"${dir}upc-lib-optional-spec.html"} = 1;

$key = q/0 0 0 2 1 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$section_info{$key} = '5%:%'."$dir".q|upc-lib-optional-spec.html%:%<SPAN CLASS="arabic">2</SPAN> Predefined Types%:%| unless ($section_info{$key}); 
$noresave{$key} = "$nosave";
$done{"${dir}upc-lib-optional-spec.html"} = 1;

$key = q/0 0 0 2 1 7 5 0 0 0 0 0 0 0 0 0 0 0 0 0/;

$key = q/0 0 0 2 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$section_info{$key} = '4%:%'."$dir".q|upc-lib-optional-spec.html%:%<SPAN CLASS="arabic">1</SPAN> UPC Parallel I/O <TT>&lt;</TT>upc_io.h<TT>&gt;</TT>%:%| unless ($section_info{$key}); 
$noresave{$key} = "$nosave";
$done{"${dir}upc-lib-optional-spec.html"} = 1;

$key = q/0 0 0 2 1 3 1 0 0 0 0 0 0 0 0 0 0 0 0 0/;

$key = q/0 0 0 2 1 4 2 0 0 0 0 0 0 0 0 0 0 0 0 0/;

$key = q/0 0 0 2 1 1 4 0 0 0 0 0 0 0 0 0 0 0 0 0/;

$key = q/0 0 0 2 1 6 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$section_info{$key} = '5%:%'."$dir".q|upc-lib-optional-spec.html%:%<SPAN CLASS="arabic">6</SPAN> List I/O%:%| unless ($section_info{$key}); 
$noresave{$key} = "$nosave";
$done{"${dir}upc-lib-optional-spec.html"} = 1;

$key = q/0 0 0 2 1 5 2 0 0 0 0 0 0 0 0 0 0 0 0 0/;

$key = q/0 0 0 2 1 7 4 0 0 0 0 0 0 0 0 0 0 0 0 0/;

1;

