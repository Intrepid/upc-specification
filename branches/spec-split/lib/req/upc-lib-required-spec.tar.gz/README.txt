Makefile

	Makefile to build the UPC required library specification.

upc-lib-collectives.tex

	UPC collectives specification.  UPC collectives are a component of
	the UPC required library.

upc-lib-required-spec.tar.gz

	Tar file with both LaTeX and generated PDF files.

upc-lib-required-spec.tex

	The UPC required library specification driver file.
