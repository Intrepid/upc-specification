# LaTeX2HTML 2008 (1.71)
# Associate sections original text with physical files.


$key = q/0 0 0 2 1 2 6 0 0 0 0 0 0 0 0 0 0 0 0 0/;

$key = q/0 0 0 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$section_info{$key} = '3%:%'."$dir".q|upc-lib-required-spec.html%:%A. Proposed Additions and Extensions%:%| unless ($section_info{$key}); 
$noresave{$key} = "$nosave";
$done{"${dir}upc-lib-required-spec.html"} = 1;

$key = q/0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$section_info{$key} = '3%:%'."$dir".q|upc-lib-required-spec.html%:%Contents%:%| unless ($section_info{$key}); 
$noresave{$key} = "$nosave";
$done{"${dir}upc-lib-required-spec.html"} = 1;

$key = q/0 0 0 2 1 2 1 0 0 0 0 0 0 0 0 0 0 0 0 0/;

$key = q/0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$section_info{$key} = '0%:%'."$dir".q|upc-lib-required-spec.html%:%UPC Language Required Library Specifications
V1.2 %:%| unless ($section_info{$key}); 
$noresave{$key} = "$nosave";
$done{"${dir}upc-lib-required-spec.html"} = 1;

$key = q/0 0 0 2 1 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$section_info{$key} = '5%:%'."$dir".q|upc-lib-required-spec.html%:%<SPAN CLASS="arabic">1</SPAN> Standard headers%:%| unless ($section_info{$key}); 
$noresave{$key} = "$nosave";
$done{"${dir}upc-lib-required-spec.html"} = 1;

$key = q/0 0 0 2 1 2 4 0 0 0 0 0 0 0 0 0 0 0 0 0/;

$key = q/0 0 0 2 1 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$section_info{$key} = '5%:%'."$dir".q|upc-lib-required-spec.html%:%<SPAN CLASS="arabic">3</SPAN> Computational Operations%:%| unless ($section_info{$key}); 
$noresave{$key} = "$nosave";
$done{"${dir}upc-lib-required-spec.html"} = 1;

$key = q/0 0 0 2 1 2 2 0 0 0 0 0 0 0 0 0 0 0 0 0/;

$key = q/0 0 0 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$section_info{$key} = '3%:%'."$dir".q|upc-lib-required-spec.html%:%<SPAN CLASS="arabic">1</SPAN> Library%:%| unless ($section_info{$key}); 
$noresave{$key} = "$nosave";
$done{"${dir}upc-lib-required-spec.html"} = 1;

$key = q/0 0 0 5 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$section_info{$key} = '3%:%'."$dir".q|upc-lib-required-spec.html%:%About this document ...%:%| unless ($section_info{$key}); 
$noresave{$key} = "$nosave";
$done{"${dir}upc-lib-required-spec.html"} = 1;

$key = q/0 0 0 2 1 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$section_info{$key} = '5%:%'."$dir".q|upc-lib-required-spec.html%:%<SPAN CLASS="arabic">2</SPAN> Relocalization Operations%:%| unless ($section_info{$key}); 
$noresave{$key} = "$nosave";
$done{"${dir}upc-lib-required-spec.html"} = 1;

$key = q/0 0 0 2 1 2 3 0 0 0 0 0 0 0 0 0 0 0 0 0/;

$key = q/0 0 0 2 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$section_info{$key} = '4%:%'."$dir".q|upc-lib-required-spec.html%:%<SPAN CLASS="arabic">1</SPAN> UPC Collective Utilities <TT>&lt;upc_collective.h&gt;</TT>%:%| unless ($section_info{$key}); 
$noresave{$key} = "$nosave";
$done{"${dir}upc-lib-required-spec.html"} = 1;

$key = q/0 0 0 2 1 3 1 0 0 0 0 0 0 0 0 0 0 0 0 0/;

$key = q/0 0 0 2 1 2 5 0 0 0 0 0 0 0 0 0 0 0 0 0/;

$key = q/0 0 0 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$section_info{$key} = '3%:%'."$dir".q|upc-lib-required-spec.html%:%Index%:%| unless ($section_info{$key}); 
$noresave{$key} = "$nosave";
$done{"${dir}upc-lib-required-spec.html"} = 1;

1;

