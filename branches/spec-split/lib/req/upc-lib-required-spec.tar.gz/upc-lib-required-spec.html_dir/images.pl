# LaTeX2HTML 2008 (1.71)
# Associate images original text with physical files.


$key = q/opluscdotsoplus;MSF=1.6;AAT/;
$cached_env_img{$key} = q|9#9|; 

$key = q/0leq;MSF=1.6;AAT/;
$cached_env_img{$key} = q|10#10|; 

$key = q/*;MSF=1.6;AAT/;
$cached_env_img{$key} = q|7#7|; 

$key = q/{center}vbox{input{upc-terms-and-defs}}{center};AAT/;
$cached_env_img{$key} = q|4#4|; 

$key = q/{center}vbox{input{upc-lib-mem-semantics}}{center};AAT/;
$cached_env_img{$key} = q|12#12|; 

$key = q/{center}vbox{input{upc-acknowledgments}}{center};AAT/;
$cached_env_img{$key} = q|1#1|; 

$key = q/i;MSF=1.6;AAT/;
$cached_env_img{$key} = q|5#5|; 

$key = q/{center}vbox{input{upc-references}}{center};AAT/;
$cached_env_img{$key} = q|13#13|; 

$key = q/oplus;MSF=1.6;AAT/;
$cached_env_img{$key} = q|8#8|; 

$key = q/leq;MSF=1.6;AAT/;
$cached_env_img{$key} = q|11#11|; 

$key = q/{center}vbox{input{upc-scope}}{center};AAT/;
$cached_env_img{$key} = q|3#3|; 

$key = q/{center}vbox{input{upc-introduction}}{center};AAT/;
$cached_env_img{$key} = q|2#2|; 

$key = q/j;MSF=1.6;AAT/;
$cached_env_img{$key} = q|6#6|; 

1;

