# LaTeX2HTML 2008 (1.71)
# Associate index original text with physical files.


$key = q/collective libarary###2222/;
$index{$key} .= q|<A NAME="tex2html1" HREF="|."$dir".q|upc-lib-required-spec.html#47">|; 
$noresave{$key} = "$nosave";

$key = q/gather###2245/;
$index{$key} .= q|<A NAME="tex2html9" HREF="|."$dir".q|upc-lib-required-spec.html#125">|; 
$noresave{$key} = "$nosave";

$key = q/broadcast###2229/;
$index{$key} .= q|<A NAME="tex2html5" HREF="|."$dir".q|upc-lib-required-spec.html#58">|; 
$noresave{$key} = "$nosave";

$key = q/UPC_ADD###2274/;
$index{$key} .= q|<A NAME="tex2html17" HREF="|."$dir".q|upc-lib-required-spec.html#262">|; 
$noresave{$key} = "$nosave";

$key = q/feature macros###2343/;
$index{$key} .= q|<A NAME="tex2html37" HREF="|."$dir".q|upc-lib-required-spec.html#414">|; 
$noresave{$key} = "$nosave";

$key = q/UPC_MAX###2282/;
$index{$key} .= q|<A NAME="tex2html25" HREF="|."$dir".q|upc-lib-required-spec.html#270">|; 
$noresave{$key} = "$nosave";

$key = q/upc_all_gather###2244/;
$index{$key} .= q|<A NAME="tex2html8" HREF="|."$dir".q|upc-lib-required-spec.html#124">|; 
$noresave{$key} = "$nosave";

$key = q/UPC_LOGAND###2279/;
$index{$key} .= q|<A NAME="tex2html22" HREF="|."$dir".q|upc-lib-required-spec.html#267">|; 
$noresave{$key} = "$nosave";

$key = q/prefix reduction###2339/;
$index{$key} .= q|<A NAME="tex2html34" HREF="|."$dir".q|upc-lib-required-spec.html#311">|; 
$noresave{$key} = "$nosave";

$key = q/upc_all_scatter###2236/;
$index{$key} .= q|<A NAME="tex2html6" HREF="|."$dir".q|upc-lib-required-spec.html#92">|; 
$noresave{$key} = "$nosave";

$key = q/reduction###2338/;
$index{$key} .= q|<A NAME="tex2html33" HREF="|."$dir".q|upc-lib-required-spec.html#310">|; 
$noresave{$key} = "$nosave";

$key = q/upc_all_gather_all###2251/;
$index{$key} .= q|<A NAME="tex2html10" HREF="|."$dir".q|upc-lib-required-spec.html#157">|; 
$noresave{$key} = "$nosave";

$key = q/UPC_AND###2276/;
$index{$key} .= q|<A NAME="tex2html19" HREF="|."$dir".q|upc-lib-required-spec.html#264">|; 
$noresave{$key} = "$nosave";

$key = q/upc_all_exchange###2254/;
$index{$key} .= q|<A NAME="tex2html12" HREF="|."$dir".q|upc-lib-required-spec.html#191">|; 
$noresave{$key} = "$nosave";

$key = q/UPC_MIN###2281/;
$index{$key} .= q|<A NAME="tex2html24" HREF="|."$dir".q|upc-lib-required-spec.html#269">|; 
$noresave{$key} = "$nosave";

$key = q/upc_all_reduce###2336/;
$index{$key} .= q|<A NAME="tex2html31" HREF="|."$dir".q|upc-lib-required-spec.html#308">|; 
$noresave{$key} = "$nosave";

$key = q/upc_all_permute###2268/;
$index{$key} .= q|<A NAME="tex2html14" HREF="|."$dir".q|upc-lib-required-spec.html#225">|; 
$noresave{$key} = "$nosave";

$key = q/upc_op_t###2273/;
$index{$key} .= q|<A NAME="tex2html16" HREF="|."$dir".q|upc-lib-required-spec.html#261">|; 
$noresave{$key} = "$nosave";

$key = q/UPC_LOGOR###2280/;
$index{$key} .= q|<A NAME="tex2html23" HREF="|."$dir".q|upc-lib-required-spec.html#268">|; 
$noresave{$key} = "$nosave";

$key = q/gather, to all###2252/;
$index{$key} .= q|<A NAME="tex2html11" HREF="|."$dir".q|upc-lib-required-spec.html#158">|; 
$noresave{$key} = "$nosave";

$key = q/scatter###2237/;
$index{$key} .= q|<A NAME="tex2html7" HREF="|."$dir".q|upc-lib-required-spec.html#93">|; 
$noresave{$key} = "$nosave";

$key = q/exchange###2255/;
$index{$key} .= q|<A NAME="tex2html13" HREF="|."$dir".q|upc-lib-required-spec.html#192">|; 
$noresave{$key} = "$nosave";

$key = q/UPC_XOR###2278/;
$index{$key} .= q|<A NAME="tex2html21" HREF="|."$dir".q|upc-lib-required-spec.html#266">|; 
$noresave{$key} = "$nosave";

$key = q/upc_all_reduce_prefix###2337/;
$index{$key} .= q|<A NAME="tex2html32" HREF="|."$dir".q|upc-lib-required-spec.html#309">|; 
$noresave{$key} = "$nosave";

$key = q/__UPC_COLLECTIVE__###2223/;
$index{$key} .= q|<A NAME="tex2html2" HREF="|."$dir".q|upc-lib-required-spec.html#48">|; 
$noresave{$key} = "$nosave";

$key = q/proposed extensions###2341/;
$index{$key} .= q|<A NAME="tex2html35" HREF="|."$dir".q|upc-lib-required-spec.html#408">|; 
$noresave{$key} = "$nosave";

$key = q/upc_all_broadcast###2228/;
$index{$key} .= q|<A NAME="tex2html4" HREF="|."$dir".q|upc-lib-required-spec.html#57">|; 
$noresave{$key} = "$nosave";

$key = q/upc_collective.h###2224/;
$index{$key} .= q|<A NAME="tex2html3" HREF="|."$dir".q|upc-lib-required-spec.html#49">|; 
$noresave{$key} = "$nosave";

$key = q/UPC_OR###2277/;
$index{$key} .= q|<A NAME="tex2html20" HREF="|."$dir".q|upc-lib-required-spec.html#265">|; 
$noresave{$key} = "$nosave";

$key = q/UPC_MULT###2275/;
$index{$key} .= q|<A NAME="tex2html18" HREF="|."$dir".q|upc-lib-required-spec.html#263">|; 
$noresave{$key} = "$nosave";

$key = q/UPC_NONCOMM_FUNC###2284/;
$index{$key} .= q|<A NAME="tex2html27" HREF="|."$dir".q|upc-lib-required-spec.html#272">|; 
$noresave{$key} = "$nosave";

$key = q/UPC_FUNC###2283/;
$index{$key} .= q|<A NAME="tex2html26" HREF="|."$dir".q|upc-lib-required-spec.html#271">|; 
$noresave{$key} = "$nosave";

$key = q/permute###2269/;
$index{$key} .= q|<A NAME="tex2html15" HREF="|."$dir".q|upc-lib-required-spec.html#226">|; 
$noresave{$key} = "$nosave";
