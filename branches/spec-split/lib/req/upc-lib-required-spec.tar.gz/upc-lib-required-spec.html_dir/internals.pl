# LaTeX2HTML 2008 (1.71)
# Associate internals original text with physical files.


$key = q/upc-op-t-item/;
$ref_files{$key} = "$dir".q|upc-lib-required-spec.html|; 
$noresave{$key} = "$nosave";

$key = q/upc-op-t-section/;
$ref_files{$key} = "$dir".q|upc-lib-required-spec.html|; 
$noresave{$key} = "$nosave";

$key = q/reduction/;
$ref_files{$key} = "$dir".q|upc-lib-required-spec.html|; 
$noresave{$key} = "$nosave";

$key = q/upc-collective/;
$ref_files{$key} = "$dir".q|upc-lib-required-spec.html|; 
$noresave{$key} = "$nosave";

1;

