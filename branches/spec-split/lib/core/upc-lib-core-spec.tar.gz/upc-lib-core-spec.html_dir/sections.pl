# LaTeX2HTML 2008 (1.71)
# Associate sections original text with physical files.


$key = q/0 0 0 2 2 5 4 0 0 0 0 0 0 0 0 0 0 0 0 0/;

$key = q/0 0 0 2 2 5 2 0 0 0 0 0 0 0 0 0 0 0 0 0/;

$key = q/0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$section_info{$key} = '3%:%'."$dir".q|upc-lib-core-spec.html%:%Contents%:%| unless ($section_info{$key}); 
$noresave{$key} = "$nosave";
$done{"${dir}upc-lib-core-spec.html"} = 1;

$key = q/0 0 0 2 2 2 3 0 0 0 0 0 0 0 0 0 0 0 0 0/;

$key = q/0 0 0 2 2 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$section_info{$key} = '5%:%'."$dir".q|upc-lib-core-spec.html%:%<SPAN CLASS="arabic">1</SPAN> Termination of all threads%:%| unless ($section_info{$key}); 
$noresave{$key} = "$nosave";
$done{"${dir}upc-lib-core-spec.html"} = 1;

$key = q/0 0 0 2 2 4 1 0 0 0 0 0 0 0 0 0 0 0 0 0/;

$key = q/0 0 0 2 2 4 6 0 0 0 0 0 0 0 0 0 0 0 0 0/;

$key = q/0 0 0 2 2 2 2 0 0 0 0 0 0 0 0 0 0 0 0 0/;

$key = q/0 0 0 2 2 5 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$section_info{$key} = '5%:%'."$dir".q|upc-lib-core-spec.html%:%<SPAN CLASS="arabic">5</SPAN> Shared string handling functions%:%| unless ($section_info{$key}); 
$noresave{$key} = "$nosave";
$done{"${dir}upc-lib-core-spec.html"} = 1;

$key = q/0 0 0 2 2 2 1 0 0 0 0 0 0 0 0 0 0 0 0 0/;

$key = q/0 0 0 2 2 3 3 0 0 0 0 0 0 0 0 0 0 0 0 0/;

$key = q/0 0 0 2 2 4 3 0 0 0 0 0 0 0 0 0 0 0 0 0/;

$key = q/0 0 0 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$section_info{$key} = '3%:%'."$dir".q|upc-lib-core-spec.html%:%About this document ...%:%| unless ($section_info{$key}); 
$noresave{$key} = "$nosave";
$done{"${dir}upc-lib-core-spec.html"} = 1;

$key = q/0 0 0 2 2 2 5 0 0 0 0 0 0 0 0 0 0 0 0 0/;

$key = q/0 0 0 2 2 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$section_info{$key} = '5%:%'."$dir".q|upc-lib-core-spec.html%:%<SPAN CLASS="arabic">2</SPAN> Shared memory allocation functions%:%| unless ($section_info{$key}); 
$noresave{$key} = "$nosave";
$done{"${dir}upc-lib-core-spec.html"} = 1;

$key = q/0 0 0 2 2 3 4 0 0 0 0 0 0 0 0 0 0 0 0 0/;

$key = q/0 0 0 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$section_info{$key} = '3%:%'."$dir".q|upc-lib-core-spec.html%:%Index%:%| unless ($section_info{$key}); 
$noresave{$key} = "$nosave";
$done{"${dir}upc-lib-core-spec.html"} = 1;

$key = q/0 0 0 2 2 5 1 0 0 0 0 0 0 0 0 0 0 0 0 0/;

$key = q/0 0 0 2 2 4 4 0 0 0 0 0 0 0 0 0 0 0 0 0/;

$key = q/0 0 0 2 2 4 2 0 0 0 0 0 0 0 0 0 0 0 0 0/;

$key = q/0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$section_info{$key} = '0%:%'."$dir".q|upc-lib-core-spec.html%:%UPC Language Core Library Specifications
V1.2 %:%| unless ($section_info{$key}); 
$noresave{$key} = "$nosave";
$done{"${dir}upc-lib-core-spec.html"} = 1;

$key = q/0 0 0 2 2 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$section_info{$key} = '5%:%'."$dir".q|upc-lib-core-spec.html%:%<SPAN CLASS="arabic">3</SPAN> Pointer-to-shared manipulation functions%:%| unless ($section_info{$key}); 
$noresave{$key} = "$nosave";
$done{"${dir}upc-lib-core-spec.html"} = 1;

$key = q/0 0 0 2 2 2 4 0 0 0 0 0 0 0 0 0 0 0 0 0/;

$key = q/0 0 0 2 2 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$section_info{$key} = '5%:%'."$dir".q|upc-lib-core-spec.html%:%<SPAN CLASS="arabic">4</SPAN> Lock functions%:%| unless ($section_info{$key}); 
$noresave{$key} = "$nosave";
$done{"${dir}upc-lib-core-spec.html"} = 1;

$key = q/0 0 0 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$section_info{$key} = '3%:%'."$dir".q|upc-lib-core-spec.html%:%<SPAN CLASS="arabic">1</SPAN> Library%:%| unless ($section_info{$key}); 
$noresave{$key} = "$nosave";
$done{"${dir}upc-lib-core-spec.html"} = 1;

$key = q/0 0 0 2 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$section_info{$key} = '4%:%'."$dir".q|upc-lib-core-spec.html%:%<SPAN CLASS="arabic">1</SPAN> Standard headers%:%| unless ($section_info{$key}); 
$noresave{$key} = "$nosave";
$done{"${dir}upc-lib-core-spec.html"} = 1;

$key = q/0 0 0 2 2 3 1 0 0 0 0 0 0 0 0 0 0 0 0 0/;

$key = q/0 0 0 2 2 4 5 0 0 0 0 0 0 0 0 0 0 0 0 0/;

$key = q/0 0 0 2 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$section_info{$key} = '4%:%'."$dir".q|upc-lib-core-spec.html%:%<SPAN CLASS="arabic">2</SPAN> UPC utilities <TT>&lt;upc.h&gt;</TT>%:%| unless ($section_info{$key}); 
$noresave{$key} = "$nosave";
$done{"${dir}upc-lib-core-spec.html"} = 1;

$key = q/0 0 0 2 2 5 3 0 0 0 0 0 0 0 0 0 0 0 0 0/;

$key = q/0 0 0 2 2 4 7 0 0 0 0 0 0 0 0 0 0 0 0 0/;

$key = q/0 0 0 2 2 3 2 0 0 0 0 0 0 0 0 0 0 0 0 0/;

$key = q/0 0 0 2 2 3 5 0 0 0 0 0 0 0 0 0 0 0 0 0/;

1;

