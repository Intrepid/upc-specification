# LaTeX2HTML 2008 (1.71)
# Associate index original text with physical files.


$key = q/shared object, copying###2408/;
$index{$key} .= q|<A NAME="tex2html37" HREF="|."$dir".q|upc-lib-core-spec.html#302">|; 
$noresave{$key} = "$nosave";

$key = q/affinity###2373/;
$index{$key} .= q|<A NAME="tex2html15" HREF="|."$dir".q|upc-lib-core-spec.html#147">|; 
$noresave{$key} = "$nosave";

$key = q/memory copy###2409/;
$index{$key} .= q|<A NAME="tex2html38" HREF="|."$dir".q|upc-lib-core-spec.html#303">|; 
$noresave{$key} = "$nosave";

$key = q/upc_all_lock_alloc###2396/;
$index{$key} .= q|<A NAME="tex2html30" HREF="|."$dir".q|upc-lib-core-spec.html#243">|; 
$noresave{$key} = "$nosave";

$key = q/upc_lock_free###2399/;
$index{$key} .= q|<A NAME="tex2html32" HREF="|."$dir".q|upc-lib-core-spec.html#253">|; 
$noresave{$key} = "$nosave";

$key = q/upc_lock_t###2392/;
$index{$key} .= q|<A NAME="tex2html28" HREF="|."$dir".q|upc-lib-core-spec.html#220">|; 
$noresave{$key} = "$nosave";

$key = q/phase###2380/;
$index{$key} .= q|<A NAME="tex2html20" HREF="|."$dir".q|upc-lib-core-spec.html#171">|; 
$noresave{$key} = "$nosave";

$key = q/phase###2377/;
$index{$key} .= q|<A NAME="tex2html18" HREF="|."$dir".q|upc-lib-core-spec.html#160">|; 
$noresave{$key} = "$nosave";

$key = q/shared object, allocation###2356/;
$index{$key} .= q|<A NAME="tex2html5" HREF="|."$dir".q|upc-lib-core-spec.html#68">|; 
$noresave{$key} = "$nosave";

$key = q/upc_memput###2415/;
$index{$key} .= q|<A NAME="tex2html41" HREF="|."$dir".q|upc-lib-core-spec.html#339">|; 
$noresave{$key} = "$nosave";

$key = q/synchronization###2389/;
$index{$key} .= q|<A NAME="tex2html26" HREF="|."$dir".q|upc-lib-core-spec.html#217">|; 
$noresave{$key} = "$nosave";

$key = q/upc_resetphase###2379/;
$index{$key} .= q|<A NAME="tex2html19" HREF="|."$dir".q|upc-lib-core-spec.html#170">|; 
$noresave{$key} = "$nosave";

$key = q/upc_local_alloc###2365/;
$index{$key} .= q|<A NAME="tex2html10" HREF="|."$dir".q|upc-lib-core-spec.html#114">|; 
$noresave{$key} = "$nosave";

$key = q/upc_addrfield###2383/;
$index{$key} .= q|<A NAME="tex2html22" HREF="|."$dir".q|upc-lib-core-spec.html#180">|; 
$noresave{$key} = "$nosave";

$key = q/shared object, clearing###2418/;
$index{$key} .= q|<A NAME="tex2html43" HREF="|."$dir".q|upc-lib-core-spec.html#356">|; 
$noresave{$key} = "$nosave";

$key = q/memory allocation###2357/;
$index{$key} .= q|<A NAME="tex2html6" HREF="|."$dir".q|upc-lib-core-spec.html#69">|; 
$noresave{$key} = "$nosave";

$key = q/collective###2351/;
$index{$key} .= q|<A NAME="tex2html3" HREF="|."$dir".q|upc-lib-core-spec.html#54">|; 
$noresave{$key} = "$nosave";

$key = q/upc_localsizeof###2386/;
$index{$key} .= q|<A NAME="tex2html24" HREF="|."$dir".q|upc-lib-core-spec.html#190">|; 
$noresave{$key} = "$nosave";

$key = q/upc_threadof###2376/;
$index{$key} .= q|<A NAME="tex2html17" HREF="|."$dir".q|upc-lib-core-spec.html#159">|; 
$noresave{$key} = "$nosave";

$key = q/mutual exclusion###2390/;
$index{$key} .= q|<A NAME="tex2html27" HREF="|."$dir".q|upc-lib-core-spec.html#218">|; 
$noresave{$key} = "$nosave";

$key = q/upc_free###2368/;
$index{$key} .= q|<A NAME="tex2html12" HREF="|."$dir".q|upc-lib-core-spec.html#128">|; 
$noresave{$key} = "$nosave";

$key = q/upc_threadof###2372/;
$index{$key} .= q|<A NAME="tex2html14" HREF="|."$dir".q|upc-lib-core-spec.html#146">|; 
$noresave{$key} = "$nosave";

$key = q/upc_lock###2402/;
$index{$key} .= q|<A NAME="tex2html34" HREF="|."$dir".q|upc-lib-core-spec.html#271">|; 
$noresave{$key} = "$nosave";

$key = q/upc_global_lock_alloc###2394/;
$index{$key} .= q|<A NAME="tex2html29" HREF="|."$dir".q|upc-lib-core-spec.html#233">|; 
$noresave{$key} = "$nosave";

$key = q/upc_global_alloc###2359/;
$index{$key} .= q|<A NAME="tex2html7" HREF="|."$dir".q|upc-lib-core-spec.html#72">|; 
$noresave{$key} = "$nosave";

$key = q/upc_affinitysize###2385/;
$index{$key} .= q|<A NAME="tex2html23" HREF="|."$dir".q|upc-lib-core-spec.html#189">|; 
$noresave{$key} = "$nosave";

$key = q/upc_all_alloc###2361/;
$index{$key} .= q|<A NAME="tex2html8" HREF="|."$dir".q|upc-lib-core-spec.html#85">|; 
$noresave{$key} = "$nosave";

$key = q/upc_global_exit###2354/;
$index{$key} .= q|<A NAME="tex2html4" HREF="|."$dir".q|upc-lib-core-spec.html#61">|; 
$noresave{$key} = "$nosave";

$key = q/upc_memset###2417/;
$index{$key} .= q|<A NAME="tex2html42" HREF="|."$dir".q|upc-lib-core-spec.html#355">|; 
$noresave{$key} = "$nosave";

$key = q/upc_memcpy###2411/;
$index{$key} .= q|<A NAME="tex2html39" HREF="|."$dir".q|upc-lib-core-spec.html#306">|; 
$noresave{$key} = "$nosave";

$key = q/upc_relaxed.h###2350/;
$index{$key} .= q|<A NAME="tex2html2" HREF="|."$dir".q|upc-lib-core-spec.html#51">|; 
$noresave{$key} = "$nosave";

$key = q/upc_alloc###2363/;
$index{$key} .= q|<A NAME="tex2html9" HREF="|."$dir".q|upc-lib-core-spec.html#101">|; 
$noresave{$key} = "$nosave";

$key = q/upc_strict.h###2349/;
$index{$key} .= q|<A NAME="tex2html1" HREF="|."$dir".q|upc-lib-core-spec.html#48">|; 
$noresave{$key} = "$nosave";

$key = q/upc_lock_attempt###2404/;
$index{$key} .= q|<A NAME="tex2html35" HREF="|."$dir".q|upc-lib-core-spec.html#283">|; 
$noresave{$key} = "$nosave";

$key = q/upc_unlock###2406/;
$index{$key} .= q|<A NAME="tex2html36" HREF="|."$dir".q|upc-lib-core-spec.html#293">|; 
$noresave{$key} = "$nosave";

$key = q/upc_memget###2413/;
$index{$key} .= q|<A NAME="tex2html40" HREF="|."$dir".q|upc-lib-core-spec.html#322">|; 
$noresave{$key} = "$nosave";

$key = q/locks###2388/;
$index{$key} .= q|<A NAME="tex2html25" HREF="|."$dir".q|upc-lib-core-spec.html#216">|; 
$noresave{$key} = "$nosave";
