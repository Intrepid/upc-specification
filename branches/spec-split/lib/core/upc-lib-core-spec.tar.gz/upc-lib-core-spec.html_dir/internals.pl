# LaTeX2HTML 2008 (1.71)
# Associate internals original text with physical files.


$key = q/upc_addrfield/;
$ref_files{$key} = "$dir".q|upc-lib-core-spec.html|; 
$noresave{$key} = "$nosave";

$key = q/upc_lock/;
$ref_files{$key} = "$dir".q|upc-lib-core-spec.html|; 
$noresave{$key} = "$nosave";

$key = q/upc_threadof/;
$ref_files{$key} = "$dir".q|upc-lib-core-spec.html|; 
$noresave{$key} = "$nosave";

$key = q/upc_phaseof/;
$ref_files{$key} = "$dir".q|upc-lib-core-spec.html|; 
$noresave{$key} = "$nosave";

$key = q/upc_global_exit/;
$ref_files{$key} = "$dir".q|upc-lib-core-spec.html|; 
$noresave{$key} = "$nosave";

1;

