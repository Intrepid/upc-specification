# LaTeX2HTML 2008 (1.71)
# Associate labels original text with physical files.


$key = q/upc_addrfield/;
$external_labels{$key} = "$URL/" . q|upc-lib-core-spec.html|; 
$noresave{$key} = "$nosave";

$key = q/upc_lock/;
$external_labels{$key} = "$URL/" . q|upc-lib-core-spec.html|; 
$noresave{$key} = "$nosave";

$key = q/upc_threadof/;
$external_labels{$key} = "$URL/" . q|upc-lib-core-spec.html|; 
$noresave{$key} = "$nosave";

$key = q/upc_phaseof/;
$external_labels{$key} = "$URL/" . q|upc-lib-core-spec.html|; 
$noresave{$key} = "$nosave";

$key = q/upc_global_exit/;
$external_labels{$key} = "$URL/" . q|upc-lib-core-spec.html|; 
$noresave{$key} = "$nosave";

1;


# LaTeX2HTML 2008 (1.71)
# labels from external_latex_labels array.


$key = q/upc-flag-t/;
$external_latex_labels{$key} = q|6.2.6|; 
$noresave{$key} = "$nosave";

$key = q/upc_addrfield/;
$external_latex_labels{$key} = q|6.2.3.4|; 
$noresave{$key} = "$nosave";

$key = q/upc_lock/;
$external_latex_labels{$key} = q|6.2.4|; 
$noresave{$key} = "$nosave";

$key = q/def-access/;
$external_latex_labels{$key} = q|3.5|; 
$noresave{$key} = "$nosave";

$key = q/strict_relaxed/;
$external_latex_labels{$key} = q|5.1.2.3|; 
$noresave{$key} = "$nosave";

$key = q/upc_threadof/;
$external_latex_labels{$key} = q|6.2.3.1|; 
$noresave{$key} = "$nosave";

$key = q/upc_phaseof/;
$external_latex_labels{$key} = q|6.2.3.2|; 
$noresave{$key} = "$nosave";

$key = q/upc_global_exit/;
$external_latex_labels{$key} = q|6.2.1|; 
$noresave{$key} = "$nosave";

1;

