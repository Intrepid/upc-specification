Makefile

	Makefile to build the UPC core library specification.

upc-lib-core-spec.tar.gz

	Tar file with both LaTeX and generated PDF files.

upc-lib-core-spec.tex

	The UPC core library specification driver file.

upc-lib-core.tex

	The main description of the UPC core library.
