# LaTeX2HTML 2008 (1.71)
# Associate index original text with physical files.


$key = q/__UPC_VERSION__###5166/;
$index{$key} .= q|<A NAME="tex2html114" HREF="|."$dir".q|upc-lang-spec.html#646">|; 
$noresave{$key} = "$nosave";

$key = q/UPC_MAX_BLOCK_SIZE###5022/;
$index{$key} .= q|<A NAME="tex2html20" HREF="|."$dir".q|upc-lang-spec.html#90">|; 
$noresave{$key} = "$nosave";

$key = q/Precedes###5517/;
$index{$key} .= q|<A NAME="tex2html150" HREF="|."$dir".q|upc-lang-spec.html#2443">|; 
$noresave{$key} = "$nosave";

$key = q/UPC_MAX_BLOCK_SIZE###5006/;
$index{$key} .= q|<A NAME="tex2html8" HREF="|."$dir".q|upc-lang-spec.html#59">|; 
$noresave{$key} = "$nosave";

$key = q/StrictOnThreads###5247/;
$index{$key} .= q|<A NAME="tex2html129" HREF="|."$dir".q|upc-lang-spec.html#2112">|; 
$noresave{$key} = "$nosave";

$key = q/__UPC__###5165/;
$index{$key} .= q|<A NAME="tex2html113" HREF="|."$dir".q|upc-lang-spec.html#644">|; 
$noresave{$key} = "$nosave";

$key = q/memory consistency###5175/;
$index{$key} .= q|<A NAME="tex2html122" HREF="|."$dir".q|upc-lang-spec.html#2082">|; 
$noresave{$key} = "$nosave";

$key = q/block size, default###5079/;
$index{$key} .= q|<A NAME="tex2html58" HREF="|."$dir".q|upc-lang-spec.html#301">|; 
$noresave{$key} = "$nosave";

$key = q/THREADS###5017/;
$index{$key} .= q|<A NAME="tex2html17" HREF="|."$dir".q|upc-lang-spec.html#79">|; 
$noresave{$key} = "$nosave";

$key = q/upc_threadof###5040/;
$index{$key} .= q|<A NAME="tex2html31" HREF="|."$dir".q|upc-lang-spec.html#169">|; 
$noresave{$key} = "$nosave";

$key = q/definite block size###5082/;
$index{$key} .= q|<A NAME="tex2html61" HREF="|."$dir".q|upc-lang-spec.html#304">|; 
$noresave{$key} = "$nosave";

$key = q/memory consistency, locks###5294/;
$index{$key} .= q|<A NAME="tex2html135" HREF="|."$dir".q|upc-lang-spec.html#2155">|; 
$noresave{$key} = "$nosave";

$key = q/MYTHREAD###5019/;
$index{$key} .= q|<A NAME="tex2html18" HREF="|."$dir".q|upc-lang-spec.html#84">|; 
$noresave{$key} = "$nosave";

$key = q/pointer subtraction###5043/;
$index{$key} .= q|<A NAME="tex2html34" HREF="|."$dir".q|upc-lang-spec.html#172">|; 
$noresave{$key} = "$nosave";

$key = q/struct field, address-of###5058/;
$index{$key} .= q|<A NAME="tex2html47" HREF="|."$dir".q|upc-lang-spec.html#218">|; 
$noresave{$key} = "$nosave";

$key = q/memory consistency, collective library###5343/;
$index{$key} .= q|<A NAME="tex2html142" HREF="|."$dir".q|upc-lang-spec.html#2183">|; 
$noresave{$key} = "$nosave";

$key = q/shared declarations, restrictions###5099/;
$index{$key} .= q|<A NAME="tex2html69" HREF="|."$dir".q|upc-lang-spec.html#376">|; 
$noresave{$key} = "$nosave";

$key = q/upc_blocksizeof###5032/;
$index{$key} .= q|<A NAME="tex2html25" HREF="|."$dir".q|upc-lang-spec.html#142">|; 
$noresave{$key} = "$nosave";

$key = q/strict shared write###5159/;
$index{$key} .= q|<A NAME="tex2html108" HREF="|."$dir".q|upc-lang-spec.html#630">|; 
$noresave{$key} = "$nosave";

$key = q/predefined macros###5164/;
$index{$key} .= q|<A NAME="tex2html112" HREF="|."$dir".q|upc-lang-spec.html#640">|; 
$noresave{$key} = "$nosave";

$key = q/program order###5518/;
$index{$key} .= q|<A NAME="tex2html151" HREF="|."$dir".q|upc-lang-spec.html#2444">|; 
$noresave{$key} = "$nosave";

$key = q/implicit barriers###5129/;
$index{$key} .= q|<A NAME="tex2html93" HREF="|."$dir".q|upc-lang-spec.html#466">|; 
$noresave{$key} = "$nosave";

$key = q/UPC_MAX_BLOCK_SIZE###5167/;
$index{$key} .= q|<A NAME="tex2html115" HREF="|."$dir".q|upc-lang-spec.html#648">|; 
$noresave{$key} = "$nosave";

$key = q/upc_wait###5012/;
$index{$key} .= q|<A NAME="tex2html14" HREF="|."$dir".q|upc-lang-spec.html#65">|; 
$noresave{$key} = "$nosave";

$key = q/upc_elemsizeof###5008/;
$index{$key} .= q|<A NAME="tex2html10" HREF="|."$dir".q|upc-lang-spec.html#61">|; 
$noresave{$key} = "$nosave";

$key = q/strict###5069/;
$index{$key} .= q|<A NAME="tex2html51" HREF="|."$dir".q|upc-lang-spec.html#257">|; 
$noresave{$key} = "$nosave";

$key = q/indefinite block size###5081/;
$index{$key} .= q|<A NAME="tex2html60" HREF="|."$dir".q|upc-lang-spec.html#303">|; 
$noresave{$key} = "$nosave";

$key = q/dynamic THREADS environment###5103/;
$index{$key} .= q|<A NAME="tex2html72" HREF="|."$dir".q|upc-lang-spec.html#385">|; 
$noresave{$key} = "$nosave";

$key = q/sizeof###5028/;
$index{$key} .= q|<A NAME="tex2html23" HREF="|."$dir".q|upc-lang-spec.html#128">|; 
$noresave{$key} = "$nosave";

$key = q/DependsOnThreads###5291/;
$index{$key} .= q|<A NAME="tex2html134" HREF="|."$dir".q|upc-lang-spec.html#2124">|; 
$noresave{$key} = "$nosave";

$key = q/indefinite###5084/;
$index{$key} .= q|<A NAME="tex2html63" HREF="|."$dir".q|upc-lang-spec.html#308">|; 
$noresave{$key} = "$nosave";

$key = q/strict###5010/;
$index{$key} .= q|<A NAME="tex2html12" HREF="|."$dir".q|upc-lang-spec.html#63">|; 
$noresave{$key} = "$nosave";

$key = q/MYTHREAD###5173/;
$index{$key} .= q|<A NAME="tex2html121" HREF="|."$dir".q|upc-lang-spec.html#662">|; 
$noresave{$key} = "$nosave";

$key = q/upc_forall###5014/;
$index{$key} .= q|<A NAME="tex2html16" HREF="|."$dir".q|upc-lang-spec.html#67">|; 
$noresave{$key} = "$nosave";

$key = q/pointer-to-shared###5036/;
$index{$key} .= q|<A NAME="tex2html27" HREF="|."$dir".q|upc-lang-spec.html#165">|; 
$noresave{$key} = "$nosave";

$key = q/continue###5149/;
$index{$key} .= q|<A NAME="tex2html100" HREF="|."$dir".q|upc-lang-spec.html#565">|; 
$noresave{$key} = "$nosave";

$key = q/relaxed###5066/;
$index{$key} .= q|<A NAME="tex2html49" HREF="|."$dir".q|upc-lang-spec.html#226">|; 
$noresave{$key} = "$nosave";

$key = q/block size, automatically-computed###5080/;
$index{$key} .= q|<A NAME="tex2html59" HREF="|."$dir".q|upc-lang-spec.html#302">|; 
$noresave{$key} = "$nosave";

$key = q/pointer-to-local###5037/;
$index{$key} .= q|<A NAME="tex2html28" HREF="|."$dir".q|upc-lang-spec.html#166">|; 
$noresave{$key} = "$nosave";

$key = q/phase###5045/;
$index{$key} .= q|<A NAME="tex2html36" HREF="|."$dir".q|upc-lang-spec.html#174">|; 
$noresave{$key} = "$nosave";

$key = q/pointer-to-shared, casts###5052/;
$index{$key} .= q|<A NAME="tex2html42" HREF="|."$dir".q|upc-lang-spec.html#201">|; 
$noresave{$key} = "$nosave";

$key = q/barriers###5122/;
$index{$key} .= q|<A NAME="tex2html86" HREF="|."$dir".q|upc-lang-spec.html#459">|; 
$noresave{$key} = "$nosave";

$key = q/upc_barrier###5123/;
$index{$key} .= q|<A NAME="tex2html87" HREF="|."$dir".q|upc-lang-spec.html#460">|; 
$noresave{$key} = "$nosave";

$key = q/block size, declaration###5098/;
$index{$key} .= q|<A NAME="tex2html68" HREF="|."$dir".q|upc-lang-spec.html#330">|; 
$noresave{$key} = "$nosave";

$key = q/upc_fence###5130/;
$index{$key} .= q|<A NAME="tex2html94" HREF="|."$dir".q|upc-lang-spec.html#482">|; 
$noresave{$key} = "$nosave";

$key = q/upc_fence###5011/;
$index{$key} .= q|<A NAME="tex2html13" HREF="|."$dir".q|upc-lang-spec.html#64">|; 
$noresave{$key} = "$nosave";

$key = q/MYTHREAD###5001/;
$index{$key} .= q|<A NAME="tex2html3" HREF="|."$dir".q|upc-lang-spec.html#54">|; 
$noresave{$key} = "$nosave";

$key = q/pointer-to-shared, conversion###5053/;
$index{$key} .= q|<A NAME="tex2html43" HREF="|."$dir".q|upc-lang-spec.html#202">|; 
$noresave{$key} = "$nosave";

$key = q/affinity###5044/;
$index{$key} .= q|<A NAME="tex2html35" HREF="|."$dir".q|upc-lang-spec.html#173">|; 
$noresave{$key} = "$nosave";

$key = q/synchronization phase###5126/;
$index{$key} .= q|<A NAME="tex2html90" HREF="|."$dir".q|upc-lang-spec.html#463">|; 
$noresave{$key} = "$nosave";

$key = q/memory consistency, fence###5296/;
$index{$key} .= q|<A NAME="tex2html137" HREF="|."$dir".q|upc-lang-spec.html#2157">|; 
$noresave{$key} = "$nosave";

$key = q/upc_barrier###5002/;
$index{$key} .= q|<A NAME="tex2html4" HREF="|."$dir".q|upc-lang-spec.html#55">|; 
$noresave{$key} = "$nosave";

$key = q/THREADS###5013/;
$index{$key} .= q|<A NAME="tex2html15" HREF="|."$dir".q|upc-lang-spec.html#66">|; 
$noresave{$key} = "$nosave";

$key = q/shared layout qualifier###5071/;
$index{$key} .= q|<A NAME="tex2html53" HREF="|."$dir".q|upc-lang-spec.html#259">|; 
$noresave{$key} = "$nosave";

$key = q/relaxed shared read###5243/;
$index{$key} .= q|<A NAME="tex2html126" HREF="|."$dir".q|upc-lang-spec.html#2089">|; 
$noresave{$key} = "$nosave";

$key = q/upc_notify###5124/;
$index{$key} .= q|<A NAME="tex2html88" HREF="|."$dir".q|upc-lang-spec.html#461">|; 
$noresave{$key} = "$nosave";

$key = q/upc_addrfield###5041/;
$index{$key} .= q|<A NAME="tex2html32" HREF="|."$dir".q|upc-lang-spec.html#170">|; 
$noresave{$key} = "$nosave";

$key = q/strict shared read###5158/;
$index{$key} .= q|<A NAME="tex2html107" HREF="|."$dir".q|upc-lang-spec.html#629">|; 
$noresave{$key} = "$nosave";

$key = q/upc_localsizeof###5003/;
$index{$key} .= q|<A NAME="tex2html5" HREF="|."$dir".q|upc-lang-spec.html#56">|; 
$noresave{$key} = "$nosave";

$key = q/strict###5065/;
$index{$key} .= q|<A NAME="tex2html48" HREF="|."$dir".q|upc-lang-spec.html#225">|; 
$noresave{$key} = "$nosave";

$key = q/block size, indefinite###5077/;
$index{$key} .= q|<A NAME="tex2html56" HREF="|."$dir".q|upc-lang-spec.html#299">|; 
$noresave{$key} = "$nosave";

$key = q/pointer-to-shared, type compatibility###5086/;
$index{$key} .= q|<A NAME="tex2html65" HREF="|."$dir".q|upc-lang-spec.html#311">|; 
$noresave{$key} = "$nosave";

$key = q/relaxed shared write###5244/;
$index{$key} .= q|<A NAME="tex2html127" HREF="|."$dir".q|upc-lang-spec.html#2090">|; 
$noresave{$key} = "$nosave";

$key = q/sequential consistency###5369/;
$index{$key} .= q|<A NAME="tex2html146" HREF="|."$dir".q|upc-lang-spec.html#2202">|; 
$noresave{$key} = "$nosave";

$key = q/work sharing###5150/;
$index{$key} .= q|<A NAME="tex2html101" HREF="|."$dir".q|upc-lang-spec.html#566">|; 
$noresave{$key} = "$nosave";

$key = q/Conflicting###5290/;
$index{$key} .= q|<A NAME="tex2html133" HREF="|."$dir".q|upc-lang-spec.html#2123">|; 
$noresave{$key} = "$nosave";

$key = q/memory consistency###5127/;
$index{$key} .= q|<A NAME="tex2html91" HREF="|."$dir".q|upc-lang-spec.html#464">|; 
$noresave{$key} = "$nosave";

$key = q/memory consistency, non-collective library###5317/;
$index{$key} .= q|<A NAME="tex2html139" HREF="|."$dir".q|upc-lang-spec.html#2173">|; 
$noresave{$key} = "$nosave";

$key = q/block size###5023/;
$index{$key} .= q|<A NAME="tex2html21" HREF="|."$dir".q|upc-lang-spec.html#91">|; 
$noresave{$key} = "$nosave";

$key = q/null strict access###5131/;
$index{$key} .= q|<A NAME="tex2html95" HREF="|."$dir".q|upc-lang-spec.html#487">|; 
$noresave{$key} = "$nosave";

$key = q/upc_forall###5148/;
$index{$key} .= q|<A NAME="tex2html99" HREF="|."$dir".q|upc-lang-spec.html#564">|; 
$noresave{$key} = "$nosave";

$key = q/upc_notify###5009/;
$index{$key} .= q|<A NAME="tex2html11" HREF="|."$dir".q|upc-lang-spec.html#62">|; 
$noresave{$key} = "$nosave";

$key = q/block size, conversion###5056/;
$index{$key} .= q|<A NAME="tex2html46" HREF="|."$dir".q|upc-lang-spec.html#205">|; 
$noresave{$key} = "$nosave";

$key = q/parallel loop###5151/;
$index{$key} .= q|<A NAME="tex2html102" HREF="|."$dir".q|upc-lang-spec.html#567">|; 
$noresave{$key} = "$nosave";

$key = q/block size, definite###5078/;
$index{$key} .= q|<A NAME="tex2html57" HREF="|."$dir".q|upc-lang-spec.html#300">|; 
$noresave{$key} = "$nosave";

$key = q/upc_phaseof###5039/;
$index{$key} .= q|<A NAME="tex2html30" HREF="|."$dir".q|upc-lang-spec.html#168">|; 
$noresave{$key} = "$nosave";

$key = q/collective###5128/;
$index{$key} .= q|<A NAME="tex2html92" HREF="|."$dir".q|upc-lang-spec.html#465">|; 
$noresave{$key} = "$nosave";

$key = q/definite block size###5085/;
$index{$key} .= q|<A NAME="tex2html64" HREF="|."$dir".q|upc-lang-spec.html#310">|; 
$noresave{$key} = "$nosave";

$key = q/upc_wait###5125/;
$index{$key} .= q|<A NAME="tex2html89" HREF="|."$dir".q|upc-lang-spec.html#462">|; 
$noresave{$key} = "$nosave";

$key = q/keywords###4999/;
$index{$key} .= q|<A NAME="tex2html1" HREF="|."$dir".q|upc-lang-spec.html#52">|; 
$noresave{$key} = "$nosave";

$key = q/shared###5007/;
$index{$key} .= q|<A NAME="tex2html9" HREF="|."$dir".q|upc-lang-spec.html#60">|; 
$noresave{$key} = "$nosave";

$key = q/static THREADS environment###5171/;
$index{$key} .= q|<A NAME="tex2html119" HREF="|."$dir".q|upc-lang-spec.html#658">|; 
$noresave{$key} = "$nosave";

$key = q/relaxed###5070/;
$index{$key} .= q|<A NAME="tex2html52" HREF="|."$dir".q|upc-lang-spec.html#258">|; 
$noresave{$key} = "$nosave";

$key = q/relaxed###5004/;
$index{$key} .= q|<A NAME="tex2html6" HREF="|."$dir".q|upc-lang-spec.html#57">|; 
$noresave{$key} = "$nosave";

$key = q/__UPC_DYNAMIC_THREADS__###5168/;
$index{$key} .= q|<A NAME="tex2html116" HREF="|."$dir".q|upc-lang-spec.html#653">|; 
$noresave{$key} = "$nosave";

$key = q/upc_elemsizeof###5034/;
$index{$key} .= q|<A NAME="tex2html26" HREF="|."$dir".q|upc-lang-spec.html#155">|; 
$noresave{$key} = "$nosave";

$key = q/shared access###5240/;
$index{$key} .= q|<A NAME="tex2html123" HREF="|."$dir".q|upc-lang-spec.html#2086">|; 
$noresave{$key} = "$nosave";

$key = q/shared declarations, scalar###5100/;
$index{$key} .= q|<A NAME="tex2html70" HREF="|."$dir".q|upc-lang-spec.html#381">|; 
$noresave{$key} = "$nosave";

$key = q/StrictPairs###5246/;
$index{$key} .= q|<A NAME="tex2html128" HREF="|."$dir".q|upc-lang-spec.html#2111">|; 
$noresave{$key} = "$nosave";

$key = q/memory consistency, barriers###5295/;
$index{$key} .= q|<A NAME="tex2html136" HREF="|."$dir".q|upc-lang-spec.html#2156">|; 
$noresave{$key} = "$nosave";

$key = q/THREADS###5172/;
$index{$key} .= q|<A NAME="tex2html120" HREF="|."$dir".q|upc-lang-spec.html#661">|; 
$noresave{$key} = "$nosave";

$key = q/shared declarations, examples###5087/;
$index{$key} .= q|<A NAME="tex2html66" HREF="|."$dir".q|upc-lang-spec.html#317">|; 
$noresave{$key} = "$nosave";

$key = q/blocking factor###5083/;
$index{$key} .= q|<A NAME="tex2html62" HREF="|."$dir".q|upc-lang-spec.html#305">|; 
$noresave{$key} = "$nosave";

$key = q/dynamic THREADS environment###5169/;
$index{$key} .= q|<A NAME="tex2html117" HREF="|."$dir".q|upc-lang-spec.html#654">|; 
$noresave{$key} = "$nosave";

$key = q/upc_localsizeof###5030/;
$index{$key} .= q|<A NAME="tex2html24" HREF="|."$dir".q|upc-lang-spec.html#133">|; 
$noresave{$key} = "$nosave";

$key = q/memory consistency, examples###5372/;
$index{$key} .= q|<A NAME="tex2html148" HREF="|."$dir".q|upc-lang-spec.html#2221">|; 
$noresave{$key} = "$nosave";

$key = q/block size###5067/;
$index{$key} .= q|<A NAME="tex2html50" HREF="|."$dir".q|upc-lang-spec.html#227">|; 
$noresave{$key} = "$nosave";

$key = q/pointer equality###5042/;
$index{$key} .= q|<A NAME="tex2html33" HREF="|."$dir".q|upc-lang-spec.html#171">|; 
$noresave{$key} = "$nosave";

$key = q/relaxed shared write###5161/;
$index{$key} .= q|<A NAME="tex2html110" HREF="|."$dir".q|upc-lang-spec.html#632">|; 
$noresave{$key} = "$nosave";

$key = q/synchronization###5121/;
$index{$key} .= q|<A NAME="tex2html85" HREF="|."$dir".q|upc-lang-spec.html#458">|; 
$noresave{$key} = "$nosave";

$key = q/pragmas###5154/;
$index{$key} .= q|<A NAME="tex2html103" HREF="|."$dir".q|upc-lang-spec.html#625">|; 
$noresave{$key} = "$nosave";

$key = q/strict shared read###5241/;
$index{$key} .= q|<A NAME="tex2html124" HREF="|."$dir".q|upc-lang-spec.html#2087">|; 
$noresave{$key} = "$nosave";

$key = q/strict shared write###5242/;
$index{$key} .= q|<A NAME="tex2html125" HREF="|."$dir".q|upc-lang-spec.html#2088">|; 
$noresave{$key} = "$nosave";

$key = q/AllStrict###5248/;
$index{$key} .= q|<A NAME="tex2html130" HREF="|."$dir".q|upc-lang-spec.html#2113">|; 
$noresave{$key} = "$nosave";

$key = q/static THREADS environment###5104/;
$index{$key} .= q|<A NAME="tex2html73" HREF="|."$dir".q|upc-lang-spec.html#386">|; 
$noresave{$key} = "$nosave";

$key = q/upc_blocksizeof###5005/;
$index{$key} .= q|<A NAME="tex2html7" HREF="|."$dir".q|upc-lang-spec.html#58">|; 
$noresave{$key} = "$nosave";

$key = q/shared declarations, examples###5108/;
$index{$key} .= q|<A NAME="tex2html77" HREF="|."$dir".q|upc-lang-spec.html#396">|; 
$noresave{$key} = "$nosave";

$key = q/pointer addition###5038/;
$index{$key} .= q|<A NAME="tex2html29" HREF="|."$dir".q|upc-lang-spec.html#167">|; 
$noresave{$key} = "$nosave";

$key = q/relaxed shared read###5160/;
$index{$key} .= q|<A NAME="tex2html109" HREF="|."$dir".q|upc-lang-spec.html#631">|; 
$noresave{$key} = "$nosave";

$key = q/__UPC_STATIC_THREADS__###5170/;
$index{$key} .= q|<A NAME="tex2html118" HREF="|."$dir".q|upc-lang-spec.html#657">|; 
$noresave{$key} = "$nosave";

$key = q/upc_phaseof###5107/;
$index{$key} .= q|<A NAME="tex2html76" HREF="|."$dir".q|upc-lang-spec.html#393">|; 
$noresave{$key} = "$nosave";

$key = q/shared access###5157/;
$index{$key} .= q|<A NAME="tex2html106" HREF="|."$dir".q|upc-lang-spec.html#628">|; 
$noresave{$key} = "$nosave";

$key = q/pointer-to-shared, null###5054/;
$index{$key} .= q|<A NAME="tex2html44" HREF="|."$dir".q|upc-lang-spec.html#203">|; 
$noresave{$key} = "$nosave";

$key = q/strict###5155/;
$index{$key} .= q|<A NAME="tex2html104" HREF="|."$dir".q|upc-lang-spec.html#626">|; 
$noresave{$key} = "$nosave";

$key = q/tokens###5000/;
$index{$key} .= q|<A NAME="tex2html2" HREF="|."$dir".q|upc-lang-spec.html#53">|; 
$noresave{$key} = "$nosave";

$key = q/relaxed###5156/;
$index{$key} .= q|<A NAME="tex2html105" HREF="|."$dir".q|upc-lang-spec.html#627">|; 
$noresave{$key} = "$nosave";

$key = q/pointer-to-shared, generic###5055/;
$index{$key} .= q|<A NAME="tex2html45" HREF="|."$dir".q|upc-lang-spec.html#204">|; 
$noresave{$key} = "$nosave";

$key = q/shared declarations, array###5102/;
$index{$key} .= q|<A NAME="tex2html71" HREF="|."$dir".q|upc-lang-spec.html#384">|; 
$noresave{$key} = "$nosave";

$key = q/PotentialRaces###5370/;
$index{$key} .= q|<A NAME="tex2html147" HREF="|."$dir".q|upc-lang-spec.html#2208">|; 
$noresave{$key} = "$nosave";
