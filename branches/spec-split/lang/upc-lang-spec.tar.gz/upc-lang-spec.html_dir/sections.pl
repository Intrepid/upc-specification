# LaTeX2HTML 2008 (1.71)
# Associate sections original text with physical files.


$key = q/0 0 0 2 3 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$section_info{$key} = '5%:%'."$dir".q|upc-lang-spec.html%:%<SPAN CLASS="arabic">1</SPAN> <TT>THREADS</TT>%:%| unless ($section_info{$key}); 
$noresave{$key} = "$nosave";
$done{"${dir}upc-lang-spec.html"} = 1;

$key = q/0 0 0 2 3 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$section_info{$key} = '5%:%'."$dir".q|upc-lang-spec.html%:%<SPAN CLASS="arabic">3</SPAN> <TT>UPC_MAX_BLOCK_SIZE</TT>%:%| unless ($section_info{$key}); 
$noresave{$key} = "$nosave";
$done{"${dir}upc-lang-spec.html"} = 1;

$key = q/0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$section_info{$key} = '3%:%'."$dir".q|upc-lang-spec.html%:%Contents%:%| unless ($section_info{$key}); 
$noresave{$key} = "$nosave";
$done{"${dir}upc-lang-spec.html"} = 1;

$key = q/0 0 0 2 5 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$section_info{$key} = '5%:%'."$dir".q|upc-lang-spec.html%:%<SPAN CLASS="arabic">1</SPAN> Type qualifiers%:%| unless ($section_info{$key}); 
$noresave{$key} = "$nosave";
$done{"${dir}upc-lang-spec.html"} = 1;

$key = q/0 0 0 3 3 2 2 0 0 0 0 0 0 0 0 0 0 0 0 0/;

$key = q/0 0 0 2 4 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$section_info{$key} = '5%:%'."$dir".q|upc-lang-spec.html%:%<SPAN CLASS="arabic">1</SPAN> Unary Operators%:%| unless ($section_info{$key}); 
$noresave{$key} = "$nosave";
$done{"${dir}upc-lang-spec.html"} = 1;

$key = q/0 0 0 2 7 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$section_info{$key} = '4%:%'."$dir".q|upc-lang-spec.html%:%<SPAN CLASS="arabic">7</SPAN> Preprocessing directives%:%| unless ($section_info{$key}); 
$noresave{$key} = "$nosave";
$done{"${dir}upc-lang-spec.html"} = 1;

$key = q/0 0 0 2 6 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$section_info{$key} = '5%:%'."$dir".q|upc-lang-spec.html%:%<SPAN CLASS="arabic">1</SPAN> Barrier statements%:%| unless ($section_info{$key}); 
$noresave{$key} = "$nosave";
$done{"${dir}upc-lang-spec.html"} = 1;

$key = q/0 0 0 2 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$section_info{$key} = '4%:%'."$dir".q|upc-lang-spec.html%:%<SPAN CLASS="arabic">4</SPAN> Expressions%:%| unless ($section_info{$key}); 
$noresave{$key} = "$nosave";
$done{"${dir}upc-lang-spec.html"} = 1;

$key = q/0 0 0 3 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$section_info{$key} = '4%:%'."$dir".q|upc-lang-spec.html%:%<SPAN CLASS="arabic">2</SPAN> Memory Access Model%:%| unless ($section_info{$key}); 
$noresave{$key} = "$nosave";
$done{"${dir}upc-lang-spec.html"} = 1;

$key = q/0 0 0 2 5 2 1 0 0 0 0 0 0 0 0 0 0 0 0 0/;

$key = q/0 0 0 3 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$section_info{$key} = '4%:%'."$dir".q|upc-lang-spec.html%:%<SPAN CLASS="arabic">4</SPAN> Properties Implied by the Specification%:%| unless ($section_info{$key}); 
$noresave{$key} = "$nosave";
$done{"${dir}upc-lang-spec.html"} = 1;

$key = q/0 0 0 2 4 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$section_info{$key} = '5%:%'."$dir".q|upc-lang-spec.html%:%<SPAN CLASS="arabic">4</SPAN> Address operators%:%| unless ($section_info{$key}); 
$noresave{$key} = "$nosave";
$done{"${dir}upc-lang-spec.html"} = 1;

$key = q/0 0 0 3 3 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$section_info{$key} = '5%:%'."$dir".q|upc-lang-spec.html%:%<SPAN CLASS="arabic">1</SPAN> Consistency Semantics of Synchronization Operations%:%| unless ($section_info{$key}); 
$noresave{$key} = "$nosave";
$done{"${dir}upc-lang-spec.html"} = 1;

$key = q/0 0 0 2 7 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$section_info{$key} = '5%:%'."$dir".q|upc-lang-spec.html%:%<SPAN CLASS="arabic">1</SPAN> UPC pragmas%:%| unless ($section_info{$key}); 
$noresave{$key} = "$nosave";
$done{"${dir}upc-lang-spec.html"} = 1;

$key = q/0 0 0 3 3 2 1 0 0 0 0 0 0 0 0 0 0 0 0 0/;

$key = q/0 0 0 2 7 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$section_info{$key} = '5%:%'."$dir".q|upc-lang-spec.html%:%<SPAN CLASS="arabic">2</SPAN> Predefined macro names%:%| unless ($section_info{$key}); 
$noresave{$key} = "$nosave";
$done{"${dir}upc-lang-spec.html"} = 1;

$key = q/0 0 0 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$section_info{$key} = '3%:%'."$dir".q|upc-lang-spec.html%:%<SPAN CLASS="arabic">3</SPAN> UPC versus C Standard Section Numbering%:%| unless ($section_info{$key}); 
$noresave{$key} = "$nosave";
$done{"${dir}upc-lang-spec.html"} = 1;

$key = q/0 0 0 3 6 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$section_info{$key} = '4%:%'."$dir".q|upc-lang-spec.html%:%<SPAN CLASS="arabic">6</SPAN> Formal Definition of Precedes%:%| unless ($section_info{$key}); 
$noresave{$key} = "$nosave";
$done{"${dir}upc-lang-spec.html"} = 1;

$key = q/0 0 0 3 5 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$section_info{$key} = '4%:%'."$dir".q|upc-lang-spec.html%:%<SPAN CLASS="arabic">5</SPAN> Examples%:%| unless ($section_info{$key}); 
$noresave{$key} = "$nosave";
$done{"${dir}upc-lang-spec.html"} = 1;

$key = q/0 0 0 3 3 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$section_info{$key} = '5%:%'."$dir".q|upc-lang-spec.html%:%<SPAN CLASS="arabic">2</SPAN> Consistency Semantics of Standard Library Calls%:%| unless ($section_info{$key}); 
$noresave{$key} = "$nosave";
$done{"${dir}upc-lang-spec.html"} = 1;

$key = q/0 0 0 2 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$section_info{$key} = '4%:%'."$dir".q|upc-lang-spec.html%:%<SPAN CLASS="arabic">3</SPAN> Predefined identifiers%:%| unless ($section_info{$key}); 
$noresave{$key} = "$nosave";
$done{"${dir}upc-lang-spec.html"} = 1;

$key = q/0 0 0 2 5 1 1 0 0 0 0 0 0 0 0 0 0 0 0 0/;

$key = q/0 0 0 3 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$section_info{$key} = '4%:%'."$dir".q|upc-lang-spec.html%:%<SPAN CLASS="arabic">1</SPAN> Definitions%:%| unless ($section_info{$key}); 
$noresave{$key} = "$nosave";
$done{"${dir}upc-lang-spec.html"} = 1;

$key = q/0 0 0 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$section_info{$key} = '3%:%'."$dir".q|upc-lang-spec.html%:%<SPAN CLASS="arabic">2</SPAN> Formal UPC Memory Consistency Semantics%:%| unless ($section_info{$key}); 
$noresave{$key} = "$nosave";
$done{"${dir}upc-lang-spec.html"} = 1;

$key = q/0 0 0 6 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$section_info{$key} = '3%:%'."$dir".q|upc-lang-spec.html%:%About this document ...%:%| unless ($section_info{$key}); 
$noresave{$key} = "$nosave";
$done{"${dir}upc-lang-spec.html"} = 1;

$key = q/0 0 0 2 6 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$section_info{$key} = '5%:%'."$dir".q|upc-lang-spec.html%:%<SPAN CLASS="arabic">2</SPAN> Iteration statements%:%| unless ($section_info{$key}); 
$noresave{$key} = "$nosave";
$done{"${dir}upc-lang-spec.html"} = 1;

$key = q/0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$section_info{$key} = '0%:%'."$dir".q|upc-lang-spec.html%:%UPC Language Specifications
V1.2 %:%| unless ($section_info{$key}); 
$noresave{$key} = "$nosave";
$done{"${dir}upc-lang-spec.html"} = 1;

$key = q/0 0 0 2 4 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$section_info{$key} = '5%:%'."$dir".q|upc-lang-spec.html%:%<SPAN CLASS="arabic">2</SPAN> Pointer-to-shared arithmetic%:%| unless ($section_info{$key}); 
$noresave{$key} = "$nosave";
$done{"${dir}upc-lang-spec.html"} = 1;

$key = q/0 0 0 2 3 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$section_info{$key} = '5%:%'."$dir".q|upc-lang-spec.html%:%<SPAN CLASS="arabic">2</SPAN> <TT>MYTHREAD</TT>%:%| unless ($section_info{$key}); 
$noresave{$key} = "$nosave";
$done{"${dir}upc-lang-spec.html"} = 1;

$key = q/0 0 0 2 4 1 2 0 0 0 0 0 0 0 0 0 0 0 0 0/;

$key = q/0 0 0 2 4 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$section_info{$key} = '5%:%'."$dir".q|upc-lang-spec.html%:%<SPAN CLASS="arabic">3</SPAN> Cast and assignment expressions%:%| unless ($section_info{$key}); 
$noresave{$key} = "$nosave";
$done{"${dir}upc-lang-spec.html"} = 1;

$key = q/0 0 0 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$section_info{$key} = '3%:%'."$dir".q|upc-lang-spec.html%:%<SPAN CLASS="arabic">1</SPAN> Language%:%| unless ($section_info{$key}); 
$noresave{$key} = "$nosave";
$done{"${dir}upc-lang-spec.html"} = 1;

$key = q/0 0 0 3 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$section_info{$key} = '4%:%'."$dir".q|upc-lang-spec.html%:%<SPAN CLASS="arabic">3</SPAN> Consistency Semantics of Standard Libraries and Language Operations%:%| unless ($section_info{$key}); 
$noresave{$key} = "$nosave";
$done{"${dir}upc-lang-spec.html"} = 1;

$key = q/0 0 0 5 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$section_info{$key} = '3%:%'."$dir".q|upc-lang-spec.html%:%Index%:%| unless ($section_info{$key}); 
$noresave{$key} = "$nosave";
$done{"${dir}upc-lang-spec.html"} = 1;

$key = q/0 0 0 2 6 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$section_info{$key} = '4%:%'."$dir".q|upc-lang-spec.html%:%<SPAN CLASS="arabic">6</SPAN> Statements and blocks%:%| unless ($section_info{$key}); 
$noresave{$key} = "$nosave";
$done{"${dir}upc-lang-spec.html"} = 1;

$key = q/0 0 0 2 5 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$section_info{$key} = '4%:%'."$dir".q|upc-lang-spec.html%:%<SPAN CLASS="arabic">5</SPAN> Declarations%:%| unless ($section_info{$key}); 
$noresave{$key} = "$nosave";
$done{"${dir}upc-lang-spec.html"} = 1;

$key = q/0 0 0 2 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$section_info{$key} = '4%:%'."$dir".q|upc-lang-spec.html%:%<SPAN CLASS="arabic">1</SPAN> Notations%:%| unless ($section_info{$key}); 
$noresave{$key} = "$nosave";
$done{"${dir}upc-lang-spec.html"} = 1;

$key = q/0 0 0 2 4 1 3 0 0 0 0 0 0 0 0 0 0 0 0 0/;

$key = q/0 0 0 2 5 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$section_info{$key} = '5%:%'."$dir".q|upc-lang-spec.html%:%<SPAN CLASS="arabic">2</SPAN> Declarators%:%| unless ($section_info{$key}); 
$noresave{$key} = "$nosave";
$done{"${dir}upc-lang-spec.html"} = 1;

$key = q/0 0 0 2 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$section_info{$key} = '4%:%'."$dir".q|upc-lang-spec.html%:%<SPAN CLASS="arabic">2</SPAN> Keywords%:%| unless ($section_info{$key}); 
$noresave{$key} = "$nosave";
$done{"${dir}upc-lang-spec.html"} = 1;

$key = q/0 0 0 2 4 1 1 0 0 0 0 0 0 0 0 0 0 0 0 0/;

$key = q/0 0 0 2 4 1 4 0 0 0 0 0 0 0 0 0 0 0 0 0/;

1;

