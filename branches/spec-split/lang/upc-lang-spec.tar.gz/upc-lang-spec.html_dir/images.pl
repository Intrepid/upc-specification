# LaTeX2HTML 2008 (1.71)
# Associate images original text with physical files.


$key = q/RR(M);MSF=1.6;AAT/;
$cached_env_img{$key} = q|25#25|; 

$key = q/<_1;MSF=1.6;AAT/;
$cached_env_img{$key} = q|107#107|; 

$key = q/{center}vbox{input{upc-acknowledgments}}{center};AAT/;
$cached_env_img{$key} = q|1#1|; 

$key = q/DependOnThreads(M_t);MSF=1.6;AAT/;
$cached_env_img{$key} = q|39#39|; 

$key = q/m_2;MSF=1.6;AAT/;
$cached_env_img{$key} = q|131#131|; 

$key = q/(m_1,m_2)inPotentialRaces(M);MSF=1.6;AAT/;
$cached_env_img{$key} = q|83#83|; 

$key = q/local_z0==0;MSF=1.6;AAT/;
$cached_env_img{$key} = q|69#69|; 

$key = q/RW(x,1)<_{Strict}RR(x,0);MSF=1.6;AAT/;
$cached_env_img{$key} = q|124#124|; 

$key = q/<_{t};MSF=1.6;AAT/;
$cached_env_img{$key} = q|49#49|; 

$key = q/local_z0;MSF=1.6;AAT/;
$cached_env_img{$key} = q|71#71|; 

$key = q/upc_notify;MSF=1.6;AAT/;
$cached_env_img{$key} = q|54#54|; 

$key = q/{center}vbox{input{upc-references}}{center};AAT/;
$cached_env_img{$key} = q|137#137|; 

$key = q/upc_lock();MSF=1.6;AAT/;
$cached_env_img{$key} = q|58#58|; 

$key = q/(=SW*);MSF=1.6;AAT/;
$cached_env_img{$key} = q|119#119|; 

$key = q/textstyleparbox{3in}{Tosatisfywrite-to-readdataflowin{<_1{,RW(x,1)mustfollowRR(x.Therearethreeothervalid{<_1{orderingswhichsatisfytheseconstraints.};MSF=1.6;AAT/;
$cached_env_img{$key} = q|102#102|; 

$key = q/textstyleparbox{3in}{T0{observesonlyitsownwrites.Thewritesarenon-conflicting,soeitherorderingconstitutesavalid{<_0{.};MSF=1.6;AAT/;
$cached_env_img{$key} = q|101#101|; 

$key = q/(=SR*);MSF=1.6;AAT/;
$cached_env_img{$key} = q|120#120|; 

$key = q/DependOnThreads(M_0);MSF=1.6;AAT/;
$cached_env_img{$key} = q|114#114|; 

$key = q/textstyleparbox{2in}{Relaxedreadshavebeenreordered.Other{<_1{ordersarepossible.};MSF=1.6;AAT/;
$cached_env_img{$key} = q|118#118|; 

$key = q/PotentialRaces(M);MSF=1.6;AAT/;
$cached_env_img{$key} = q|80#80|; 

$key = q/MsubseteqO;MSF=1.6;AAT/;
$cached_env_img{$key} = q|20#20|; 

$key = q/Strict(M);MSF=1.6;AAT/;
$cached_env_img{$key} = q|31#31|; 

$key = q/_{opt};MSF=1.6;AAT/;
$cached_env_img{$key} = q|6#6|; 

$key = q/expression_{opt};MSF=1.6;AAT/;
$cached_env_img{$key} = q|5#5|; 

$key = q/PotentialRaces;MSF=1.6;AAT/;
$cached_env_img{$key} = q|85#85|; 

$key = q/SW(M);MSF=1.6;AAT/;
$cached_env_img{$key} = q|24#24|; 

$key = q/local_x==0;MSF=1.6;AAT/;
$cached_env_img{$key} = q|70#70|; 

$key = q/Thread(m);MSF=1.6;AAT/;
$cached_env_img{$key} = q|17#17|; 

$key = q/O_t;MSF=1.6;AAT/;
$cached_env_img{$key} = q|10#10|; 

$key = q/SW(l_{synch},0);MSF=1.6;AAT/;
$cached_env_img{$key} = q|55#55|; 

$key = q/DependOnThreads(M);MSF=1.6;AAT/;
$cached_env_img{$key} = q|50#50|; 

$key = q/{center}vbox{input{upc-terms-and-defs}}{center};AAT/;
$cached_env_img{$key} = q|4#4|; 

$key = q/DependOnThreads(M_1);MSF=1.6;AAT/;
$cached_env_img{$key} = q|109#109|; 

$key = q/Rightarrow;MSF=1.6;AAT/;
$cached_env_img{$key} = q|91#91|; 

$key = q/{displaymath}AllStrict(M){defatop=}StrictPairs(M)cupStrictOnThreads(M){displaymath};MSF=1.6;AAT/;
$cached_env_img{$key} = q|38#38|; 

$key = q/textstyleparbox{3in}{DependOnThreads(M_0)impliestheseedgesinStrictOnThreads(M)mustberespectedby<_{Strict}.footnotemark};MSF=1.6;AAT/;
$cached_env_img{$key} = q|127#127|; 

$key = q/<_t;MSF=1.6;AAT/;
$cached_env_img{$key} = q|47#47|; 

$key = q/x,y,z[0];MSF=1.6;AAT/;
$cached_env_img{$key} = q|65#65|; 

$key = q/upc_unlock;MSF=1.6;AAT/;
$cached_env_img{$key} = q|60#60|; 

$key = q/local_z1;MSF=1.6;AAT/;
$cached_env_img{$key} = q|72#72|; 

$key = q/linL;MSF=1.6;AAT/;
$cached_env_img{$key} = q|13#13|; 

$key = q/textstyleparbox{2in}{vspace{0.5in}Readcannotreturn0.};MSF=1.6;AAT/;
$cached_env_img{$key} = q|128#128|; 

$key = q/textstyleparbox{3in}{Analogoussituationwithawrite-after-read,thistimeonx.Severalothervalid{<_1{orderingsarepossible.};MSF=1.6;AAT/;
$cached_env_img{$key} = q|104#104|; 

$key = q/textstyleparbox{2.5in}{<_1{conformsto{<_{Strict}{.T1'soperationsonxdonotconflictayappearrelativelyreorderedin{<_1{.Oneother{<_1{orderingispossible.};MSF=1.6;AAT/;
$cached_env_img{$key} = q|108#108|; 

$key = q/textstyleparbox{2.5in}{Thisistheonly{<_1{thatconformsto{<_{Strict}{and{DependOnThreads(M_1){.Thesecondreadofxcannotreturn1-itmustreturn3.};MSF=1.6;AAT/;
$cached_env_img{$key} = q|111#111|; 

$key = q/{displaymath}forall(m_1,m_2)inPotentialRaces(M):(m_1<_{Strict}m_2)lor(m_2<_{Strict}m_1){displaymath};MSF=1.6;AAT/;
$cached_env_img{$key} = q|84#84|; 

$key = q/textstyleparbox{3in}{Theonlyconstrainton{<_0{isRW(y,1)mustfollowRR(y,0).Severalothervalid{<_0{orderingsarepossible.};MSF=1.6;AAT/;
$cached_env_img{$key} = q|103#103|; 

$key = q/m_1<_tm_2;MSF=1.6;AAT/;
$cached_env_img{$key} = q|89#89|; 

$key = q/vinV;MSF=1.6;AAT/;
$cached_env_img{$key} = q|14#14|; 

$key = q/textstyleparbox{2.5in}{Thewritesarenon-conflicting,thereforenotorderedby{DependOnThreads(M_0){.};MSF=1.6;AAT/;
$cached_env_img{$key} = q|116#116|; 

$key = q/M;MSF=1.6;AAT/;
$cached_env_img{$key} = q|22#22|; 

$key = q/O_tcupW(M)cupSR(M);MSF=1.6;AAT/;
$cached_env_img{$key} = q|48#48|; 

$key = q/{displaymath}PotentialRaces(M){defatop=}left{(m_1,m_2)left|array{{l}Location(m_1hread(m_2)land(m_1inW(M)lorm_2inW(M))array{right.right}{displaymath};MSF=1.6;AAT/;
$cached_env_img{$key} = q|82#82|; 

$key = q/textstyleparbox{2.5in}{DependOnThreads(M_0){impliesthisistheonlyvalid{<_{Strict}{orderingover{StrictOnThreads(M){};MSF=1.6;AAT/;
$cached_env_img{$key} = q|105#105|; 

$key = q/y;MSF=1.6;AAT/;
$cached_env_img{$key} = q|99#99|; 

$key = q/(m_1,m_2);MSF=1.6;AAT/;
$cached_env_img{$key} = q|81#81|; 

$key = q/textstyleparbox{3in}{T0{observes{T1{'swritehappeningbeforeitsownread.};MSF=1.6;AAT/;
$cached_env_img{$key} = q|95#95|; 

$key = q/LW(M);MSF=1.6;AAT/;
$cached_env_img{$key} = q|28#28|; 

$key = q/upc_fence;MSF=1.6;AAT/;
$cached_env_img{$key} = q|52#52|; 

$key = q/RW(x,1)Rightarrowupc_notifyRightarrowupc_notifyRightarrowRR(x,0);MSF=1.6;AAT/;
$cached_env_img{$key} = q|129#129|; 

$key = q/local_z1==-4;MSF=1.6;AAT/;
$cached_env_img{$key} = q|68#68|; 

$key = q/x;MSF=1.6;AAT/;
$cached_env_img{$key} = q|100#100|; 

$key = q/textstyleparbox{3.25in}{Alloftheedgesshownarerequired,butthisisnotavalid{<_{Strict}{,sinceitcontainsacycle.};MSF=1.6;AAT/;
$cached_env_img{$key} = q|98#98|; 

$key = q/textstyleparbox{3in}{T1{mustobserveitsownprogramorderforconflictingoperations,butitsees{T0{'swriteasthefirstoperation.};MSF=1.6;AAT/;
$cached_env_img{$key} = q|97#97|; 

$key = q/{displaymath}Conflicting(M){defatop=}left{(m_1,m_2)left|array{{lc}Location(m_1)=ation(m_2)land(m_1inW(M)lorm_2inW(M))array{right.right}{displaymath};MSF=1.6;AAT/;
$cached_env_img{$key} = q|40#40|; 

$key = q/SR(M);MSF=1.6;AAT/;
$cached_env_img{$key} = q|23#23|; 

$key = q/local_x;MSF=1.6;AAT/;
$cached_env_img{$key} = q|76#76|; 

$key = q/t;MSF=1.6;AAT/;
$cached_env_img{$key} = q|9#9|; 

$key = q/l_{synch}inL;MSF=1.6;AAT/;
$cached_env_img{$key} = q|51#51|; 

$key = q/upc_memcpy;MSF=1.6;AAT/;
$cached_env_img{$key} = q|63#63|; 

$key = q/m_1<_{Strict}m_2;MSF=1.6;AAT/;
$cached_env_img{$key} = q|87#87|; 

$key = q/O;MSF=1.6;AAT/;
$cached_env_img{$key} = q|8#8|; 

$key = q/m_1Rightarrowm_2;MSF=1.6;AAT/;
$cached_env_img{$key} = q|88#88|; 

$key = q/z;MSF=1.6;AAT/;
$cached_env_img{$key} = q|73#73|; 

$key = q/<_{Strict};MSF=1.6;AAT/;
$cached_env_img{$key} = q|46#46|; 

$key = q/upc_all_broadcast;MSF=1.6;AAT/;
$cached_env_img{$key} = q|62#62|; 

$key = q/m_1rightarrowm_2;MSF=1.6;AAT/;
$cached_env_img{$key} = q|90#90|; 

$key = q/<_{Strict}.;MSF=1.6;AAT/;
$cached_env_img{$key} = q|126#126|; 

$key = q/{eqnarraystar}W(M){defatop=}SW(M)cupRW(M)cupLW(M){eqnarraystar};MSF=1.6;TAGS=R;AAT/;
$cached_env_img{$key} = q|30#30|; 

$key = q/upc_flag_t;MSF=1.6;AAT/;
$cached_env_img{$key} = q|78#78|; 

$key = q/Precedes();MSF=1.6;AAT/;
$cached_env_img{$key} = q|86#86|; 

$key = q/<_0,<_1;MSF=1.6;AAT/;
$cached_env_img{$key} = q|115#115|; 

$key = q/AllStrict(M);MSF=1.6;AAT/;
$cached_env_img{$key} = q|35#35|; 

$key = q/upc_barrier;MSF=1.6;AAT/;
$cached_env_img{$key} = q|79#79|; 

$key = q/T;MSF=1.6;AAT/;
$cached_env_img{$key} = q|7#7|; 

$key = q/{center}vbox{input{upc-scope}}{center};AAT/;
$cached_env_img{$key} = q|3#3|; 

$key = q/l;MSF=1.6;AAT/;
$cached_env_img{$key} = q|19#19|; 

$key = q/{center}vbox{input{upc-introduction}}{center};AAT/;
$cached_env_img{$key} = q|2#2|; 

$key = q/{displaymath}StrictPairs(M){defatop=}left{(m_1,m_2)left|array{{l}m_1neqm_2landm_1inStrict(M)landm_2inStrict(M)array{right.right}{displaymath};MSF=1.6;AAT/;
$cached_env_img{$key} = q|36#36|; 

$key = q/M_t;MSF=1.6;AAT/;
$cached_env_img{$key} = q|21#21|; 

$key = q/W(M);MSF=1.6;AAT/;
$cached_env_img{$key} = q|29#29|; 

$key = q/bullet;MSF=1.6;AAT/;
$cached_env_img{$key} = q|16#16|; 

$key = q/textstyleparbox{2.5in}{Relaxedreadsfromthread1donotappearin{<_0{};MSF=1.6;AAT/;
$cached_env_img{$key} = q|117#117|; 

$key = q/StrictOnThreads(M_t);MSF=1.6;AAT/;
$cached_env_img{$key} = q|43#43|; 

$key = q/<_1:;MSF=1.6;AAT/;
$cached_env_img{$key} = q|96#96|; 

$key = q/RW(M);MSF=1.6;AAT/;
$cached_env_img{$key} = q|26#26|; 

$key = q/T0;MSF=1.6;AAT/;
$cached_env_img{$key} = q|92#92|; 

$key = q/T1;MSF=1.6;AAT/;
$cached_env_img{$key} = q|93#93|; 

$key = q/textstyleparbox{2.3in}{DependOnThreads(M)andthesynchronizationsemanticsofbarrierimplythat<_{Strict}mustrespectalltheedgesshown.footnotemark};MSF=1.6;AAT/;
$cached_env_img{$key} = q|122#122|; 

$key = q/LR(M);MSF=1.6;AAT/;
$cached_env_img{$key} = q|27#27|; 

$key = q/upc_mem{put,get,cpy};MSF=1.6;AAT/;
$cached_env_img{$key} = q|64#64|; 

$key = q/N;MSF=1.6;AAT/;
$cached_env_img{$key} = q|136#136|; 

$key = q/SR(M)cupSW(M);MSF=1.6;AAT/;
$cached_env_img{$key} = q|125#125|; 

$key = q/textstyleparbox{2.5in}{DependOnThreads(M_1){impliesthisistheonlyvalid{<_{Strict}{orderingover{StrictOnThreads(M){};MSF=1.6;AAT/;
$cached_env_img{$key} = q|112#112|; 

$key = q/m;MSF=1.6;AAT/;
$cached_env_img{$key} = q|15#15|; 

$key = q/Location(m);MSF=1.6;AAT/;
$cached_env_img{$key} = q|18#18|; 

$key = q/SW(l_{synch},0);SR(l_{synch},0);MSF=1.6;AAT/;
$cached_env_img{$key} = q|53#53|; 

$key = q/textstyleparbox{2.5in}{<_0{conformsto{<_{Strict}{.Otherorderingsarepossible.};MSF=1.6;AAT/;
$cached_env_img{$key} = q|110#110|; 

$key = q/Precedes(m_1,m_2);MSF=1.6;AAT/;
$cached_env_img{$key} = q|44#44|; 

$key = q/Precedes;MSF=1.6;AAT/;
$cached_env_img{$key} = q|45#45|; 

$key = q/StrictOnThreads(M);MSF=1.6;AAT/;
$cached_env_img{$key} = q|34#34|; 

$key = q/Conflicting(M_t);MSF=1.6;AAT/;
$cached_env_img{$key} = q|42#42|; 

$key = q/z[1];MSF=1.6;AAT/;
$cached_env_img{$key} = q|66#66|; 

$key = q/m_1;MSF=1.6;AAT/;
$cached_env_img{$key} = q|130#130|; 

$key = q/SR(l_{synch},0);MSF=1.6;AAT/;
$cached_env_img{$key} = q|57#57|; 

$key = q/MLN=6;MSF=1.6;AAT/;
$cached_env_img{$key} = q|134#134|; 

$key = q/local_y==2;MSF=1.6;AAT/;
$cached_env_img{$key} = q|67#67|; 

$key = q/local_y;MSF=1.6;AAT/;
$cached_env_img{$key} = q|75#75|; 

$key = q/L;MSF=1.6;AAT/;
$cached_env_img{$key} = q|11#11|; 

$key = q/<;MSF=1.6;AAT/;
$cached_env_img{$key} = q|132#132|; 

$key = q/{displaymath}StrictOnThreads(M){defatop=}left{(m_1,m_2)left|array{{l}m_1neqm_2laland(m_1inStrict(M)lorm_2inStrict(M))array{right.right}{displaymath};MSF=1.6;AAT/;
$cached_env_img{$key} = q|37#37|; 

$key = q/upc_lock-_attempt();MSF=1.6;AAT/;
$cached_env_img{$key} = q|59#59|; 

$key = q/{eqnarraystar}Strict(M){defatop=}SR(M)cupSW(M){eqnarraystar};MSF=1.6;TAGS=R;AAT/;
$cached_env_img{$key} = q|32#32|; 

$key = q/upc_mem-{put,get,cpy};MSF=1.6;AAT/;
$cached_env_img{$key} = q|61#61|; 

$key = q/z[0];MSF=1.6;AAT/;
$cached_env_img{$key} = q|77#77|; 

$key = q/RW(x,1)Rightarrowupc_notifyRightarrowupc_waitRightarrowRR(x,0);MSF=1.6;AAT/;
$cached_env_img{$key} = q|123#123|; 

$key = q/V;MSF=1.6;AAT/;
$cached_env_img{$key} = q|12#12|; 

$key = q/{displaymath}array{{l}DependOnThreads(M){defatop=}left{langlem_1,m_2rangleleft|anStrictOnThreads(M)array{right)array{right.right}array{{displaymath};MSF=1.6;AAT/;
$cached_env_img{$key} = q|41#41|; 

$key = q/upc_wait;MSF=1.6;AAT/;
$cached_env_img{$key} = q|56#56|; 

$key = q/C;MSF=1.6;AAT/;
$cached_env_img{$key} = q|135#135|; 

$key = q/textstyleparbox{2.5in}{<_0{conformsto{<_{Strict}{};MSF=1.6;AAT/;
$cached_env_img{$key} = q|106#106|; 

$key = q/upc_memput;MSF=1.6;AAT/;
$cached_env_img{$key} = q|74#74|; 

$key = q/<_0;MSF=1.6;AAT/;
$cached_env_img{$key} = q|94#94|; 

$key = q/StrictPairs(M);MSF=1.6;AAT/;
$cached_env_img{$key} = q|33#33|; 

$key = q/MLN;MSF=1.6;AAT/;
$cached_env_img{$key} = q|133#133|; 

$key = q/shown.;MSF=1.6;AAT/;
$cached_env_img{$key} = q|121#121|; 

$key = q/textstyleparbox{2.5in}{Thisistheonly{<_0{thatconformsto{<_{Strict}{and{DependOnThreads(M_0){.Thesecondreadofxcannotreturn1-itmustreturn2.};MSF=1.6;AAT/;
$cached_env_img{$key} = q|113#113|; 

1;

