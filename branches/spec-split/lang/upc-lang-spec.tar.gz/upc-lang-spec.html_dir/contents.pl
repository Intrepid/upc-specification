# LaTeX2HTML 2008 (1.71)
# Associate contents original text with physical files.


$key = q/0 0 0 3 5 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '4%:%'."$dir".q|upc-lang-spec.html%:%5 Examples| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 0 2 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '4%:%'."$dir".q|upc-lang-spec.html%:%3 Predefined identifiers| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 0 3 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '4%:%'."$dir".q|upc-lang-spec.html%:%1 Definitions| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 0 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '3%:%'."$dir".q|upc-lang-spec.html%:%2 Formal UPC Memory Consistency Semantics| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '3%:%'."$dir".q|upc-lang-spec.html%:%Contents| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 0 6 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '3%:%'."$dir".q|upc-lang-spec.html%:%About this document ...%:%<tex2html_star_mark>| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '0%:%'."$dir".q|upc-lang-spec.html%:%UPC Language Specifications
V1.2 | unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 0 2 7 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '4%:%'."$dir".q|upc-lang-spec.html%:%7 Preprocessing directives| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 0 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '3%:%'."$dir".q|upc-lang-spec.html%:%1 Language| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 0 3 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '4%:%'."$dir".q|upc-lang-spec.html%:%3 Consistency Semantics of Standard Libraries and Language Operations| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 0 2 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '4%:%'."$dir".q|upc-lang-spec.html%:%4 Expressions| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 0 5 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '3%:%'."$dir".q|upc-lang-spec.html%:%Index| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 0 3 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '4%:%'."$dir".q|upc-lang-spec.html%:%2 Memory Access Model| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 0 2 5 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '4%:%'."$dir".q|upc-lang-spec.html%:%5 Declarations| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 0 2 6 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '4%:%'."$dir".q|upc-lang-spec.html%:%6 Statements and blocks| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 0 2 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '4%:%'."$dir".q|upc-lang-spec.html%:%1 Notations| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 0 3 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '4%:%'."$dir".q|upc-lang-spec.html%:%4 Properties Implied by the Specification| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 0 2 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '4%:%'."$dir".q|upc-lang-spec.html%:%2 Keywords| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 0 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '3%:%'."$dir".q|upc-lang-spec.html%:%3 UPC versus C Standard Section Numbering| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 0 3 6 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '4%:%'."$dir".q|upc-lang-spec.html%:%6 Formal Definition of Precedes| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

1;

