# LaTeX2HTML 2008 (1.71)
# Associate internals original text with physical files.


$key = q/shared_array/;
$ref_files{$key} = "$dir".q|upc-lang-spec.html|; 
$noresave{$key} = "$nosave";

$key = q/upc_barrier/;
$ref_files{$key} = "$dir".q|upc-lang-spec.html|; 
$noresave{$key} = "$nosave";

$key = q/max_block_size/;
$ref_files{$key} = "$dir".q|upc-lang-spec.html|; 
$noresave{$key} = "$nosave";

$key = q/declarator/;
$ref_files{$key} = "$dir".q|upc-lang-spec.html|; 
$noresave{$key} = "$nosave";

$key = q/pointer-arithmetic/;
$ref_files{$key} = "$dir".q|upc-lang-spec.html|; 
$noresave{$key} = "$nosave";

$key = q/threads/;
$ref_files{$key} = "$dir".q|upc-lang-spec.html|; 
$noresave{$key} = "$nosave";

$key = q/MemModelPrecedes/;
$ref_files{$key} = "$dir".q|upc-lang-spec.html|; 
$noresave{$key} = "$nosave";

$key = q/localDepend/;
$ref_files{$key} = "$dir".q|upc-lang-spec.html|; 
$noresave{$key} = "$nosave";

$key = q/type_qualifiers/;
$ref_files{$key} = "$dir".q|upc-lang-spec.html|; 
$noresave{$key} = "$nosave";

$key = q/mem-semantics/;
$ref_files{$key} = "$dir".q|upc-lang-spec.html|; 
$noresave{$key} = "$nosave";

$key = q/pragmas/;
$ref_files{$key} = "$dir".q|upc-lang-spec.html|; 
$noresave{$key} = "$nosave";

$key = q/indefinite_block_size/;
$ref_files{$key} = "$dir".q|upc-lang-spec.html|; 
$noresave{$key} = "$nosave";

$key = q/MemoryAccessModel/;
$ref_files{$key} = "$dir".q|upc-lang-spec.html|; 
$noresave{$key} = "$nosave";

$key = q/MemModelExamples/;
$ref_files{$key} = "$dir".q|upc-lang-spec.html|; 
$noresave{$key} = "$nosave";

1;

